"""Install automatic VAT progress-difference update without touching business data."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import secrets
import shutil
import sys

ROOT=Path(__file__).resolve().parent
VERSION='2026.11.20.46'
CORE=['corporate_close_app.py','corporate_close_store.py','corporate_progress.py','corporate_progress_report.py']
NAV='app_navigation.py'
NEW={
    'corporate_close_app.py':'0530acdc0c5fa6b0473ec64cd0f0cf29c5ec29f9204879c5e16787a17a4cdd1e',
    'corporate_close_store.py':'b0ae1fd36da05476803906c22db218667b210486a67c8a71039399be673509d9',
    'corporate_progress.py':'cfaef8b3f7c853fb3537324ad0133040c3086fc1da41d5c1f8b4bea454258e0f',
    'corporate_progress_report.py':'dcd636286420d75357d2db59617486dc49a143e84f550d830ef509600f0246cc',
}
ACCEPTED={
    'corporate_close_app.py':{'2673a1f0e0d14db500629ace6ff7cab2a383e8a24313ed5f2b9fc16272755157','061ea58e9e82b84c74af238ac1c588e86245a05d17f9c85b8994ee5975a1b5ab','4e20da2d58ec6d20b8204b919ae3c77e74c77ec1f751ca549ab3f0ecec67051f',NEW['corporate_close_app.py']},
    'corporate_close_store.py':{'e42d5cfbcb1780f03b26742cfac586557faa98ddc7757add64321eff0b199354','41c249286102a8dfce0ab27072827cdd798bafab29df7aaebe1d4211ee6c2751',NEW['corporate_close_store.py']},
    'corporate_progress.py':{'7d36a731145cc84ae548b26448538953d05a11a545e6e9432e6f8bbee3e35c68','314fbd955ee2842fed4dbdcbef54acb2b201f36c26298146c7a92241986d0d5e','ec6f1e570acecdec15425854bf4caa9d2154cb0c87ccaabbd2f528dfb32e8a32',NEW['corporate_progress.py']},
    'corporate_progress_report.py':{'bb14143006599c611487c1dd7ce472e432d316ea8ed762c3767aa833d1fb0d57','24bf2973d1d5713910f25f111d5562551ea5c588ec3c3000c326637073f18128',NEW['corporate_progress_report.py']},
}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def patched_navigation(path):
    text=path.read_text(encoding='utf-8')
    if 'VERSION' not in text or 'st.' not in text:raise ValueError('현재 메뉴 파일 형식을 확인할 수 없습니다. 아무 파일도 변경하지 않았습니다.')
    updated,count=re.subn(r"(VERSION\s*=\s*)(['\"])([^'\"]+)\2",lambda m:m.group(1)+m.group(2)+VERSION+m.group(2),text,count=1)
    if count!=1:raise ValueError('현재 메뉴 파일의 버전 항목을 찾지 못했습니다. 아무 파일도 변경하지 않았습니다.')
    updated=re.sub(r'버전\s+\d{4}\.\d{2}\.\d{2}\.\d+','버전 '+VERSION,updated)
    compile(updated,NAV,'exec');return updated

def update(target):
    target=Path(target).expanduser().resolve()
    if target.is_file():target=target.parent
    if target==ROOT:raise ValueError('현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.')
    if not (target/'start.bat').is_file():raise ValueError('현재 사용하는 Sheri2 프로그램 폴더가 아닙니다.')
    for name in CORE:
        source=ROOT/name;installed=target/name
        if not source.is_file() or digest(source)!=NEW[name]:raise ValueError('업데이트 패키지 파일 검증에 실패했습니다: '+name)
        if not installed.is_file():raise ValueError('필수 프로그램 파일이 없습니다: '+name)
        if digest(installed) not in ACCEPTED[name]:raise ValueError('확인된 최신 운영본과 다른 파일입니다: '+name+'. 아무 파일도 변경하지 않았습니다.')
        compile(source.read_text(encoding='utf-8'),name,'exec')
    nav=target/NAV
    if not nav.is_file():raise ValueError('메뉴 파일이 없습니다: '+NAV)
    nav_text=patched_navigation(nav)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3);backup=target/'private'/'code-updates'/stamp;backup.mkdir(parents=True)
    manifest={'version':VERSION,'files':{}}
    for name in CORE+[NAV]:
        path=target/name;manifest['files'][name]=digest(path);shutil.copy2(path,backup/name)
    (backup/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    installed_names=[]
    try:
        for name in CORE:
            temporary=target/(name+'.update-'+secrets.token_hex(4))
            try:
                shutil.copy2(ROOT/name,temporary)
                if digest(temporary)!=NEW[name]:raise ValueError('복사 파일 검증에 실패했습니다: '+name)
                temporary.replace(target/name);installed_names.append(name)
            finally:temporary.unlink(missing_ok=True)
        temporary=target/(NAV+'.update-'+secrets.token_hex(4))
        try:
            temporary.write_text(nav_text,encoding='utf-8');compile(temporary.read_text(encoding='utf-8'),NAV,'exec');temporary.replace(nav);installed_names.append(NAV)
        finally:temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed_names):shutil.copy2(backup/name,target/name)
        raise
    for name in CORE:
        if digest(target/name)!=NEW[name]:raise ValueError('설치 후 검증에 실패했습니다: '+name)
    if VERSION not in nav.read_text(encoding='utf-8'):raise ValueError('메뉴 버전 표시 확인에 실패했습니다.')
    print('VAT 신고 작업진행률 수입차액 자동계산 업데이트 완료:',target)
    print('기존 DB, 원장, 결산, 정산, 마감 및 발행자료는 삭제하거나 변경하지 않았습니다.')
    print('기존 코드 백업:',backup)

def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
    finally:
        if window:window.destroy()

if __name__=='__main__':
    try:
        selected=choose_target()
        if not selected:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
        update(selected)
    except Exception as error:raise SystemExit('업데이트 실패: '+str(error))

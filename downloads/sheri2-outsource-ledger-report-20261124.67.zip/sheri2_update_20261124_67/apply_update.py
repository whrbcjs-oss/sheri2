"""Find the Sheri2 runtime directory and install the subcontract settlement menu there."""
from datetime import datetime, timezone
from pathlib import Path
import json
import re
import secrets
import shutil
import sys

ROOT=Path(__file__).resolve().parent
VERSION='2026.11.24.67'
PAYLOAD=['outsource_settlement_app.py','outsource_settlement_store.py','outsource_settlement_report.py']

def patch_navigation(text):
    if 'REPORTS' not in text or 'app_secondary_navigation' not in text:
        raise ValueError('지원되는 메뉴 파일이 아닙니다.')
    text,count=re.subn(r'^REPORTS\s*=.*$',"REPORTS = ['엘비데크 월별보고', '자체결산 보고', '법인결산', '채권채무확인서', '외주정산']",text,count=1,flags=re.M)
    if count!=1:raise ValueError('결산보고서 하위 메뉴 목록을 찾지 못했습니다.')
    # Patch every known form of the report-key list, including already-patched files.
    pattern=r"\['monthly'\s*,\s*'self'\s*,\s*'corporate'\s*,\s*'balance_confirmation'(?:\s*,\s*'outsource_settlement')?\s*\]"
    text,count=re.subn(pattern,"['monthly','self','corporate','balance_confirmation','outsource_settlement']",text,count=1)
    if count!=1:raise ValueError('결산보고서 버튼 키를 찾지 못했습니다.')
    # Five buttons plus one optional spacer. This replacement is cosmetic; menu creation does not depend on it.
    text=re.sub(r"st\.columns\(\[[^\]]+\],\s*gap='small'\)(\s*\n\s*for column, name, key in zip\(columns, REPORTS)",
                "st.columns([1.25,1.1,1,1.3,1.0,1.7], gap='small')\\1",text,count=1)
    text,count=re.subn(r"(VERSION\s*=\s*)(['\"])([^'\"]+)\2",lambda m:m.group(1)+m.group(2)+VERSION+m.group(2),text,count=1)
    if count!=1:raise ValueError('메뉴 버전 항목을 찾지 못했습니다.')
    text=re.sub(r'버전\s+\d{4}\.\d{2}\.\d{2}\.\d+','버전 '+VERSION,text)
    compile(text,'app_navigation.py','exec');return text

def patch_router(text):
    if "program=='외주정산'" in text:
        compile(text,'multiuser_app.py','exec');return text
    needle="""                elif program=='채권채무확인서':
                    from balance_confirmation_app import render as render_balance_confirmation
                    render_balance_confirmation(user)
"""
    addition=needle+"""                elif program=='외주정산':
                    from outsource_settlement_app import render as render_outsource_settlement
                    render_outsource_settlement(user)
"""
    if text.count(needle)!=1:raise ValueError('채권채무확인서 화면 연결 위치를 찾지 못했습니다.')
    text=text.replace(needle,addition,1);compile(text,'multiuser_app.py','exec');return text

def runtime_directories(start_file):
    root=start_file.parent.resolve();found=[]
    def add(path):
        path=path.resolve()
        if path not in found and (path/'app_navigation.py').is_file() and (path/'multiuser_app.py').is_file():found.append(path)
    add(root)
    # Resolve explicit Python paths referenced by start.bat.
    raw=start_file.read_text(encoding='utf-8',errors='ignore')
    for token in re.findall(r'[^\s"\']+\.py',raw,re.I):
        candidate=Path(token.replace('\\','/'))
        if not candidate.is_absolute():candidate=root/candidate
        add(candidate.parent)
    # Older distributions sometimes keep the active source one or two folders below start.bat.
    for app in root.glob('*/multiuser_app.py'):add(app.parent)
    for app in root.glob('*/*/multiuser_app.py'):add(app.parent)
    return found

def install_one(target,backup_root):
    navigation=patch_navigation((target/'app_navigation.py').read_text(encoding='utf-8'))
    router=patch_router((target/'multiuser_app.py').read_text(encoding='utf-8'))
    relative=target.name+'-'+secrets.token_hex(2);backup=backup_root/relative;backup.mkdir(parents=True)
    names=['app_navigation.py','multiuser_app.py']+PAYLOAD
    existing=[]
    for name in names:
        path=target/name
        if path.is_file():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved);existing.append(name)
    (backup/'manifest.json').write_text(json.dumps({'version':VERSION,'runtime':str(target),'files':existing},ensure_ascii=False,indent=2),encoding='utf-8')
    installed=[]
    try:
        for name in PAYLOAD:
            destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True)
            temporary=destination.with_name(destination.name+'.update-'+secrets.token_hex(3))
            try:shutil.copy2(ROOT/name,temporary);temporary.replace(destination);installed.append(name)
            finally:temporary.unlink(missing_ok=True)
        for name,content in [('app_navigation.py',navigation),('multiuser_app.py',router)]:
            destination=target/name;temporary=destination.with_name(destination.name+'.update-'+secrets.token_hex(3))
            try:temporary.write_text(content,encoding='utf-8');compile(content,name,'exec');temporary.replace(destination);installed.append(name)
            finally:temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed):
            saved=backup/name;destination=target/name
            if saved.is_file():destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(saved,destination)
            else:destination.unlink(missing_ok=True)
        raise
    check=(target/'app_navigation.py').read_text(encoding='utf-8')
    if "'외주정산'" not in check or VERSION not in check:raise ValueError('메뉴 설치 후 검증에 실패했습니다: '+str(target))
    return backup

def update(selected):
    selected=Path(selected).expanduser().resolve()
    start=selected if selected.is_file() else selected/'start.bat'
    if start.name.lower()!='start.bat' or not start.is_file():raise ValueError('현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요.')
    for name in PAYLOAD:
        if not (ROOT/name).is_file():raise ValueError('업데이트 구성 파일이 없습니다: '+name)
    targets=runtime_directories(start)
    if not targets:raise ValueError('start.bat 주변에서 실제 app_navigation.py와 multiuser_app.py를 찾지 못했습니다.')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)
    backup_root=start.parent/'private'/'code-updates'/stamp;backup_root.mkdir(parents=True)
    completed=[];errors=[]
    for target in targets:
        try:install_one(target,backup_root);completed.append(target)
        except Exception as exc:errors.append(f'{target}: {exc}')
    if not completed:raise ValueError('실행본을 수정하지 못했습니다. '+' | '.join(errors))
    print('Sheri2 subcontract settlement report-form update completed.')
    for target in completed:print('Patched runtime:',target)
    if errors:
        print('Ignored non-runtime candidates:')
        for error in errors:print(' -',error)
    print('Code backup:',backup_root)

def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
    finally:
        if window:window.destroy()

if __name__=='__main__':
    try:
        selected=choose_target()
        if not selected:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
        update(selected)
    except Exception as error:raise SystemExit('업데이트 실패: '+str(error))

"""PC-first subcontract settlement workflow."""
from __future__ import annotations

import hashlib
from datetime import date, datetime
from html import escape

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

import outsource_settlement_report as report
import outsource_settlement_store as db


CSS='''<style>
.os-hero{background:linear-gradient(120deg,#ecf8f4,#e8f4fb);border:1px solid #bcd9d2;border-left:6px solid #2c94a8;border-radius:10px;padding:14px 17px;margin:3px 0 12px}.os-hero small{display:block;color:#3b8882;font-weight:800;letter-spacing:.06em}.os-hero strong{font-size:24px;color:#174a42;display:block}.os-title{background:#eaf6f2;border-left:5px solid #279c7b;padding:8px 11px;margin:12px 0 8px;color:#145c4d;font-size:18px;font-weight:850}.os-note{background:#f1f8fc;border:1px solid #cfe1eb;border-radius:8px;padding:9px 11px;color:#385b69}.st-key-os_metrics [data-testid="stMetric"]{background:white;border:1px solid #c9ddd6;border-top:4px solid #4b9fb3;border-radius:11px;padding:9px 12px}.st-key-os_work [data-testid="stDataFrame"]{border:1px solid #c7d9d3;border-radius:8px}.st-key-os_context{background:#f7fbfa;border:1px solid #c9ddd6;border-radius:10px;padding:8px 12px}.st-key-os_tabs button p{font-size:16px!important;font-weight:800!important}div[data-testid="stDataFrame"]{font-size:14px!important}.os-settlement-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:stretch;margin:10px 0 16px}.os-settlement-card{display:flex;flex-direction:column;min-width:0}.os-settlement-card h3{margin:0;background:#e8f6f1;border-left:5px solid #279c7b;padding:8px 10px;color:#145c4d;font-size:17px}.os-settlement-table{width:100%;border-collapse:separate;border-spacing:0;table-layout:fixed;border:1px solid #bfd5ce;border-radius:0 0 10px 10px;overflow:hidden;background:white}.os-settlement-table th,.os-settlement-table td{border-right:1px solid #d6e2de;border-bottom:1px solid #d6e2de;padding:6px 10px;height:34px;font-size:14px}.os-settlement-table th{background:#f3f8f6;color:#5d716b;text-align:left;font-weight:700}.os-settlement-table th:last-child,.os-settlement-table td:last-child{border-right:0;text-align:right;width:38%;font-variant-numeric:tabular-nums}.os-settlement-table tr:last-child td{border-bottom:0}.os-settlement-table tr.major td{font-weight:800;color:#21483f;background:#fbfdfc}.os-settlement-table tr.sub td:first-child{padding-left:28px;color:#49665e}.os-settlement-table tr.result td{font-weight:850;background:#edf7f3;color:#0d6b53}.os-settlement-table tr.final td{font-weight:900;background:#e2f3ed;color:#075a45}.os-settlement-table tr.blank td{color:transparent}.os-settlement-table tr.blank td:last-child{color:transparent}@media(max-width:900px){.os-settlement-grid{grid-template-columns:1fr}.os-settlement-table th,.os-settlement-table td{font-size:13px}}</style>'''


def _date(value):
    try:return datetime.strptime(str(value),'%Y-%m-%d').date()
    except (TypeError,ValueError):return date.today()


def _money(value):return f'{int(value or 0):,}원'


def _flash():
    message=st.session_state.pop('_os_notice',None)
    if message:getattr(st,message[0])(message[1])


def _project_header(c):
    records=db.projects(c)
    pending=st.session_state.pop('_os_pending_project_id',None)
    if pending is not None:st.session_state['os_project_id']=int(pending)
    st.html(CSS+'<style>.os-settlement-table td:not(:first-child),.os-settlement-table th:not(:first-child){text-align:right}.os-deductions th:first-child{width:34%}.os-deductions th:not(:first-child){width:22%}.os-deductions th:last-child,.os-deductions td:last-child{width:22%}</style>')
    st.html('<div class="os-hero"><small>SUBCONTRACT · COST SETTLEMENT</small><strong>외주정산</strong>도급내역·원장·급여자료를 한 공사 단위로 연결해 실행금액과 최종정산금액을 계산합니다.</div>')
    with st.container(key='os_context'):
        left,right=st.columns([3,.7])
        choices=[0]+[item['id'] for item in records]
        labels={item['id']:f"{item['project_name']} · {item['contractor'] or '외주업체 미입력'}" for item in records}
        if st.session_state.get('os_project_id') not in choices:st.session_state['os_project_id']=choices[0]
        selected_id=left.selectbox('작업 공사',choices,format_func=lambda x:'새 공사 등록' if not x else labels[x],key='os_project_id')
        right.button('새 공사',use_container_width=True,type='primary',on_click=lambda:st.session_state.update(os_project_id=0))
    return next((item for item in records if item['id']==selected_id),None)


def _project_form(c,row):
    st.html('<div class="os-title">공사·계약 기본정보</div>')
    value=row or {'company_name':db.company_names()[0],'project_name':'','contractor':'','written_at':date.today().isoformat(),
      'contract_date':'','start_date':'','end_date':'','client_name':'','contract_amount':0,'levy_rate':0.0,
      'original_contract_amount':0,'original_levy_rate':0.0,'reserve_amount':0,'public_adjustment':0,'retirement_pension':0,'version':0}
    companies=db.company_names();key=f"os_project_form_{value.get('id',0)}_{value.get('version',0)}"
    with st.form(key):
        a,b,d=st.columns([1,2.2,1.2]);company_name=a.selectbox('당사',companies,index=companies.index(value['company_name']) if value.get('company_name') in companies else 0);project_name=b.text_input('공사명',value.get('project_name',''));contractor=d.text_input('외주업체명',value.get('contractor',''))
        a,b,d,e=st.columns(4);written_at=a.date_input('작성일',_date(value.get('written_at')));contract_date=b.date_input('계약일',_date(value.get('contract_date')));start_date=d.date_input('착공일',_date(value.get('start_date')));end_date=e.date_input('준공일',_date(value.get('end_date')))
        client_name=st.text_input('발주처',value.get('client_name',''))
        a,b,d,e=st.columns(4);contract_amount=a.number_input('현재 계약금액(VAT 포함)',min_value=0,value=int(value.get('contract_amount',0)),step=1000);levy_rate=b.number_input('현재 부금율(%)',min_value=0.0,max_value=100.0,value=float(value.get('levy_rate',0)),step=.1);original_contract_amount=d.number_input('당초 계약금액(VAT 포함)',min_value=0,value=int(value.get('original_contract_amount',0)),step=1000);original_levy_rate=e.number_input('당초 부금율(%)',min_value=0.0,max_value=100.0,value=float(value.get('original_levy_rate',0)),step=.1)
        a,b=st.columns(2);reserve_amount=a.number_input('유보금',value=int(value.get('reserve_amount',0)),step=1000);public_adjustment=b.number_input('공무부 확인 조정액',value=int(value.get('public_adjustment',0)),step=1000)
        # Kept internally only for compatibility with amounts saved by older versions.
        retirement_pension=int(value.get('retirement_pension',0))
        save=st.form_submit_button('공사정보 저장',type='primary')
    if save:
        try:
            project_id=db.save_project(c,locals(),value.get('id'),value.get('version'))
            st.session_state['_os_notice']=('success','공사정보를 저장했습니다.')
            st.session_state['_os_pending_project_id']=project_id;st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    if row:
        with st.expander('이 공사 삭제'):
            confirm=st.checkbox('원장·급여자료를 포함해 이 공사를 목록에서 삭제합니다.',key=f'os_delete_confirm_{row["id"]}')
            if st.button('공사 삭제',disabled=not confirm,key=f'os_delete_{row["id"]}'):
                try:db.delete_project(c,row['id'],row['version']);st.session_state['_os_notice']=('success','공사를 삭제했습니다.');st.session_state['_os_pending_project_id']=0;st.rerun()
                except (ValueError,PermissionError) as exc:st.error(str(exc))


def _upload_contract(c,row,kind,scope):
    label='당초 내역서' if kind=='original' else '변경 내역서'
    uploaded=st.file_uploader(f'{label} Excel 업로드',type=['xlsx','xlsm'],key=f'os_{scope}_{kind}_{row["id"]}')
    cache=f'_os_{kind}_items_{row["id"]}'
    if uploaded:
        digest=hashlib.sha256(uploaded.getvalue()).hexdigest()
        saved=st.session_state.get(cache)
        if not saved or saved['digest']!=digest:
            try:st.session_state[cache]={'digest':digest,'items':db.parse_contract(uploaded.getvalue())}
            except ValueError as exc:st.error(str(exc))
    items=(st.session_state.get(cache) or {}).get('items',db.json_items(row,kind))
    frame=pd.DataFrame(items or [],columns=['반영','항목','금액'])
    with st.form(f'os_{scope}_{kind}_form_{row["id"]}'):
        edited=st.data_editor(frame,hide_index=True,use_container_width=True,num_rows='dynamic',key=f'os_{scope}_{kind}_editor_{row["id"]}',
          column_config={'반영':st.column_config.CheckboxColumn('정산 반영'),'항목':st.column_config.TextColumn('실비정산 항목'),'금액':st.column_config.NumberColumn('내역금액',format='localized')})
        save=st.form_submit_button(f'{label} 선택항목 저장',type='primary')
    if save:
        try:db.save_items(c,row['id'],kind,edited.to_dict('records'),row['version']);st.session_state.pop(cache,None);st.session_state['_os_notice']=('success',f'{label} 항목을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def _metrics(calc, rate):
    with st.container(key='os_metrics'):
        cols=st.columns(5)
        for col,(label,key) in zip(cols,[('공급가액 ①','supply'),('보험료 합계 ②','insurance'),('외주비 ③','outsource'),(f'관리비 ④ ({float(rate or 0):.2f}%)','management'),('실행금액 ⑤','execution')]):col.metric(label,_money(calc[key]))


def _settlement_table(calc,detail_items,rate):
    st.caption(f"실정산원가 {calc['real_settlement_cost']:,}원 = 본사직불금액 {calc['direct']:,}원 + 미지급금 {calc['unpaid']:,}원")
    details=[]
    for item in detail_items:
        if not item.get('반영'):continue
        name=str(item.get('항목') or '').strip()
        if name:details.append(('sub','↳ '+name,db.money(item.get('금액'))))
    left=[('major','① 공급가액',calc['supply']),('major','② 실비정산 항목 합계',calc['insurance'])]
    left+=details
    left += [('major','③ 외주비 금액',calc['outsource']),('major',f'④ 관리비 ({float(rate or 0):.2f}%)',calc['management']),
             ('major','⑤ 실행금액',calc['execution']),('major','⑥ 매입 VAT',calc['purchase_vat']),
             ('final','계(⑤+⑥)',calc['total'])]
    right=[('major',name,values.get('estimate'),values.get('actual'),values.get('difference'))
           for name,values in calc['deduction_details'].items()]
    right += [('result','공제 합계',None,None,calc['deduction_total']),('result','정산 차액',None,None,calc['difference']),
              ('final','최종정산금액',None,None,calc['final'])]
    size=max(len(left),len(right))
    left += [('blank','　',0)]*(size-len(left));right += [('blank','　',None,None,None)]*(size-len(right))
    def left_body(items):
        output=[]
        for style,label,value in items:
            shown='' if style=='blank' else f'{int(value or 0):,}'
            output.append(f'<tr class="{style}"><td>{escape(label)}</td><td>{shown}</td></tr>')
        return ''.join(output)
    def right_body(items):
        output=[]
        for style,label,estimate,actual,difference in items:
            values=['' if value is None or style=='blank' else f'{int(value):,}' for value in (estimate,actual,difference)]
            output.append(f'<tr class="{style}"><td>{escape(label)}</td><td>{values[0]}</td><td>{values[1]}</td><td>{values[2]}</td></tr>')
        return ''.join(output)
    st.html('<div class="os-settlement-grid">'
      '<section class="os-settlement-card"><h3>공사내역 및 지출과목</h3><table class="os-settlement-table">'
      '<thead><tr><th>산출내역</th><th>금액</th></tr></thead><tbody>'+left_body(left)+'</tbody></table></section>'
      '<section class="os-settlement-card"><h3>공제과목금액</h3><table class="os-settlement-table os-deductions">'
      '<thead><tr><th>과목</th><th>내역서</th><th>원장</th><th>공제금액</th></tr></thead><tbody>'+right_body(right)+'</tbody></table></section></div>')


def _receipts(c,row):
    st.html('<div class="os-title">공사비 수령내역(공급가액)</div>')
    frame=pd.DataFrame(db.receipts(row),columns=['일자','내역','금액'])
    with st.form(f'os_receipts_form_{row["id"]}'):
        edited=st.data_editor(frame,hide_index=True,use_container_width=True,num_rows='dynamic',key=f'os_receipts_{row["id"]}',
          column_config={'일자':st.column_config.TextColumn('일자 (YYYY-MM-DD)'),'내역':st.column_config.TextColumn('내역'),'금액':st.column_config.NumberColumn('금액',format='localized')})
        save=st.form_submit_button('공사비 수령내역 저장',type='primary')
    receipt_total=sum(db.money(item.get('금액')) for item in db.receipts(row))
    st.metric('공사비 수령 합계금액',_money(receipt_total))
    if save:
        try:db.save_receipts(c,row['id'],edited.to_dict('records'),row['version']);st.session_state['_os_notice']=('success','공사비 수령내역을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def contract_tab(c,row,changed=False):
    ledger_rows=db.ledger(c,row['id']);payroll_rows=db.payroll(c,row['id']);calc=db.calculations(row,ledger_rows,payroll_rows,changed=changed)
    if changed:
        original_record=dict(row);original_record['contract_amount']=row.get('original_contract_amount') or row['contract_amount'];original_record['levy_rate']=row.get('original_levy_rate') or row['levy_rate']
        original=db.calculations(original_record,ledger_rows,payroll_rows,False)
        cols=st.columns(3);cols[0].metric('당초 실행금액',_money(original['execution']));cols[1].metric('변경 증감액',_money(calc['execution']-original['execution']));cols[2].metric('변경 후 실행금액',_money(calc['execution']))
        _upload_contract(c,row,'original','change_tab');_upload_contract(c,row,'changed','change_tab')
        st.html('<div class="os-title">당초와 변경내역 비교</div>')
        labels=['공급가액','보험료 합계','외주비','관리비','실행금액']
        keys=['supply','insurance','outsource','management','execution']
        comparison=pd.DataFrame([[label,original[key],calc[key]-original[key],calc[key]] for label,key in zip(labels,keys)],columns=['산출내역','당초','변경(증·감)','변경 후'])
        st.dataframe(comparison,hide_index=True,use_container_width=True,column_config={name:st.column_config.NumberColumn(name,format='localized') for name in ['당초','변경(증·감)','변경 후']})
        st.html('<div class="os-title">변경 후 공사내역·공제과목</div>')
        _settlement_table(calc,db.json_items(row,'changed'),row.get('levy_rate'))
    else:
        current_kind='changed' if db.json_items(row,'changed') else 'original'
        _upload_contract(c,row,current_kind,'base_tab')
        _metrics(calc,row.get('levy_rate'));_settlement_table(calc,db.json_items(row,current_kind),row.get('levy_rate'));_receipts(c,row)
    return calc


def ledger_tab(c,row):
    uploaded=st.file_uploader('아마란스 프로젝트별 계정내역 Excel',type=['xlsx','xlsm'],key=f'os_ledger_upload_{row["id"]}')
    if uploaded:
        try:
            parsed=db.parse_ledger(uploaded.getvalue());st.success(f'{len(parsed):,}개 원장 행을 찾았습니다.')
            st.dataframe(pd.DataFrame(parsed[:20]),hide_index=True,use_container_width=True,column_config={'amount':st.column_config.NumberColumn('지출',format='localized'),'payment':None})
            if st.button('기존 원장을 교체하고 업로드',type='primary',key=f'os_ledger_replace_{row["id"]}'):
                db.replace_ledger(c,row['id'],parsed,uploaded.name);st.session_state['_os_notice']=('success',f'원장 {len(parsed):,}개 행을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    records=db.ledger(c,row['id'])
    if not records:st.info('등록된 원장이 없습니다.');return
    included_count=sum(bool(x.get('included',1)) for x in records)
    st.caption(f'계산 포함 {included_count:,}행 · 제외 {len(records)-included_count:,}행 — 자동 제외 행도 체크하면 다시 포함할 수 있습니다.')
    ledger_calc=db.calculations(row,records,db.payroll(c,row['id']),changed=bool(db.json_items(row,'changed')))
    for col,(label,key) in zip(st.columns(5),[('원장 전체금액','ledger_amount'),('제외·외주업체 차감','excluded_cost'),('실정산원가','real_settlement_cost'),('미지급금','unpaid'),('본사직불금액','direct')]):col.metric(label,_money(ledger_calc[key]))
    controls=st.columns([1.5,1,1]);query=controls[0].text_input('적요·거래처 검색',key=f'os_ledger_search_{row["id"]}');note=controls[1].selectbox('비고분류',['전체']+sorted({x['note'] for x in records if x['note']}),key=f'os_ledger_note_{row["id"]}');scope=controls[2].selectbox('계산반영',['전체','포함','제외'],key=f'os_ledger_scope_{row["id"]}')
    visible=[x for x in records if query.casefold() in (x['description']+x['vendor']).casefold() and (note=='전체' or x['note']==note) and (scope=='전체' or bool(x.get('included',1))==(scope=='포함'))]
    frame=pd.DataFrame(visible)[['id','account','posted_at','description','vendor','amount','note','included','exclusion_reason']]
    with st.form(f'os_ledger_edit_form_{row["id"]}'):
        edited=st.data_editor(frame,hide_index=True,use_container_width=True,height=430,key=f'os_ledger_editor_{row["id"]}',disabled=['id','account','posted_at','description','vendor','amount','exclusion_reason'],column_config={'id':None,'account':'계정과목명','posted_at':'기표일자','description':'적요','vendor':'거래처명','amount':st.column_config.NumberColumn('지출',format='localized'),'note':'비고','included':st.column_config.CheckboxColumn('계산 포함'),'exclusion_reason':'제외 사유'})
        save=st.form_submit_button('원장 수정사항 최종 저장',type='primary')
    if save:
        try:db.save_ledger_edits(c,row['id'],edited.to_dict('records'));st.session_state['_os_notice']=('success','원장 수정사항을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def payroll_tab(c,row):
    uploaded=st.file_uploader('급여현황(사원별) Excel',type=['xlsx','xlsm'],key=f'os_payroll_upload_{row["id"]}')
    if uploaded:
        try:
            parsed=db.parse_payroll(uploaded.getvalue());st.success(f'{len(parsed):,}개 급여 행을 찾았습니다.')
            if st.button('기존 급여자료를 교체하고 업로드',type='primary',key=f'os_payroll_replace_{row["id"]}'):
                db.replace_payroll(c,row['id'],parsed,uploaded.name);st.session_state['_os_notice']=('success',f'급여자료 {len(parsed):,}개 행을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    records=db.payroll(c,row['id'])
    if not records:st.info('등록된 급여자료가 없습니다.');return
    legacy=int(row.get('retirement_pension') or 0)
    if legacy:
        st.warning(f'이전 버전의 미배정 퇴직연금 {_money(legacy)}이 남아 있습니다. 귀속 직원을 선택해 이전하세요.')
        employees={}
        for item in records:employees.setdefault(item['employee'],item['id'])
        a,b=st.columns([3,1]);employee=a.selectbox('기존 퇴직연금 귀속 직원',list(employees),key=f'os_legacy_employee_{row["id"]}')
        if b.button('선택 직원에게 이전',type='primary',use_container_width=True,key=f'os_move_legacy_{row["id"]}'):
            try:db.move_legacy_retirement(c,row['id'],employees[employee],row['version']);st.session_state['_os_notice']=('success',f'기존 퇴직연금을 {employee} 직원에게 이전했습니다.');st.rerun()
            except (ValueError,PermissionError) as exc:st.error(str(exc))
    summary=[]
    for item in records:
        summary.append({'사원':item['employee'],'구분':item['role'],
          '급여':item['salary'] if item.get('reflect_salary',1) else 0,
          '국민연금':item['pension'] if item.get('reflect_pension',1) else 0,
          '건강보험':item['health'] if item.get('reflect_health',1) else 0,
          '장기요양':item['longterm'] if item.get('reflect_longterm',1) else 0,
          '퇴직연금':item.get('retirement_pension',0) if item.get('reflect_retirement',1) else 0})
    grouped=pd.DataFrame(summary).groupby(['사원','구분'],dropna=False)[['급여','국민연금','건강보험','장기요양','퇴직연금']].sum().reset_index()
    grouped['합계금액']=grouped[['급여','국민연금','건강보험','장기요양','퇴직연금']].sum(axis=1)
    st.html('<div class="os-title">사원별 집계·퇴직연금 입력</div>');st.caption('급여·보험은 반영 체크된 금액의 합계입니다. 퇴직연금은 해당 직원 행에 직접 입력한 뒤 저장하세요.')
    with st.form(f'os_employee_retirement_form_{row["id"]}'):
        employee_summary=st.data_editor(grouped,hide_index=True,use_container_width=True,key=f'os_employee_retirement_{row["id"]}',
          disabled=['사원','구분','급여','국민연금','건강보험','장기요양','합계금액'],column_config={'급여':st.column_config.NumberColumn('급여',format='localized'),'국민연금':st.column_config.NumberColumn('국민연금',format='localized'),'건강보험':st.column_config.NumberColumn('건강보험',format='localized'),'장기요양':st.column_config.NumberColumn('장기요양',format='localized'),'퇴직연금':st.column_config.NumberColumn('퇴직연금',format='localized',min_value=0,step=1000),'합계금액':st.column_config.NumberColumn('합계금액',format='localized')})
        retirement_save=st.form_submit_button('직원별 퇴직연금 저장',type='primary')
    if retirement_save:
        try:db.save_employee_retirements(c,row['id'],employee_summary.to_dict('records'));st.session_state['_os_notice']=('success','직원별 퇴직연금을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    totals={name:int(grouped[name].sum()) for name in ['급여','국민연금','건강보험','장기요양','퇴직연금','합계금액']}
    if legacy:totals['퇴직연금']+=legacy;totals['합계금액']+=legacy
    st.dataframe(pd.DataFrame([{'사원':'전체 합계','구분':'',**totals}]),hide_index=True,use_container_width=True,column_config={name:st.column_config.NumberColumn(name,format='localized') for name in totals})
    st.html('<div class="os-title">월별 상세·원장 반영항목</div>')
    frame=pd.DataFrame(records)[['id','employee','role','month','salary','pension','health','longterm','retirement_pension','reflect_salary','reflect_pension','reflect_health','reflect_longterm','reflect_retirement']]
    with st.form(f'os_payroll_edit_form_{row["id"]}'):
        edited=st.data_editor(frame,hide_index=True,use_container_width=True,height=360,key=f'os_payroll_editor_{row["id"]}',disabled=['id','employee','role','month','salary','pension','health','longterm','retirement_pension'],column_config={'id':None,'employee':'사원','role':'구분','month':'귀속연월','salary':st.column_config.NumberColumn('급여',format='localized'),'pension':st.column_config.NumberColumn('국민연금',format='localized'),'health':st.column_config.NumberColumn('건강보험',format='localized'),'longterm':st.column_config.NumberColumn('장기요양',format='localized'),'retirement_pension':st.column_config.NumberColumn('퇴직연금',format='localized'),'reflect_salary':st.column_config.CheckboxColumn('급여 반영'),'reflect_pension':st.column_config.CheckboxColumn('연금 반영'),'reflect_health':st.column_config.CheckboxColumn('건강 반영'),'reflect_longterm':st.column_config.CheckboxColumn('장기요양 반영'),'reflect_retirement':st.column_config.CheckboxColumn('퇴직연금 반영')})
        save=st.form_submit_button('급여 반영항목 최종 저장',type='primary')
    if save:
        try:db.save_payroll_edits(c,row['id'],edited.to_dict('records'));st.session_state['_os_notice']=('success','급여 반영항목을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def output_panel(c,row):
    ledger_rows=db.ledger(c,row['id']);payroll_rows=db.payroll(c,row['id'])
    html=report.print_html(row,ledger_rows,payroll_rows)
    st.download_button('외주정산 보고서 HTML 내려받기',html.encode('utf-8'),file_name=f"{row['project_name']}_외주정산_보고서.html",mime='text/html',type='primary',use_container_width=True)
    with st.expander('보고서 인쇄 미리보기',expanded=False):
        st.caption('제공된 실행내역 검토서·프로젝트별 계정내역현황 양식을 기준으로 구성했습니다. 미리보기 안의 인쇄 / PDF 저장 버튼을 사용하세요.')
        components.html(html,height=1050,scrolling=True)


def render(user=None):
    c=db.connect();_flash();row=_project_header(c)
    _project_form(c,row)
    if not row:
        st.info('공사정보를 먼저 저장하면 내역서·원장·급여 업로드와 정산 계산을 사용할 수 있습니다.');return
    row=db.project(c,row['id'])
    output_panel(c,row)
    menus=['도급정산','도급(변경이 있는 경우)','원장','급여현황(사원별)']
    active=st.radio('외주정산 작업',menus,horizontal=True,key='os_active_menu')
    if active==menus[0]:contract_tab(c,row,False)
    elif active==menus[1]:contract_tab(c,row,True)
    elif active==menus[2]:ledger_tab(c,row)
    else:payroll_tab(c,row)

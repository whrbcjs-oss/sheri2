Sheri2 외주정산 전체 펼침표 개선 2026.11.24.62

왼쪽 산출내역 소과목과 오른쪽 전체 공제과목을 스크롤 없이 펼치고 양쪽 표 높이를 동일하게 맞춥니다.

1. 실행 중인 모든 Sheri2 검은색 서버 창을 닫습니다.
2. UPDATE_PROGRAM.bat을 실행합니다.
3. 평소 실행할 때 사용하는 start.bat 파일을 선택합니다.
4. 완료 화면의 Patched runtime 경로를 확인합니다.
5. 선택했던 기존 start.bat을 실행합니다.

이 설치기는 선택한 폴더뿐 아니라 start.bat이 참조하는 경로와 하위 실행 폴더를 확인합니다.
실제 실행본의 app_navigation.py와 multiuser_app.py에 외주정산 메뉴를 반영합니다.

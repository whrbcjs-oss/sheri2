Sheri2 login password minimum update 2026.11.19.40

This changes the minimum length for a new login password from 12 to 8 characters. Existing accounts and passwords remain valid. Password hashing, lockout protection, databases, and entered records are unchanged.

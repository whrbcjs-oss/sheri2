"""Lower the login-password minimum from 12 to 8 without replacing operating code."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import sys

FILES = ["collaboration.py", "multiuser_app.py", "app_navigation.py"]


def changed_sources(target):
    paths = {name: target / name for name in FILES}
    for name,path in paths.items():
        if not path.is_file():raise ValueError("필수 프로그램 파일이 없습니다: " + name)
    collaboration = paths["collaboration.py"].read_text(encoding="utf-8")
    multiuser = paths["multiuser_app.py"].read_text(encoding="utf-8")
    navigation = paths["app_navigation.py"].read_text(encoding="utf-8")

    already = "if len(password) < 8:" in collaboration and "새 비밀번호 (8자 이상)" in multiuser and "2026.11.19.40" in navigation
    if already:return {name:paths[name].read_text(encoding="utf-8") for name in FILES}
    if collaboration.count("if len(password) < 12:") != 1 or "비밀번호는 12자 이상 입력하세요." not in collaboration:
        raise ValueError("로그인 비밀번호 검사 코드가 예상한 운영본과 다릅니다. 아무 파일도 변경하지 않았습니다.")
    if multiuser.count("(12자 이상)") < 2:
        raise ValueError("로그인 비밀번호 화면 문구가 예상한 운영본과 다릅니다. 아무 파일도 변경하지 않았습니다.")
    if navigation.count("2026.11.19.39") != 2:
        raise ValueError("먼저 2026.11.19.39 업데이트를 적용하세요. 아무 파일도 변경하지 않았습니다.")

    collaboration = collaboration.replace("if len(password) < 12:", "if len(password) < 8:")
    collaboration = collaboration.replace("12자 이상", "8자 이상")
    multiuser = multiuser.replace("(12자 이상)", "(8자 이상)")
    navigation = navigation.replace("2026.11.19.39", "2026.11.19.40")
    return {"collaboration.py":collaboration,"multiuser_app.py":multiuser,"app_navigation.py":navigation}


def update(target):
    target = Path(target).expanduser().resolve()
    if target.is_file():target = target.parent
    if not (target / "start.bat").is_file():raise ValueError("현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.")
    output = changed_sources(target)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    backup = target / "private" / "code-updates" / stamp
    backup.mkdir(parents=True)
    manifest = {}
    for name in FILES:
        path=target/name;manifest[name]=hashlib.sha256(path.read_bytes()).hexdigest();shutil.copy2(path,backup/name)
    (backup/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")

    installed=[]
    try:
        for name in FILES:
            destination=target/name;temporary=target/(name+".update-"+secrets.token_hex(4))
            try:
                temporary.write_text(output[name],encoding="utf-8")
                compile(output[name],name,"exec")
                temporary.replace(destination);installed.append(name)
            finally:temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed):shutil.copy2(backup/name,target/name)
        raise
    check=(target/"collaboration.py").read_text(encoding="utf-8")
    if "if len(password) < 8:" not in check or "비밀번호는 8자 이상 입력하세요." not in check:raise ValueError("설치 후 비밀번호 검사 확인에 실패했습니다.")
    print("로그인 비밀번호 최소 길이 8자 변경 완료:",target)
    print("기존 코드 백업:",backup)
    print("기존 계정과 비밀번호, DB 및 입력자료는 변경하지 않았습니다.")


def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes("-topmost",True)
        return filedialog.askopenfilename(parent=window,title="39버전 프로그램의 start.bat을 선택하세요",filetypes=[("start.bat","start.bat")])
    finally:
        if window:window.destroy()


if __name__=="__main__":
    try:
        value=choose_target()
        if not value:raise ValueError("취소했습니다. 아무 파일도 변경하지 않았습니다.")
        update(value)
    except Exception as error:raise SystemExit("업데이트 실패: "+str(error))

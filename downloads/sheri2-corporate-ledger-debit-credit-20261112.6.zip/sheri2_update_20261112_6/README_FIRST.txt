Sheri2 corporate ledger debit-credit update 2026.11.12.6

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

This update preserves company databases, accounts, ledgers, attachments and closing data.
The application screen and reports remain in Korean.

After updating, open 법인결산 > 소득구분계산서 > 원장 업로드·적요 분류.
If the legacy-data warning appears, click 기존 원장 차변·대변 기준 재계산 once.

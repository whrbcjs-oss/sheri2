"""Install the approved corporate tax-flow layout update while preserving private data."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib,json,secrets,shutil,sys
ROOT=Path(__file__).resolve().parent
FILES=["corporate_close_app.py","corporate_close_calc.py","corporate_close_import.py","corporate_close_report.py","corporate_close_store.py","app_navigation.py","docs/법인결산_사용안내.md"]
def update(target):
 target=Path(target).expanduser().resolve()
 if target.is_file():target=target.parent
 if target==ROOT:raise ValueError("기존 start.bat이 있는 프로그램 폴더를 선택하세요.")
 if not (target/"start.bat").is_file() or not (target/"corporate_close_store.py").is_file():raise ValueError("법인결산 2026.11.10.2 이상이 설치된 기존 프로그램 폴더가 아닙니다.")
 nav=target/"app_navigation.py"
 if not nav.is_file() or not any(v in nav.read_text(encoding="utf-8") for v in ["2026.11.10.2","2026.11.10.3","2026.11.10.4","2026.11.10.5","2026.11.10.6","2026.11.11.1","2026.11.11.2","2026.11.11.3","2026.11.11.4"]):raise ValueError("2026.11.10.2 이상 설치 폴더에 적용해 주세요.")
 for name in FILES:
  if not (ROOT/name).is_file():raise ValueError("업데이트 파일 누락: "+name)
 stamp=datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")+"-"+secrets.token_hex(3);backup=target/"private"/"code-updates"/stamp;backup.mkdir(parents=True)
 manifest={}
 for name in FILES:
  path=target/name;manifest[name]=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
  if path.exists():(backup/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,backup/name)
 (backup/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
 installed=[]
 try:
  for name in FILES:
   path=target/name;path.parent.mkdir(parents=True,exist_ok=True);tmp=target/(name+".update-"+secrets.token_hex(4))
   try:tmp.write_bytes((ROOT/name).read_bytes());tmp.replace(path);installed.append(name)
   finally:tmp.unlink(missing_ok=True)
 except BaseException:
  for name in reversed(installed):
   if manifest[name] is None:(target/name).unlink(missing_ok=True)
   else:shutil.copy2(backup/name,target/name)
  raise
 print("법인세 흐름표 업데이트 완료:",target);print("기존 코드 백업:",backup);print("회사 DB와 입력자료는 변경하지 않았습니다.")
def choose_target():
 if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
 window=None
 try:
  import tkinter as tk
  from tkinter import filedialog
  window=tk.Tk();window.withdraw();window.attributes("-topmost",True)
  return filedialog.askopenfilename(parent=window,title="기존 프로그램의 start.bat을 선택하세요",filetypes=[("start.bat","start.bat")])
 finally:
  if window:window.destroy()
if __name__=="__main__":
 try:
  value=choose_target()
  if not value:raise ValueError("취소했습니다.")
  update(value)
 except Exception as e:raise SystemExit("업데이트 실패: "+str(e))

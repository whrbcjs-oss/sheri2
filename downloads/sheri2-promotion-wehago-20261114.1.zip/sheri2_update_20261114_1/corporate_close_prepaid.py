"""Extract contract periods from ledger descriptions and calculate prepaid expenses."""
import hashlib,re
from datetime import date,datetime

DATE_RE=re.compile(r'(?<!\d)(\d{2,4})[.\-/](\d{1,2})[.\-/](\d{1,2})(?!\d)')
VEHICLE_WORDS=('책임','종합보험료','책임보험료','차량보험료','보험료')
RENT_WORDS=('부지임차료','야적장 토지임차료','야적장임차료','토지임차료')

def _date(match):
    year=int(match.group(1));year=2000+year if year<100 else year
    return date(year,int(match.group(2)),int(match.group(3)))
def _identifier(text,first_date,kind):
    prefix=text[:first_date.start()];start=max(prefix.rfind('('),prefix.rfind('（'))
    value=prefix[start+1:] if start>=0 else prefix
    value=re.sub(r'^[\s:：,，.-]+|[\s:：,，.-]+$','',value)
    for word in (*VEHICLE_WORDS,*RENT_WORDS):value=value.replace(word,'')
    value=re.sub(r'^[\s:：,，.-]+|[\s:：,，.-]+$','',value)
    return value or ('차량번호 확인' if kind.startswith('보험료') else '지번 확인')
def source_key(kind,row):
    raw='|'.join(str(row.get(k,'') or '') for k in ['date','account','description','debit','amount'])
    return hashlib.sha256((kind+'|'+raw).encode()).hexdigest()[:24]
def extract(kind,row,year):
    text=str(row.get('description') or '').strip();matches=list(DATE_RE.finditer(text));start=end=None
    if len(matches)>=2:
        try:start,end=_date(matches[0]),_date(matches[1])
        except ValueError:start=end=None
    identifier=_identifier(text,matches[0],kind) if matches else ('차량번호 확인' if kind.startswith('보험료') else '지번 확인')
    amount=row.get('debit') if row.get('debit') is not None else row.get('amount',0)
    return {'source_key':source_key(kind,row),'ledger_row_id':row.get('id'),'kind':kind,'description':text,'identifier':identifier,'site':row.get('business',''),'counterparty':row.get('counterparty',''),'amount':int(amount or 0),'start':start.isoformat() if start else '','end':end.isoformat() if end else '','opening':0,'note':'','valid':bool(start and end and end>=start)}
def parse_day(value):
    if isinstance(value,datetime):return value.date()
    if isinstance(value,date):return value
    text=str(value or '').strip().replace('.','-').replace('/','-')
    try:return date.fromisoformat(text)
    except ValueError:return None
def calculate(item,year):
    start=parse_day(item.get('start'));end=parse_day(item.get('end'));amount=max(0,int(item.get('amount') or 0));opening=max(0,int(item.get('opening') or 0));cutoff=date(int(year)+1,1,1)
    if not start or not end or end<start:return {**item,'opening':opening,'amount':amount,'total_days':0,'prepaid_start':'','prepaid_end':'','prepaid_days':0,'ending':0,'current_expense':amount,'combined':opening+amount,'valid':False}
    total=(end-start).days+1;prepaid_start=max(start,cutoff);prepaid_days=max(0,(end-prepaid_start).days+1) if end>=prepaid_start else 0;ending=(amount*prepaid_days)//total if total else 0
    current_expense=amount-ending
    return {**item,'opening':opening,'amount':amount,'total_days':total,'prepaid_start':prepaid_start.isoformat() if prepaid_days else '','prepaid_end':end.isoformat() if prepaid_days else '','prepaid_days':prepaid_days,'ending':ending,'current_expense':current_expense,'combined':opening+current_expense,'valid':True}
def build(current_rows,prior_closing,overrides,year):
    result=[];seen=set()
    for row in current_rows:
        item=extract(row['kind'],row,year);key=item['source_key'];item.update(overrides.get(key,{}));seen.add(key);result.append(calculate(item,year))
    # Carry every prior closing item independently. This avoids merging two
    # policies for the same vehicle or two leases for the same parcel.
    for old in prior_closing or []:
        if not int(old.get('ending') or 0):continue
        key='carry:'+str(old.get('source_key') or hashlib.sha256(str(old).encode()).hexdigest()[:24])
        item={'source_key':key,'ledger_row_id':None,'kind':old['kind'],'description':old.get('description','전기 선급비용 이월'),'identifier':old.get('identifier',''),'site':old.get('site',''),'counterparty':old.get('counterparty',''),'amount':0,'start':'','end':'','opening':int(old['ending']),'note':'전년도 자동이월','valid':True};item.update(overrides.get(key,{}));result.append(calculate(item,year));seen.add(key)
    return result
def summary(items):
    out={k:{'opening':0,'amount':0,'ending':0,'current_expense':0} for k in ['보험료(원가)','보험료(판관비)','지급임차료(원가)']}
    for r in items:
        z=out[r['kind']]
        for key in z:z[key]+=int(r.get(key) or 0)
    return out
def grouped(items):
    groups={}
    for r in items:
        key=(r['kind'],r.get('identifier',''))
        if key not in groups:groups[key]={**r,'contract_count':0,'source_keys':[],'descriptions':[],'starts':[],'ends':[],'opening':0,'amount':0,'ending':0,'current_expense':0,'combined':0,'valid':True}
        g=groups[key];g['contract_count']+=1;g['source_keys'].append(r['source_key']);g['descriptions'].append(r.get('description',''))
        if r.get('start'):g['starts'].append(r['start'])
        if r.get('end'):g['ends'].append(r['end'])
        for field in ['opening','amount','ending','current_expense','combined']:g[field]+=int(r.get(field) or 0)
        g['valid']=g['valid'] and bool(r.get('valid'))
    out=[]
    for g in groups.values():
        same_period=len(set(g['starts']))<=1 and len(set(g['ends']))<=1
        g['start']=g['starts'][0] if g['starts'] and same_period else '개별계산'
        g['end']=g['ends'][0] if g['ends'] and same_period else '개별계산'
        g['total_days']=g.get('total_days',0) if g['contract_count']==1 else 0
        g['prepaid_start']=g.get('prepaid_start','') if g['contract_count']==1 else '개별계산'
        g['prepaid_end']=g.get('prepaid_end','') if g['contract_count']==1 else '개별계산'
        g['prepaid_days']=g.get('prepaid_days',0) if g['contract_count']==1 else 0
        out.append(g)
    return out

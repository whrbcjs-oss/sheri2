"""Storage, Excel import and calculation helpers for subcontract settlements."""
from __future__ import annotations

import io
import json
import re
from datetime import date, datetime
from pathlib import Path

import pandas as pd

import collaboration as shared


INSURANCE_WORDS = (
    '산재보험', '고용보험', '건강보험', '국민연금', '퇴직공제부금',
    '건설하도급지급보증', '건설기계보증수수료',
)
SETTLEMENT_ALIASES = {
    '산재보험': ('산재보험', '산재보험료'),
    '고용보험': ('고용보험', '고용보험료'),
    '건강보험': ('건강보험', '건강보험료'),
    '국민연금': ('국민연금', '연금보험', '연금보험료'),
    '노인장기요양보험료': ('노인장기요양보험', '장기요양보험', '장기요양보험료'),
    '퇴직공제부금': ('퇴직공제부금', '퇴직공제부금비'),
    '산업안전보건관리비': ('산업안전보건관리비', '안전보건관리비'),
    '기타경비': ('기타경비',),
    '건설기계보증수수료': ('건설기계대여금지급보증', '건설기계보증수수료', '건기대보증'),
    '건설하도급지급보증': ('건설하도급대금지급보증', '하도급대금지급보증', '건설하도급지급보증'),
    '환경보전비': ('환경보전비',),
    '안전관리비': ('안전관리비',),
    '품질관리비': ('품질관리비',),
    '기술사용료': ('기술사용료',),
}
SETTLEMENT_HINTS = ('보험','연금','부금','관리비','경비','보증','보전비','수수료','사용료')
LEDGER_ALIASES = {
    'account': ('계정과목명', '계정과목', '계정명'),
    'posted_at': ('기표일자', '일자', '거래일자'),
    'description': ('적요', '내용', '품명'),
    'vendor': ('거래처명', '거래처', '업체명'),
    'amount': ('지출', '금액', '출금액', '공급가액'),
    'note': ('비고', '구분'),
}
PAYROLL_ALIASES = {
    'employee_code': ('사원코드', '사번'), 'role': ('구분', '직책'), 'employee': ('사원', '성명'),
    'hire_date': ('입사일',), 'retire_date': ('퇴직일',), 'company': ('사업장', '회사'),
    'project': ('프로젝트', '현장명'), 'month': ('귀속연월', '급여월'), 'salary': ('급여합계', '급여총액'),
    'pension': ('국민연금',), 'health': ('건강보험',), 'longterm': ('장기요양보험료', '장기요양 보험료', '장기요양'),
    'retirement_pension': ('퇴직연금', '퇴직 연금'),
}


def rows(c, sql, args=()):
    cur = c.execute(sql, args)
    names = [item[0] for item in cur.description]
    return [dict(zip(names, row)) for row in cur]


def connect():
    shared.DATA.mkdir(parents=True, exist_ok=True)
    c = shared.connect(shared.DATA / 'outsource_settlement.db')
    ctx = shared.RUN.get()
    actor = ctx['user']['username'] if ctx else 'system'
    c.create_function('current_actor', 0, lambda: actor)
    c.executescript('''
    CREATE TABLE IF NOT EXISTS os_projects(
      id INTEGER PRIMARY KEY, company_name TEXT NOT NULL DEFAULT '', project_name TEXT NOT NULL,
      contractor TEXT NOT NULL DEFAULT '', written_at TEXT NOT NULL DEFAULT '', contract_date TEXT NOT NULL DEFAULT '',
      start_date TEXT NOT NULL DEFAULT '', end_date TEXT NOT NULL DEFAULT '', client_name TEXT NOT NULL DEFAULT '',
      contract_amount INTEGER NOT NULL DEFAULT 0, levy_rate REAL NOT NULL DEFAULT 0,
      original_contract_amount INTEGER NOT NULL DEFAULT 0, original_levy_rate REAL NOT NULL DEFAULT 0,
      original_items_json TEXT NOT NULL DEFAULT '[]', changed_items_json TEXT NOT NULL DEFAULT '[]',
      receipts_json TEXT NOT NULL DEFAULT '[]', reserve_amount INTEGER NOT NULL DEFAULT 0,
      public_adjustment INTEGER NOT NULL DEFAULT 0, retirement_pension INTEGER NOT NULL DEFAULT 0,
      version INTEGER NOT NULL DEFAULT 1, deleted INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS os_ledger(
      id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, account TEXT NOT NULL DEFAULT '', posted_at TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '', vendor TEXT NOT NULL DEFAULT '', amount INTEGER NOT NULL DEFAULT 0,
      note TEXT NOT NULL DEFAULT '', payment TEXT NOT NULL DEFAULT '', source_row INTEGER NOT NULL DEFAULT 0,
      included INTEGER NOT NULL DEFAULT 1, exclusion_reason TEXT NOT NULL DEFAULT '',
      version INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(project_id) REFERENCES os_projects(id) ON DELETE CASCADE);
    CREATE INDEX IF NOT EXISTS os_ledger_project ON os_ledger(project_id,id);
    CREATE TABLE IF NOT EXISTS os_payroll(
      id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, employee_code TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT '',
      employee TEXT NOT NULL DEFAULT '', hire_date TEXT NOT NULL DEFAULT '', retire_date TEXT NOT NULL DEFAULT '',
      company TEXT NOT NULL DEFAULT '', project TEXT NOT NULL DEFAULT '', month TEXT NOT NULL DEFAULT '',
      salary INTEGER NOT NULL DEFAULT 0, pension INTEGER NOT NULL DEFAULT 0, health INTEGER NOT NULL DEFAULT 0,
      longterm INTEGER NOT NULL DEFAULT 0, retirement_pension INTEGER NOT NULL DEFAULT 0, reflect_salary INTEGER NOT NULL DEFAULT 1,
      reflect_pension INTEGER NOT NULL DEFAULT 1, reflect_health INTEGER NOT NULL DEFAULT 1,
      reflect_longterm INTEGER NOT NULL DEFAULT 1, reflect_retirement INTEGER NOT NULL DEFAULT 1, version INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY(project_id) REFERENCES os_projects(id) ON DELETE CASCADE);
    CREATE INDEX IF NOT EXISTS os_payroll_project ON os_payroll(project_id,id);
    CREATE TABLE IF NOT EXISTS os_imports(
      id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, kind TEXT NOT NULL, filename TEXT NOT NULL,
      row_count INTEGER NOT NULL DEFAULT 0, imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(project_id) REFERENCES os_projects(id) ON DELETE CASCADE);
    ''')
    ledger_columns={item[1] for item in c.execute('PRAGMA table_info(os_ledger)')}
    added_inclusion='included' not in ledger_columns
    if added_inclusion:c.execute('ALTER TABLE os_ledger ADD COLUMN included INTEGER NOT NULL DEFAULT 1')
    if 'exclusion_reason' not in ledger_columns:c.execute("ALTER TABLE os_ledger ADD COLUMN exclusion_reason TEXT NOT NULL DEFAULT ''")
    if added_inclusion:
        existing=rows(c,'SELECT id,account,posted_at,description,vendor,amount,note,payment FROM os_ledger')
        for item in existing:
            reason=_ledger_exclusion(item)
            c.execute('UPDATE os_ledger SET included=?,exclusion_reason=? WHERE id=?',(0 if reason else 1,reason,item['id']))
    payroll_columns={item[1] for item in c.execute('PRAGMA table_info(os_payroll)')}
    if 'retirement_pension' not in payroll_columns:
        c.execute('ALTER TABLE os_payroll ADD COLUMN retirement_pension INTEGER NOT NULL DEFAULT 0')
    if 'reflect_retirement' not in payroll_columns:
        c.execute('ALTER TABLE os_payroll ADD COLUMN reflect_retirement INTEGER NOT NULL DEFAULT 1')
    c.commit()
    return shared.protect(c)


def company_names():
    try:
        import corporate_close_store as corporate
        c = corporate.connect()
        try:
            names = [row['name'] for row in corporate.companies(c)]
        finally:
            c.close()
        if names:
            return names
    except Exception:
        pass
    return ['다혜건설㈜', '㈜효성', '㈜효성전문', '㈜한길', '㈜효성엘비데크']


def projects(c, include_deleted=False):
    sql = 'SELECT * FROM os_projects'
    if not include_deleted:
        sql += ' WHERE deleted=0'
    return rows(c, sql + ' ORDER BY updated_at DESC,id DESC')


def project(c, project_id):
    found = rows(c, 'SELECT * FROM os_projects WHERE id=? AND deleted=0', (int(project_id),))
    return found[0] if found else None


def _text(value, limit=500):
    value = '' if value is None else str(value).strip()
    if len(value) > limit:
        raise ValueError('입력값이 너무 깁니다.')
    return value


def _date_text(value):
    if value in (None, ''):
        return ''
    if isinstance(value, (date, datetime)):
        return value.strftime('%Y-%m-%d')
    return _text(value, 20)


def money(value):
    if value in (None, ''):
        return 0
    try:
        if pd.isna(value):
            return 0
    except (TypeError, ValueError):
        pass
    text = str(value).replace(',', '').replace('원', '').replace('₩', '').strip()
    negative = text.startswith('(') and text.endswith(')')
    text = text.strip('()')
    try:
        result = int(round(float(text or 0)))
    except (TypeError, ValueError) as exc:
        raise ValueError(f'금액을 확인하세요: {value}') from exc
    return -result if negative else result


def save_project(c, values, project_id=None, expected=None):
    name = _text(values.get('project_name'), 250)
    if not name:
        raise ValueError('공사명을 입력하세요.')
    keys = ('company_name','contractor','client_name')
    clean = {key: _text(values.get(key), 250) for key in keys}
    dates = {key: _date_text(values.get(key)) for key in ('written_at','contract_date','start_date','end_date')}
    amounts = {key: money(values.get(key)) for key in ('contract_amount','original_contract_amount','reserve_amount','public_adjustment','retirement_pension')}
    rates = {key: float(values.get(key) or 0) for key in ('levy_rate','original_levy_rate')}
    if not 0 <= rates['levy_rate'] <= 100 or not 0 <= rates['original_levy_rate'] <= 100:
        raise ValueError('부금율은 0~100% 사이로 입력하세요.')
    with c:
        if project_id:
            current = project(c, project_id)
            if not current or current['version'] != int(expected):
                raise ValueError('다른 작업자가 공사정보를 변경했습니다. 다시 불러오세요.')
            changed = c.execute('''UPDATE os_projects SET company_name=?,project_name=?,contractor=?,written_at=?,contract_date=?,
              start_date=?,end_date=?,client_name=?,contract_amount=?,levy_rate=?,original_contract_amount=?,original_levy_rate=?,
              reserve_amount=?,public_adjustment=?,retirement_pension=?,version=version+1,updated_at=CURRENT_TIMESTAMP
              WHERE id=? AND version=?''', (clean['company_name'],name,clean['contractor'],dates['written_at'],dates['contract_date'],
              dates['start_date'],dates['end_date'],clean['client_name'],amounts['contract_amount'],rates['levy_rate'],
              amounts['original_contract_amount'],rates['original_levy_rate'],amounts['reserve_amount'],amounts['public_adjustment'],
              amounts['retirement_pension'],int(project_id),int(expected))).rowcount
            if changed != 1:
                raise ValueError('공사정보가 변경되었습니다. 다시 불러오세요.')
            return int(project_id)
        return c.execute('''INSERT INTO os_projects(company_name,project_name,contractor,written_at,contract_date,start_date,end_date,
          client_name,contract_amount,levy_rate,original_contract_amount,original_levy_rate,reserve_amount,public_adjustment,retirement_pension)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(clean['company_name'],name,clean['contractor'],dates['written_at'],dates['contract_date'],
          dates['start_date'],dates['end_date'],clean['client_name'],amounts['contract_amount'],rates['levy_rate'],
          amounts['original_contract_amount'],rates['original_levy_rate'],amounts['reserve_amount'],amounts['public_adjustment'],
          amounts['retirement_pension'])).lastrowid


def delete_project(c, project_id, expected):
    current = project(c, project_id)
    if not current or current['version'] != int(expected):
        raise ValueError('공사정보가 변경되었습니다. 다시 불러오세요.')
    with c:
        c.execute('UPDATE os_projects SET deleted=1,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',(int(project_id),))


def json_items(row, kind):
    key = 'original_items_json' if kind == 'original' else 'changed_items_json'
    try:
        return json.loads(row.get(key) or '[]')
    except (TypeError, json.JSONDecodeError):
        return []


def save_items(c, project_id, kind, items, expected):
    if kind not in ('original','changed'):
        raise ValueError('내역서 구분이 올바르지 않습니다.')
    current = project(c, project_id)
    if not current or current['version'] != int(expected):
        raise ValueError('공사정보가 변경되었습니다. 다시 불러오세요.')
    normalized=[]
    for item in items:
        name=_text(item.get('항목'),200)
        if not name: continue
        normalized.append({'항목':name,'금액':money(item.get('금액')),'반영':bool(item.get('반영'))})
    key = 'original_items_json' if kind == 'original' else 'changed_items_json'
    with c:
        c.execute(f'UPDATE os_projects SET {key}=?,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                  (json.dumps(normalized,ensure_ascii=False),int(project_id)))


def save_receipts(c, project_id, receipts, expected):
    current=project(c,project_id)
    if not current or current['version']!=int(expected):
        raise ValueError('공사정보가 변경되었습니다. 다시 불러오세요.')
    cleaned=[]
    for item in receipts:
        if not any(str(item.get(key,'')).strip() for key in ('일자','내역','금액')): continue
        cleaned.append({'일자':_date_text(item.get('일자')),'내역':_text(item.get('내역'),200),'금액':money(item.get('금액'))})
    with c:
        c.execute('UPDATE os_projects SET receipts_json=?,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                  (json.dumps(cleaned,ensure_ascii=False),int(project_id)))


def receipts(row):
    try:return json.loads(row.get('receipts_json') or '[]')
    except (TypeError,json.JSONDecodeError):return []


def _sheet_frames(payload):
    book=pd.ExcelFile(io.BytesIO(payload))
    for sheet in book.sheet_names:
        yield sheet,pd.read_excel(book,sheet_name=sheet,header=None,dtype=object)


def _norm(value):
    return ''.join(ch for ch in str(value or '').casefold() if ch.isalnum())


LEDGER_EXCLUDE_WORDS = ('소계', '합계', '전월이월', '누계')


def _ledger_exclusion(item):
    """Return the automatic exclusion reason for a ledger row."""
    fields = ('account', 'posted_at', 'description', 'vendor', 'note')
    joined = _norm(' '.join(str(item.get(key) or '') for key in fields))
    for word in LEDGER_EXCLUDE_WORDS:
        if _norm(word) in joined:
            return word
    has_value = any(str(item.get(key) or '').strip() for key in fields) or bool(money(item.get('amount')))
    return '' if has_value else '빈 행'


def _find_header(frame, aliases):
    wanted={_norm(v) for values in aliases.values() for v in values}
    best=(-1,-1)
    for index in range(min(len(frame),60)):
        score=sum(_norm(value) in wanted for value in frame.iloc[index].tolist())
        if score>best[0]:best=(score,index)
    return best[1] if best[0]>=2 else None


def _column_map(columns, aliases):
    result={}
    for key,choices in aliases.items():
        normalized={_norm(choice) for choice in choices}
        for column in columns:
            if _norm(column) in normalized:
                result[key]=column;break
    return result


def parse_contract(payload):
    sheet_candidates=[]
    aliases={name:tuple(_norm(alias) for alias in values) for name,values in SETTLEMENT_ALIASES.items()}
    for sheet,frame in _sheet_frames(payload):
        candidates=[]
        for row_index,row in frame.iterrows():
            cells=[value for value in row.tolist() if value not in (None,'') and not (isinstance(value,float) and pd.isna(value))]
            if len(cells)<2:continue
            text=next((str(value).strip() for value in cells if isinstance(value,str) and str(value).strip()),'')
            numeric=[]
            for value in cells:
                try:
                    parsed=money(value)
                    if parsed:numeric.append(parsed)
                except ValueError:pass
            normalized=_norm(text)
            if '일반관리비' in normalized:break
            if not text or not numeric or '계산방법' in normalized or any(word in normalized for word in ('소계','합계','총계')):continue
            # Quantity rows usually contain the number 1 even when the amount is blank.
            amounts=[value for value in numeric if abs(value)>1]
            if not amounts:continue
            name=next((canonical for canonical,words in aliases.items() if any(word and word in normalized for word in words)),None)
            if name is None:
                looks_like_cost=any(_norm(hint) in normalized for hint in SETTLEMENT_HINTS)
                marked_item=str(text).lstrip().startswith(('-', '–', '—', 'ㆍ', '·'))
                if not (looks_like_cost or marked_item):continue
                name=re.sub(r'^[\s\-–—ㆍ·☞]+','',str(text)).strip()
                name=re.sub(r'\s+',' ',name)
            candidates.append({'항목':name,'금액':amounts[-1],'반영':True,'시트':sheet,'원본행':int(row_index)+1})
        merged={}
        for item in candidates:
            if item['항목'] not in merged:merged[item['항목']]=item
        if merged:sheet_candidates.append((len(merged),sheet,list(merged.values())))
    if not sheet_candidates:
        raise ValueError('내역서에서 보험·실비정산 항목을 찾지 못했습니다. 항목명과 금액 열을 확인하세요.')
    # Prefer the detail sheet containing the most distinct settlement items.
    # Do not overwrite a correct amount with the same label found later on a summary sheet.
    sheet_candidates.sort(key=lambda item:item[0],reverse=True)
    return sheet_candidates[0][2]


def _records_from_excel(payload, aliases):
    best=None
    for sheet,frame in _sheet_frames(payload):
        header=_find_header(frame,aliases)
        if header is None:continue
        data=frame.iloc[header+1:].copy();data.columns=[str(value).strip() for value in frame.iloc[header].tolist()]
        mapping=_column_map(data.columns,aliases)
        score=len(mapping)
        if best is None or score>best[0]:best=(score,sheet,data,mapping,header)
    if not best:raise ValueError('업로드 파일에서 필요한 제목행을 찾지 못했습니다.')
    return best[1:]


def parse_ledger(payload):
    sheet,data,mapping,header=_records_from_excel(payload,LEDGER_ALIASES)
    required=('account','posted_at','description','vendor','amount')
    if any(key not in mapping for key in required):raise ValueError('원장에 계정과목명·기표일자·적요·거래처명·지출 열이 필요합니다.')
    result=[]
    for offset,record in data.iterrows():
        value=record.get(mapping['amount'])
        try:amount=money(value)
        except ValueError:continue
        fields={key:record.get(column,'') for key,column in mapping.items()}
        clean={'account':_text(fields.get('account'),200),'posted_at':_date_text(fields.get('posted_at')),
          'description':_text(fields.get('description'),500),'vendor':_text(fields.get('vendor'),250),'amount':amount,
          'note':_text(fields.get('note'),150),'payment':_text(fields.get('payment'),150),'source_row':int(offset)+2}
        if not any((clean['account'],clean['posted_at'],clean['description'],clean['vendor'],clean['amount'],clean['note'],clean['payment'])):continue
        raw_payment=clean['payment']
        clean['payment']='미지급' if '미지급' in raw_payment else ('지급' if raw_payment else '')
        reason=_ledger_exclusion(clean);clean['included']=not bool(reason);clean['exclusion_reason']=reason
        result.append(clean)
    if not result:raise ValueError('원장에서 지출내역을 찾지 못했습니다.')
    return result


def replace_ledger(c,project_id,records,filename):
    with c:
        c.execute('DELETE FROM os_ledger WHERE project_id=?',(int(project_id),))
        c.executemany('''INSERT INTO os_ledger(project_id,account,posted_at,description,vendor,amount,note,payment,source_row,included,exclusion_reason)
          VALUES(?,?,?,?,?,?,?,?,?,?,?)''',[(int(project_id),r['account'],r['posted_at'],r['description'],r['vendor'],r['amount'],r['note'],r['payment'],r['source_row'],int(bool(r.get('included',True))),r.get('exclusion_reason','')) for r in records])
        c.execute('INSERT INTO os_imports(project_id,kind,filename,row_count) VALUES(?,?,?,?)',(int(project_id),'원장',_text(filename,250),len(records)))
        c.execute('UPDATE os_projects SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',(int(project_id),))


def ledger(c,project_id):return rows(c,'SELECT * FROM os_ledger WHERE project_id=? ORDER BY posted_at,id',(int(project_id),))


def save_ledger_edits(c,project_id,edited):
    current={row['id']:row for row in ledger(c,project_id)}
    with c:
        for item in edited:
            item_id=int(item['id']);old=current.get(item_id)
            if not old:continue
            included=int(bool(item.get('included')))
            reason='' if included else (_text(item.get('exclusion_reason'),150) or '작업자 제외')
            changed=c.execute('''UPDATE os_ledger SET note=?,included=?,exclusion_reason=?,version=version+1
              WHERE id=? AND version=?''',(_text(item.get('note'),150),included,reason,item_id,int(old['version']))).rowcount
            if changed!=1:raise ValueError('원장 자료가 변경되었습니다. 최신 자료를 다시 불러오세요.')
        c.execute('UPDATE os_projects SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',(int(project_id),))


def parse_payroll(payload):
    sheet,data,mapping,header=_records_from_excel(payload,PAYROLL_ALIASES)
    if 'employee' not in mapping or 'salary' not in mapping:raise ValueError('급여파일에 사원과 급여합계 열이 필요합니다.')
    result=[]
    for offset,record in data.iterrows():
        employee=_text(record.get(mapping['employee']),150)
        if not employee or '소계' in employee or employee=='합계':continue
        row={key:record.get(column,'') for key,column in mapping.items()}
        result.append({'employee_code':_text(row.get('employee_code'),80),'role':_text(row.get('role'),120),'employee':employee,
          'hire_date':_date_text(row.get('hire_date')),'retire_date':_date_text(row.get('retire_date')),
          'company':_text(row.get('company'),200),'project':_text(row.get('project'),250),'month':_date_text(row.get('month')),
          'salary':money(row.get('salary')),'pension':money(row.get('pension')),'health':money(row.get('health')),'longterm':money(row.get('longterm')),
          'retirement_pension':money(row.get('retirement_pension'))})
    if not result:raise ValueError('급여파일에서 사원별 자료를 찾지 못했습니다.')
    return result


def replace_payroll(c,project_id,records,filename):
    with c:
        c.execute('DELETE FROM os_payroll WHERE project_id=?',(int(project_id),))
        c.executemany('''INSERT INTO os_payroll(project_id,employee_code,role,employee,hire_date,retire_date,company,project,month,
          salary,pension,health,longterm,retirement_pension) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',[(int(project_id),r['employee_code'],r['role'],r['employee'],r['hire_date'],r['retire_date'],r['company'],r['project'],r['month'],r['salary'],r['pension'],r['health'],r['longterm'],r.get('retirement_pension',0)) for r in records])
        c.execute('INSERT INTO os_imports(project_id,kind,filename,row_count) VALUES(?,?,?,?)',(int(project_id),'급여',_text(filename,250),len(records)))
        c.execute('UPDATE os_projects SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',(int(project_id),))


def payroll(c,project_id):return rows(c,'SELECT * FROM os_payroll WHERE project_id=? ORDER BY employee,month,id',(int(project_id),))


def save_payroll_edits(c,project_id,items):
    with c:
        for item in items:
            c.execute('''UPDATE os_payroll SET retirement_pension=?,reflect_salary=?,reflect_pension=?,reflect_health=?,reflect_longterm=?,reflect_retirement=?,version=version+1
              WHERE id=? AND project_id=?''',(money(item.get('retirement_pension')),int(bool(item.get('reflect_salary'))),int(bool(item.get('reflect_pension'))),int(bool(item.get('reflect_health'))),int(bool(item.get('reflect_longterm'))),int(bool(item.get('reflect_retirement'))),int(item['id']),int(project_id)))
        c.execute('UPDATE os_projects SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',(int(project_id),))


def save_employee_retirements(c,project_id,items):
    """Store one retirement-pension total per employee/role group."""
    with c:
        for item in items:
            employee=_text(item.get('사원'),150);role=_text(item.get('구분'),120)
            found=rows(c,'''SELECT id FROM os_payroll WHERE project_id=? AND employee=? AND role=?
              ORDER BY month,id''',(int(project_id),employee,role))
            if not found:continue
            amount=money(item.get('퇴직연금'))
            c.execute('''UPDATE os_payroll SET retirement_pension=0,version=version+1
              WHERE project_id=? AND employee=? AND role=?''',(int(project_id),employee,role))
            c.execute('''UPDATE os_payroll SET retirement_pension=?,reflect_retirement=1,version=version+1
              WHERE id=?''',(amount,int(found[0]['id'])))
        c.execute('UPDATE os_projects SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?',(int(project_id),))


def move_legacy_retirement(c,project_id,payroll_id,expected_version):
    """Move the old project-level manual retirement pension to one employee."""
    with c:
        current=rows(c,'SELECT retirement_pension FROM os_projects WHERE id=? AND deleted=0',(int(project_id),))
        amount=money(current[0]['retirement_pension']) if current else 0
        if not amount:raise ValueError('이전할 기존 퇴직연금 금액이 없습니다.')
        changed=c.execute('''UPDATE os_projects SET retirement_pension=0,version=version+1,updated_at=CURRENT_TIMESTAMP
          WHERE id=? AND version=?''',(int(project_id),int(expected_version))).rowcount
        if changed!=1:raise ValueError('공사정보가 변경되었습니다. 최신 자료를 다시 불러오세요.')
        changed=c.execute('''UPDATE os_payroll SET retirement_pension=retirement_pension+?,reflect_retirement=1,version=version+1
          WHERE id=? AND project_id=?''',(amount,int(payroll_id),int(project_id))).rowcount
        if changed!=1:raise ValueError('선택한 급여자료를 찾지 못했습니다.')


# Compatibility for older callers.
save_payroll_flags=save_payroll_edits


def calculations(row,ledger_rows,payroll_rows,changed=False):
    contract=money(row['contract_amount'])
    supply=int(round(contract/1.1)) if contract else 0
    vat=contract-supply
    items=json_items(row,'changed' if changed else 'original')
    insurance=sum(money(item.get('금액')) for item in items if item.get('반영'))
    outsource=supply-insurance
    rate=float(row['levy_rate'] or 0)/100
    management=int(outsource*rate)
    execution=(supply-management)//10*10
    active=[r for r in ledger_rows if bool(r.get('included',1))]
    ledger_amount=sum(money(r.get('amount')) for r in active)
    excluded_cost=sum(money(r.get('amount')) for r in active if any(word in str(r.get('note') or '') for word in ('제외','외주업체')))
    settlement_rows=[r for r in active if not any(word in str(r.get('note') or '') for word in ('제외','외주업체'))]
    real_settlement_cost=sum(money(r.get('amount')) for r in settlement_rows)
    unpaid=sum(money(r.get('amount')) for r in settlement_rows if '미지급' in str(r.get('note') or ''))
    direct=real_settlement_cost-unpaid
    purchase_vat=int(sum(r['amount'] for r in active if '외주업체' in str(r.get('note') or ''))*.1)
    selected=[item for item in items if item.get('반영')]
    def estimate(*words):
        keys=[_norm(word) for word in words]
        return sum(money(item.get('금액')) for item in selected if any(key in _norm(item.get('항목')) for key in keys))
    actual_rules={
      '건강보험':('건강보험회사부담금','건강'),
      '국민연금':('국민연금회사부담금','국민연금','연금'),
      '퇴직공제부금':('퇴직공제부금및부가금','퇴직공제부금','퇴직공제'),
      '건설기계보증수수료':('건설기계대여보증수수료','건설기계보증수수료','건기대'),
      '건설하도급지급보증':('하도급대금지급보증수수료','건설하도급지급보증','하도급'),
    }
    paid_actuals={}
    for name,words in actual_rules.items():
        keys=[_norm(word) for word in words]
        paid_actuals[name]=sum(r['amount'] for r in active if any(key in _norm(str(r.get('description') or '')+' '+str(r.get('note') or '')) for key in keys))
    estimates={
      '산재보험':estimate('산재보험'),'고용보험':estimate('고용보험'),
      '건강보험':estimate('건강보험','노인장기요양보험'),
      '국민연금':estimate('국민연금'),'퇴직공제부금':estimate('퇴직공제부금'),
      '건설기계보증수수료':estimate('건설기계보증수수료','건설기계대여금지급보증'),
      '건설하도급지급보증':estimate('건설하도급지급보증','건설하도급대금지급보증'),
    }
    payroll_total=sum((money(r.get('salary')) if r.get('reflect_salary',1) else 0)+
                      (money(r.get('pension')) if r.get('reflect_pension',1) else 0)+
                      (money(r.get('health')) if r.get('reflect_health',1) else 0)+
                      (money(r.get('longterm')) if r.get('reflect_longterm',1) else 0)+
                      (money(r.get('retirement_pension')) if r.get('reflect_retirement',1) else 0) for r in payroll_rows)
    # Preserve an old project-level amount until the user assigns it to an employee.
    payroll_total+=money(row.get('retirement_pension'))
    deductions={'본사직불금액':direct,'미지급금':unpaid,'급여':payroll_total,
      '산재보험':estimates['산재보험'],'고용보험':estimates['고용보험']}
    deduction_details={
      '본사직불금액':{'estimate':None,'actual':direct,'difference':direct},
      '미지급금':{'estimate':None,'actual':unpaid,'difference':unpaid},
      '급여':{'estimate':None,'actual':payroll_total,'difference':payroll_total},
      '산재보험':{'estimate':estimates['산재보험'],'actual':None,'difference':estimates['산재보험']},
      '고용보험':{'estimate':estimates['고용보험'],'actual':None,'difference':estimates['고용보험']},
    }
    for name in actual_rules:
        difference=estimates[name]-paid_actuals[name]
        deductions[name]=difference
        deduction_details[name]={'estimate':estimates[name],'actual':paid_actuals[name],'difference':difference}
    ledger_total=ledger_amount+payroll_total
    deduction_total=sum(deductions.values())
    total=execution+purchase_vat
    difference=total-deduction_total-money(row.get('reserve_amount'))
    final=difference+money(row.get('public_adjustment'))
    return dict(contract=contract,supply=supply,vat=vat,insurance=insurance,outsource=outsource,management=management,
      execution=execution,purchase_vat=purchase_vat,total=total,direct=direct,unpaid=unpaid,deductions=deductions,
      deduction_total=deduction_total,deduction_details=deduction_details,paid_actuals=paid_actuals,
      payroll_total=payroll_total,ledger_total=ledger_total,ledger_amount=ledger_amount,excluded_cost=excluded_cost,
      real_settlement_cost=real_settlement_cost,difference=difference,final=final)

"""Excel output based on the user's original four-sheet workbook."""
from __future__ import annotations

import io
import json
from copy import copy
from pathlib import Path

from openpyxl import load_workbook

import outsource_settlement_store as db


TEMPLATE = Path(__file__).with_name('templates') / '외주정산_출력양식.xlsx'
INSURANCE_ROWS = {
    '산재보험': 12, '고용보험': 13, '건강보험': 14, '국민연금': 15,
    '퇴직공제부금': 16, '건설하도급지급보증': 17, '건설기계보증수수료': 18,
}
MONEY_FORMAT = '#,##0;[Red]-#,##0'


def _format_money(sheet, columns, start, end):
    for column in columns:
        for row in range(start,end+1):sheet[f'{column}{row}'].number_format=MONEY_FORMAT


def _item_amounts(items):
    amounts={}
    for item in items:
        if not item.get('반영'):continue
        label=str(item.get('항목') or '').strip()
        if label:amounts[label]=amounts.get(label,0)+db.money(item.get('금액'))
    return amounts


def _compact_amounts(amounts,capacity=7):
    values=list(amounts.items())
    if len(values)<=capacity:return values
    kept=values[:capacity-1];rest=values[capacity-1:]
    kept.append((f'기타 실비정산 항목({len(rest)}건)',sum(value for _,value in rest)))
    return kept


def _write_items(sheet, items, rows_map, name_col='C', amount_col='G'):
    values=_compact_amounts(_item_amounts(items),len(rows_map))
    for row in rows_map.values():sheet[f'{name_col}{row}']='';sheet[f'{amount_col}{row}']=0
    for row,(name,amount) in zip(rows_map.values(),values):
        sheet[f'{name_col}{row}']=name;sheet[f'{amount_col}{row}']=amount


def _clear_rows(sheet,start,end,columns):
    for row in range(start,end+1):
        for col in columns:
            cell=sheet[f'{col}{row}']
            if cell.__class__.__name__!='MergedCell':cell.value=None


def _fill_basic(sheet,record):
    sheet['D4']=record.get('written_at') or ''
    sheet['D6']=record.get('project_name') or ''
    sheet['Q6']=record.get('contractor') or ''
    sheet['D7']=int(record.get('contract_amount') or 0)
    sheet['C8']=record.get('contract_date') or ''
    sheet['I8']=record.get('start_date') or ''
    sheet['N8']=record.get('end_date') or ''
    sheet['S8']=record.get('client_name') or ''


def _fill_contract(sheet,record,calc,ledger_rows):
    _fill_basic(sheet,record)
    sheet['K7']=calc['supply'];sheet['S7']=calc['vat']
    items=db.json_items(record,'changed') or db.json_items(record,'original')
    _write_items(sheet,items,INSURANCE_ROWS)
    sheet['G19']=calc['insurance'];sheet['G20']=calc['outsource'];sheet['G21']=float(record.get('levy_rate') or 0)/100
    sheet['G22']=calc['management'];sheet['G23']=calc['execution'];sheet['G26']=calc['purchase_vat'];sheet['G28']=calc['total']
    deduction_rows={'급여':12,'본사직불금액':13,'미지급금':14,'산재보험':15,'고용보험':16,'건강보험':17,'국민연금':18,
      '퇴직공제부금':19,'건설기계보증수수료':20,'건설하도급지급보증':21}
    for name,row in deduction_rows.items():
        sheet[f'J{row}']=name
        sheet[f'O{row}']=calc['deductions'].get(name,0)
    sheet['O28']=calc['deduction_total'];sheet['S28']=calc['difference'];sheet['O29']=int(record.get('reserve_amount') or 0)
    sheet['S30']=calc['difference']-int(record.get('reserve_amount') or 0);sheet['S31']=calc['final']
    _clear_rows(sheet,35,42,['A','E','G'])
    for index,item in enumerate(db.receipts(record)[:8],35):
        sheet[f'A{index}']=item.get('일자','');sheet[f'E{index}']=item.get('내역','');sheet[f'G{index}']=db.money(item.get('금액'))
    sheet['G43']=sum(db.money(item.get('금액')) for item in db.receipts(record))
    sheet['O43']=sheet['G43'].value/calc['supply'] if calc['supply'] else 0
    sheet['S44']=record.get('company_name') or ''
    _format_money(sheet,['G'],11,43);_format_money(sheet,['O'],12,31);_format_money(sheet,['S'],28,31)
    for cell in ('D7','K7','S7'):sheet[cell].number_format=MONEY_FORMAT
    sheet['G21'].number_format='0.00%';sheet['O43'].number_format='0.00%'


def _fill_change(sheet,record,original,changed):
    sheet['D4']=record.get('written_at') or '';sheet['D6']=record.get('project_name') or '';sheet['Q6']=record.get('contractor') or ''
    sheet['D7']=int(record.get('original_contract_amount') or 0);sheet['K7']=original['supply'];sheet['S7']=original['vat']
    sheet['D8']=int(record.get('contract_amount') or 0);sheet['K8']=changed['supply'];sheet['S8']=changed['vat']
    sheet['C9']=record.get('contract_date') or '';sheet['I9']=record.get('start_date') or '';sheet['N9']=record.get('end_date') or '';sheet['S9']=record.get('client_name') or ''
    original_items=db.json_items(record,'original');changed_items=db.json_items(record,'changed')
    original_amounts=_item_amounts(original_items);changed_amounts=_item_amounts(changed_items)
    names=list(dict.fromkeys(list(original_amounts)+list(changed_amounts)))
    comparison=[(name,original_amounts.get(name,0),changed_amounts.get(name,0)) for name in names]
    if len(comparison)>7:
        kept=comparison[:6];rest=comparison[6:]
        kept.append((f'기타 실비정산 항목({len(rest)}건)',sum(x[1] for x in rest),sum(x[2] for x in rest)));comparison=kept
    change_rows={name:row+1 for name,row in INSURANCE_ROWS.items()}
    for row in change_rows.values():sheet[f'C{row}']='';sheet[f'G{row}']=0;sheet[f'J{row}']=0
    for row,(name,before,after) in zip(change_rows.values(),comparison):
        sheet[f'C{row}']=name;sheet[f'G{row}']=before;sheet[f'J{row}']=after-before
    sheet['G20']=original['insurance'];sheet['J20']=changed['insurance']-original['insurance']
    sheet['G21']=original['outsource'];sheet['J21']=changed['outsource']-original['outsource']
    sheet['G22']=float(record.get('original_levy_rate') or 0)/100;sheet['J22']=float(record.get('levy_rate') or 0)/100
    sheet['G23']=original['management'];sheet['J23']=changed['management']-original['management']
    sheet['G24']=original['execution'];sheet['J24']=changed['execution']-original['execution']
    sheet['J27']=changed['purchase_vat'];sheet['G29']=changed['total'];sheet['R29']=changed['deduction_total'];sheet['U29']=changed['difference']
    sheet['T44']=changed['difference'];sheet['T45']=sum(changed['deductions'].get(x,0) for x in ('건강보험','국민연금'))
    sheet['T46']=changed['unpaid'];sheet['T47']=int(record.get('public_adjustment') or 0);sheet['T48']=sum(sheet[f'T{row}'].value or 0 for row in range(44,48));sheet['T49']=changed['final']
    _format_money(sheet,['G','J'],13,29);_format_money(sheet,['R','U'],29,29);_format_money(sheet,['T'],44,49)
    for cell in ('D7','K7','S7','D8','K8','S8'):sheet[cell].number_format=MONEY_FORMAT
    sheet['G22'].number_format='0.00%';sheet['J22'].number_format='0.00%'


def _fill_ledger(sheet,record,ledger_rows,payroll_rows):
    sheet['F4']=record.get('company_name') or '';sheet['F6']=record.get('project_name') or ''
    for merged in list(sheet.merged_cells.ranges):
        if merged.min_row<=252 and merged.max_row>=8 and merged.min_col<=7 and merged.max_col>=1:
            sheet.unmerge_cells(str(merged))
    _clear_rows(sheet,8,252,['A','B','C','D','E','F','G'])
    for index,item in enumerate(ledger_rows[:245],8):
        sheet[f'A{index}']=item.get('account','');sheet[f'B{index}']=item.get('posted_at','');sheet[f'C{index}']=item.get('description','')
        sheet[f'D{index}']=item.get('vendor','');sheet[f'E{index}']=item.get('amount',0);sheet[f'F{index}']=item.get('note','');sheet[f'G{index}']=''
    sheet['E253']=sum(item.get('amount',0) for item in ledger_rows)
    totals={'salary':0,'pension':0,'health':0,'longterm':0,'retirement_pension':0}
    for item in payroll_rows:
        for key,flag in (('salary','reflect_salary'),('pension','reflect_pension'),('health','reflect_health'),('longterm','reflect_longterm'),('retirement_pension','reflect_retirement')):
            if item.get(flag,1):totals[key]+=item.get(key,0)
    sheet['E274']=sum(totals.values())+int(record.get('retirement_pension') or 0)
    sheet['E277']=sheet['E253'].value+sheet['E274'].value
    _format_money(sheet,['E'],8,277)


def _fill_payroll(sheet,payroll_rows):
    headers={str(sheet.cell(1,col).value or '').replace('\n','').replace(' ',''):col for col in range(1,sheet.max_column+1)}
    key_map={'employee_code':'사원코드','role':'구분','employee':'사원','hire_date':'입사일','retire_date':'퇴직일','company':'사업장',
      'project':'프로젝트','month':'귀속연월','salary':'급여합계','pension':'국민연금','health':'건강보험','longterm':'장기요양보험료',
      'retirement_pension':'퇴직연금'}
    for row in range(2,max(sheet.max_row,2)+1):
        for col in range(1,sheet.max_column+1):
            cell=sheet.cell(row,col)
            if cell.__class__.__name__!='MergedCell':cell.value=None
    for row_index,item in enumerate(payroll_rows,2):
        for key,label in key_map.items():
            col=headers.get(label)
            if col:
                sheet.cell(row_index,col).value=item.get(key,'')
                if key in ('salary','pension','health','longterm','retirement_pension'):sheet.cell(row_index,col).number_format=MONEY_FORMAT


def workbook(record,ledger_rows,payroll_rows):
    if not TEMPLATE.is_file():raise FileNotFoundError('외주정산 출력 템플릿이 없습니다.')
    ledger_rows=[item for item in ledger_rows if bool(item.get('included',1))]
    book=load_workbook(TEMPLATE)
    original_record=dict(record);original_record['contract_amount']=record.get('original_contract_amount') or record.get('contract_amount')
    original_record['levy_rate']=record.get('original_levy_rate') or record.get('levy_rate')
    original=db.calculations(original_record,ledger_rows,payroll_rows,changed=False)
    changed=db.calculations(record,ledger_rows,payroll_rows,changed=True)
    _fill_contract(book['도급'],record,changed,ledger_rows)
    _fill_change(book['도급(변경有경우)'],record,original,changed)
    _fill_ledger(book['원장'],record,ledger_rows,payroll_rows)
    _fill_payroll(book['급여현황(사원별)'],payroll_rows)
    output=io.BytesIO();book.save(output);return output.getvalue()

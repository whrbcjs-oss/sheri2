@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
echo [Sheri2 subcontract settlement ledger-cost update 2026.11.24.65]
echo Close the running Sheri2 server window first.
echo Select start.bat from the current program folder.
pause
call find_python.bat
if errorlevel 1 goto fail
%FINANCE_PYTHON% apply_update.py
if errorlevel 1 goto fail
echo Update completed. Run start.bat from the existing program folder.
pause
exit /b 0
:fail
echo Update stopped. No unverified source file is installed.
pause
exit /b 1

"""PC-first subcontract settlement workflow."""
from __future__ import annotations

import hashlib
from datetime import date, datetime
from html import escape

import pandas as pd
import streamlit as st

import outsource_settlement_report as report
import outsource_settlement_store as db


CSS='''<style>
.os-hero{background:linear-gradient(120deg,#ecf8f4,#e8f4fb);border:1px solid #bcd9d2;border-left:6px solid #2c94a8;border-radius:10px;padding:14px 17px;margin:3px 0 12px}.os-hero small{display:block;color:#3b8882;font-weight:800;letter-spacing:.06em}.os-hero strong{font-size:24px;color:#174a42;display:block}.os-title{background:#eaf6f2;border-left:5px solid #279c7b;padding:8px 11px;margin:12px 0 8px;color:#145c4d;font-size:18px;font-weight:850}.os-note{background:#f1f8fc;border:1px solid #cfe1eb;border-radius:8px;padding:9px 11px;color:#385b69}.st-key-os_metrics [data-testid="stMetric"]{background:white;border:1px solid #c9ddd6;border-top:4px solid #4b9fb3;border-radius:11px;padding:9px 12px}.st-key-os_work [data-testid="stDataFrame"]{border:1px solid #c7d9d3;border-radius:8px}.st-key-os_context{background:#f7fbfa;border:1px solid #c9ddd6;border-radius:10px;padding:8px 12px}.st-key-os_tabs button p{font-size:16px!important;font-weight:800!important}div[data-testid="stDataFrame"]{font-size:14px!important}</style>'''


def _date(value):
    try:return datetime.strptime(str(value),'%Y-%m-%d').date()
    except (TypeError,ValueError):return date.today()


def _money(value):return f'{int(value or 0):,}원'


def _flash():
    message=st.session_state.pop('_os_notice',None)
    if message:getattr(st,message[0])(message[1])


def _project_header(c):
    records=db.projects(c)
    pending=st.session_state.pop('_os_pending_project_id',None)
    if pending is not None:st.session_state['os_project_id']=int(pending)
    st.html(CSS)
    st.html('<div class="os-hero"><small>SUBCONTRACT · COST SETTLEMENT</small><strong>외주정산</strong>도급내역·원장·급여자료를 한 공사 단위로 연결해 실행금액과 최종정산금액을 계산합니다.</div>')
    with st.container(key='os_context'):
        left,right=st.columns([3,.7])
        choices=[0]+[item['id'] for item in records]
        labels={item['id']:f"{item['project_name']} · {item['contractor'] or '외주업체 미입력'}" for item in records}
        if st.session_state.get('os_project_id') not in choices:st.session_state['os_project_id']=choices[0]
        selected_id=left.selectbox('작업 공사',choices,format_func=lambda x:'새 공사 등록' if not x else labels[x],key='os_project_id')
        right.button('새 공사',use_container_width=True,type='primary',on_click=lambda:st.session_state.update(os_project_id=0))
    return next((item for item in records if item['id']==selected_id),None)


def _project_form(c,row):
    st.html('<div class="os-title">공사·계약 기본정보</div>')
    value=row or {'company_name':db.company_names()[0],'project_name':'','contractor':'','written_at':date.today().isoformat(),
      'contract_date':'','start_date':'','end_date':'','client_name':'','contract_amount':0,'levy_rate':0.0,
      'original_contract_amount':0,'original_levy_rate':0.0,'reserve_amount':0,'public_adjustment':0,'retirement_pension':0,'version':0}
    companies=db.company_names();key=f"os_project_form_{value.get('id',0)}_{value.get('version',0)}"
    with st.form(key):
        a,b,d=st.columns([1,2.2,1.2]);company_name=a.selectbox('당사',companies,index=companies.index(value['company_name']) if value.get('company_name') in companies else 0);project_name=b.text_input('공사명',value.get('project_name',''));contractor=d.text_input('외주업체명',value.get('contractor',''))
        a,b,d,e=st.columns(4);written_at=a.date_input('작성일',_date(value.get('written_at')));contract_date=b.date_input('계약일',_date(value.get('contract_date')));start_date=d.date_input('착공일',_date(value.get('start_date')));end_date=e.date_input('준공일',_date(value.get('end_date')))
        client_name=st.text_input('발주처',value.get('client_name',''))
        a,b,d,e=st.columns(4);contract_amount=a.number_input('현재 계약금액(VAT 포함)',min_value=0,value=int(value.get('contract_amount',0)),step=1000);levy_rate=b.number_input('현재 부금율(%)',min_value=0.0,max_value=100.0,value=float(value.get('levy_rate',0)),step=.1);original_contract_amount=d.number_input('당초 계약금액(VAT 포함)',min_value=0,value=int(value.get('original_contract_amount',0)),step=1000);original_levy_rate=e.number_input('당초 부금율(%)',min_value=0.0,max_value=100.0,value=float(value.get('original_levy_rate',0)),step=.1)
        a,b,d=st.columns(3);reserve_amount=a.number_input('유보금',value=int(value.get('reserve_amount',0)),step=1000);public_adjustment=b.number_input('공무부 확인 조정액',value=int(value.get('public_adjustment',0)),step=1000);retirement_pension=d.number_input('퇴직연금(수동)',value=int(value.get('retirement_pension',0)),step=1000)
        save=st.form_submit_button('공사정보 저장',type='primary')
    if save:
        try:
            project_id=db.save_project(c,locals(),value.get('id'),value.get('version'))
            st.session_state['_os_notice']=('success','공사정보를 저장했습니다.')
            st.session_state['_os_pending_project_id']=project_id;st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    if row:
        with st.expander('이 공사 삭제'):
            confirm=st.checkbox('원장·급여자료를 포함해 이 공사를 목록에서 삭제합니다.',key=f'os_delete_confirm_{row["id"]}')
            if st.button('공사 삭제',disabled=not confirm,key=f'os_delete_{row["id"]}'):
                try:db.delete_project(c,row['id'],row['version']);st.session_state['_os_notice']=('success','공사를 삭제했습니다.');st.session_state['_os_pending_project_id']=0;st.rerun()
                except (ValueError,PermissionError) as exc:st.error(str(exc))


def _upload_contract(c,row,kind):
    label='당초 내역서' if kind=='original' else '변경 내역서'
    uploaded=st.file_uploader(f'{label} Excel 업로드',type=['xlsx','xlsm'],key=f'os_{kind}_{row["id"]}')
    cache=f'_os_{kind}_items_{row["id"]}'
    if uploaded:
        digest=hashlib.sha256(uploaded.getvalue()).hexdigest()
        saved=st.session_state.get(cache)
        if not saved or saved['digest']!=digest:
            try:st.session_state[cache]={'digest':digest,'items':db.parse_contract(uploaded.getvalue())}
            except ValueError as exc:st.error(str(exc))
    items=(st.session_state.get(cache) or {}).get('items',db.json_items(row,kind))
    frame=pd.DataFrame(items or [],columns=['반영','항목','금액'])
    edited=st.data_editor(frame,hide_index=True,use_container_width=True,num_rows='dynamic',key=f'os_{kind}_editor_{row["id"]}',
      column_config={'반영':st.column_config.CheckboxColumn('정산 반영'),'항목':st.column_config.TextColumn('실비정산 항목'),'금액':st.column_config.NumberColumn('내역금액',format='%d')})
    if st.button(f'{label} 선택항목 저장',type='primary',key=f'os_{kind}_save_{row["id"]}'):
        try:db.save_items(c,row['id'],kind,edited.to_dict('records'),row['version']);st.session_state.pop(cache,None);st.session_state['_os_notice']=('success',f'{label} 항목을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def _metrics(calc):
    with st.container(key='os_metrics'):
        cols=st.columns(5)
        for col,(label,key) in zip(cols,[('공급가액 ①','supply'),('보험료 합계 ②','insurance'),('외주비 ③','outsource'),('관리비 ④','management'),('실행금액 ⑤','execution')]):col.metric(label,_money(calc[key]))


def _settlement_table(calc):
    left,right=st.columns([1.05,.95])
    with left:
        st.markdown('**공사내역 및 지출과목**')
        st.dataframe(pd.DataFrame([['① 공급가액',calc['supply']],['② 보험료 합계',calc['insurance']],['③ 외주비 금액',calc['outsource']],['④ 관리비',calc['management']],['⑤ 실행금액',calc['execution']],['⑥ 매입 VAT',calc['purchase_vat']],['계(⑤+⑥)',calc['total']]],columns=['산출내역','금액']),hide_index=True,use_container_width=True)
    with right:
        st.markdown('**공제과목금액**')
        items=[[key,value] for key,value in calc['deductions'].items()]+[['공제 합계',calc['deduction_total']],['정산 차액',calc['difference']],['최종정산금액',calc['final']]]
        st.dataframe(pd.DataFrame(items,columns=['과목','금액']),hide_index=True,use_container_width=True)


def _receipts(c,row):
    st.html('<div class="os-title">공사비 수령내역(공급가액)</div>')
    frame=pd.DataFrame(db.receipts(row),columns=['일자','내역','금액'])
    edited=st.data_editor(frame,hide_index=True,use_container_width=True,num_rows='dynamic',key=f'os_receipts_{row["id"]}',
      column_config={'일자':st.column_config.TextColumn('일자 (YYYY-MM-DD)'),'내역':st.column_config.TextColumn('내역'),'금액':st.column_config.NumberColumn('금액',format='%d')})
    if st.button('공사비 수령내역 저장',type='primary',key=f'os_receipts_save_{row["id"]}'):
        try:db.save_receipts(c,row['id'],edited.to_dict('records'),row['version']);st.session_state['_os_notice']=('success','공사비 수령내역을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def contract_tab(c,row,changed=False):
    ledger_rows=db.ledger(c,row['id']);payroll_rows=db.payroll(c,row['id']);calc=db.calculations(row,ledger_rows,payroll_rows,changed=changed)
    if changed:
        original_record=dict(row);original_record['contract_amount']=row.get('original_contract_amount') or row['contract_amount'];original_record['levy_rate']=row.get('original_levy_rate') or row['levy_rate']
        original=db.calculations(original_record,ledger_rows,payroll_rows,False)
        cols=st.columns(3);cols[0].metric('당초 실행금액',_money(original['execution']));cols[1].metric('변경 증감액',_money(calc['execution']-original['execution']));cols[2].metric('변경 후 실행금액',_money(calc['execution']))
        _upload_contract(c,row,'original');_upload_contract(c,row,'changed')
        st.html('<div class="os-title">당초와 변경내역 비교</div>')
        labels=['공급가액','보험료 합계','외주비','관리비','실행금액']
        keys=['supply','insurance','outsource','management','execution']
        st.dataframe(pd.DataFrame([[label,original[key],calc[key]-original[key],calc[key]] for label,key in zip(labels,keys)],columns=['산출내역','당초','변경(증·감)','변경 후']),hide_index=True,use_container_width=True)
    else:
        _upload_contract(c,row,'changed' if db.json_items(row,'changed') else 'original')
        _metrics(calc);_settlement_table(calc);_receipts(c,row)
    return calc


def ledger_tab(c,row):
    uploaded=st.file_uploader('아마란스 프로젝트별 계정내역 Excel',type=['xlsx','xlsm'],key=f'os_ledger_upload_{row["id"]}')
    if uploaded:
        try:
            parsed=db.parse_ledger(uploaded.getvalue());st.success(f'{len(parsed):,}개 원장 행을 찾았습니다.')
            st.dataframe(pd.DataFrame(parsed[:20]),hide_index=True,use_container_width=True)
            if st.button('기존 원장을 교체하고 업로드',type='primary',key=f'os_ledger_replace_{row["id"]}'):
                db.replace_ledger(c,row['id'],parsed,uploaded.name);st.session_state['_os_notice']=('success',f'원장 {len(parsed):,}개 행을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    records=db.ledger(c,row['id'])
    if not records:st.info('등록된 원장이 없습니다.');return
    controls=st.columns([1.5,1,1]);query=controls[0].text_input('적요·거래처 검색',key=f'os_ledger_search_{row["id"]}');note=controls[1].selectbox('비고분류',['전체']+sorted({x['note'] for x in records if x['note']}),key=f'os_ledger_note_{row["id"]}');payment=controls[2].selectbox('지급여부',['전체']+sorted({x['payment'] for x in records if x['payment']}),key=f'os_ledger_payment_{row["id"]}')
    visible=[x for x in records if query.casefold() in (x['description']+x['vendor']).casefold() and (note=='전체' or x['note']==note) and (payment=='전체' or x['payment']==payment)]
    frame=pd.DataFrame(visible)[['id','account','posted_at','description','vendor','amount','note','payment']]
    edited=st.data_editor(frame,hide_index=True,use_container_width=True,height=430,key=f'os_ledger_editor_{row["id"]}',disabled=['id','account','posted_at','description','vendor','amount'],column_config={'id':None,'account':'계정과목명','posted_at':'기표일자','description':'적요','vendor':'거래처명','amount':st.column_config.NumberColumn('지출',format='%d'),'note':'비고','payment':'지급여부'})
    if st.button('비고·지급여부 저장',type='primary',key=f'os_ledger_edit_save_{row["id"]}'):
        try:db.save_ledger_edits(c,row['id'],edited.to_dict('records'));st.session_state['_os_notice']=('success','원장 수정사항을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def payroll_tab(c,row):
    uploaded=st.file_uploader('급여현황(사원별) Excel',type=['xlsx','xlsm'],key=f'os_payroll_upload_{row["id"]}')
    if uploaded:
        try:
            parsed=db.parse_payroll(uploaded.getvalue());st.success(f'{len(parsed):,}개 급여 행을 찾았습니다.')
            if st.button('기존 급여자료를 교체하고 업로드',type='primary',key=f'os_payroll_replace_{row["id"]}'):
                db.replace_payroll(c,row['id'],parsed,uploaded.name);st.session_state['_os_notice']=('success',f'급여자료 {len(parsed):,}개 행을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))
    records=db.payroll(c,row['id'])
    if not records:st.info('등록된 급여자료가 없습니다.');return
    grouped=pd.DataFrame(records).groupby(['employee','role'],dropna=False)[['salary','pension','health','longterm']].sum().reset_index()
    st.html('<div class="os-title">사원별 집계</div>');st.dataframe(grouped,hide_index=True,use_container_width=True)
    st.html('<div class="os-title">월별 상세·원장 반영항목</div>')
    frame=pd.DataFrame(records)[['id','employee','role','month','salary','pension','health','longterm','reflect_salary','reflect_pension','reflect_health','reflect_longterm']]
    edited=st.data_editor(frame,hide_index=True,use_container_width=True,height=360,key=f'os_payroll_editor_{row["id"]}',disabled=['id','employee','role','month','salary','pension','health','longterm'],column_config={'id':None,'employee':'사원','role':'구분','month':'귀속연월','salary':st.column_config.NumberColumn('급여',format='%d'),'pension':st.column_config.NumberColumn('국민연금',format='%d'),'health':st.column_config.NumberColumn('건강보험',format='%d'),'longterm':st.column_config.NumberColumn('장기요양',format='%d'),'reflect_salary':st.column_config.CheckboxColumn('급여 반영'),'reflect_pension':st.column_config.CheckboxColumn('연금 반영'),'reflect_health':st.column_config.CheckboxColumn('건강 반영'),'reflect_longterm':st.column_config.CheckboxColumn('장기요양 반영')})
    if st.button('원장 반영항목 저장',type='primary',key=f'os_payroll_flags_{row["id"]}'):
        try:db.save_payroll_flags(c,row['id'],edited.to_dict('records'));st.session_state['_os_notice']=('success','원장 반영항목을 저장했습니다.');st.rerun()
        except (ValueError,PermissionError) as exc:st.error(str(exc))


def output_panel(c,row):
    ledger_rows=db.ledger(c,row['id']);payroll_rows=db.payroll(c,row['id'])
    payload=report.workbook(row,ledger_rows,payroll_rows)
    st.download_button('외주정산 Excel 동일양식 출력',payload,file_name=f"{row['project_name']}_외주정산.xlsx",mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',type='primary',use_container_width=True)
    st.caption('원본의 도급·도급(변경有경우)·원장·급여현황(사원별) 네 시트와 인쇄설정을 유지합니다.')


def render(user=None):
    c=db.connect();_flash();row=_project_header(c)
    _project_form(c,row)
    if not row:
        st.info('공사정보를 먼저 저장하면 내역서·원장·급여 업로드와 정산 계산을 사용할 수 있습니다.');return
    row=db.project(c,row['id'])
    output_panel(c,row)
    tabs=st.tabs(['도급정산','도급(변경이 있는 경우)','원장','급여현황(사원별)'])
    with tabs[0]:contract_tab(c,row,False)
    with tabs[1]:contract_tab(c,row,True)
    with tabs[2]:ledger_tab(c,row)
    with tabs[3]:payroll_tab(c,row)

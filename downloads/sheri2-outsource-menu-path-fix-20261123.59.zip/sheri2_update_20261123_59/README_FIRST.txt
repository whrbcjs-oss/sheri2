Sheri2 외주정산 메뉴 경로 수정 2026.11.23.59

58버전 설치 성공 후에도 메뉴가 보이지 않는 경우 사용하는 경로 수정판입니다.

1. 실행 중인 모든 Sheri2 검은색 서버 창을 닫습니다.
2. UPDATE_PROGRAM.bat을 실행합니다.
3. 평소 실행할 때 사용하는 start.bat 파일을 선택합니다.
4. 완료 화면의 Patched runtime 경로를 확인합니다.
5. 선택했던 기존 start.bat을 실행합니다.

이 설치기는 선택한 폴더뿐 아니라 start.bat이 참조하는 경로와 하위 실행 폴더를 확인합니다.
실제 실행본의 app_navigation.py와 multiuser_app.py에 외주정산 메뉴를 반영합니다.

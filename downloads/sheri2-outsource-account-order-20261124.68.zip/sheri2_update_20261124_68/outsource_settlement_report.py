"""Excel output based on the user's original four-sheet workbook."""
from __future__ import annotations

import io
import json
from copy import copy
from html import escape
from pathlib import Path

from openpyxl import load_workbook

import outsource_settlement_store as db


TEMPLATE = Path(__file__).with_name('templates') / '외주정산_출력양식.xlsx'
INSURANCE_ROWS = {
    '산재보험': 12, '고용보험': 13, '건강보험': 14, '국민연금': 15,
    '퇴직공제부금': 16, '건설하도급지급보증': 17, '건설기계보증수수료': 18,
}
MONEY_FORMAT = '#,##0;[Red]-#,##0'


def _format_money(sheet, columns, start, end):
    for column in columns:
        for row in range(start,end+1):sheet[f'{column}{row}'].number_format=MONEY_FORMAT


def _item_amounts(items):
    amounts={}
    for item in items:
        if not item.get('반영'):continue
        label=str(item.get('항목') or '').strip()
        if label:amounts[label]=amounts.get(label,0)+db.money(item.get('금액'))
    return amounts


def _compact_amounts(amounts,capacity=7):
    values=list(amounts.items())
    if len(values)<=capacity:return values
    kept=values[:capacity-1];rest=values[capacity-1:]
    kept.append((f'기타 실비정산 항목({len(rest)}건)',sum(value for _,value in rest)))
    return kept


def _write_items(sheet, items, rows_map, name_col='C', amount_col='G'):
    values=_compact_amounts(_item_amounts(items),len(rows_map))
    for row in rows_map.values():sheet[f'{name_col}{row}']='';sheet[f'{amount_col}{row}']=0
    for row,(name,amount) in zip(rows_map.values(),values):
        sheet[f'{name_col}{row}']=name;sheet[f'{amount_col}{row}']=amount


def _clear_rows(sheet,start,end,columns):
    for row in range(start,end+1):
        for col in columns:
            cell=sheet[f'{col}{row}']
            if cell.__class__.__name__!='MergedCell':cell.value=None


def _fill_basic(sheet,record):
    sheet['D4']=record.get('written_at') or ''
    sheet['D6']=record.get('project_name') or ''
    sheet['Q6']=record.get('contractor') or ''
    sheet['D7']=int(record.get('contract_amount') or 0)
    sheet['C8']=record.get('contract_date') or ''
    sheet['I8']=record.get('start_date') or ''
    sheet['N8']=record.get('end_date') or ''
    sheet['S8']=record.get('client_name') or ''


def _fill_contract(sheet,record,calc,ledger_rows):
    _fill_basic(sheet,record)
    sheet['K7']=calc['supply'];sheet['S7']=calc['vat']
    items=db.json_items(record,'changed') or db.json_items(record,'original')
    _write_items(sheet,items,INSURANCE_ROWS)
    sheet['G19']=calc['insurance'];sheet['G20']=calc['outsource'];sheet['G21']=float(record.get('levy_rate') or 0)/100
    sheet['G22']=calc['management'];sheet['G23']=calc['execution'];sheet['G26']=calc['purchase_vat'];sheet['G28']=calc['total']
    deduction_rows={'급여':12,'본사직불금액':13,'미지급금':14,'산재보험':15,'고용보험':16,'건강보험':17,'국민연금':18,
      '퇴직공제부금':19,'건설기계보증수수료':20,'건설하도급지급보증':21}
    for name,row in deduction_rows.items():
        sheet[f'J{row}']=name
        sheet[f'O{row}']=calc['deductions'].get(name,0)
    sheet['O28']=calc['deduction_total'];sheet['S28']=calc['difference'];sheet['O29']=int(record.get('reserve_amount') or 0)
    sheet['S30']=calc['difference']-int(record.get('reserve_amount') or 0);sheet['S31']=calc['final']
    _clear_rows(sheet,35,42,['A','E','G'])
    for index,item in enumerate(db.receipts(record)[:8],35):
        sheet[f'A{index}']=item.get('일자','');sheet[f'E{index}']=item.get('내역','');sheet[f'G{index}']=db.money(item.get('금액'))
    sheet['G43']=sum(db.money(item.get('금액')) for item in db.receipts(record))
    sheet['O43']=sheet['G43'].value/calc['supply'] if calc['supply'] else 0
    sheet['S44']=record.get('company_name') or ''
    _format_money(sheet,['G'],11,43);_format_money(sheet,['O'],12,31);_format_money(sheet,['S'],28,31)
    for cell in ('D7','K7','S7'):sheet[cell].number_format=MONEY_FORMAT
    sheet['G21'].number_format='0.00%';sheet['O43'].number_format='0.00%'


def _fill_change(sheet,record,original,changed):
    sheet['D4']=record.get('written_at') or '';sheet['D6']=record.get('project_name') or '';sheet['Q6']=record.get('contractor') or ''
    sheet['D7']=int(record.get('original_contract_amount') or 0);sheet['K7']=original['supply'];sheet['S7']=original['vat']
    sheet['D8']=int(record.get('contract_amount') or 0);sheet['K8']=changed['supply'];sheet['S8']=changed['vat']
    sheet['C9']=record.get('contract_date') or '';sheet['I9']=record.get('start_date') or '';sheet['N9']=record.get('end_date') or '';sheet['S9']=record.get('client_name') or ''
    original_items=db.json_items(record,'original');changed_items=db.json_items(record,'changed')
    original_amounts=_item_amounts(original_items);changed_amounts=_item_amounts(changed_items)
    names=list(dict.fromkeys(list(original_amounts)+list(changed_amounts)))
    comparison=[(name,original_amounts.get(name,0),changed_amounts.get(name,0)) for name in names]
    if len(comparison)>7:
        kept=comparison[:6];rest=comparison[6:]
        kept.append((f'기타 실비정산 항목({len(rest)}건)',sum(x[1] for x in rest),sum(x[2] for x in rest)));comparison=kept
    change_rows={name:row+1 for name,row in INSURANCE_ROWS.items()}
    for row in change_rows.values():sheet[f'C{row}']='';sheet[f'G{row}']=0;sheet[f'J{row}']=0
    for row,(name,before,after) in zip(change_rows.values(),comparison):
        sheet[f'C{row}']=name;sheet[f'G{row}']=before;sheet[f'J{row}']=after-before
    sheet['G20']=original['insurance'];sheet['J20']=changed['insurance']-original['insurance']
    sheet['G21']=original['outsource'];sheet['J21']=changed['outsource']-original['outsource']
    sheet['G22']=float(record.get('original_levy_rate') or 0)/100;sheet['J22']=float(record.get('levy_rate') or 0)/100
    sheet['G23']=original['management'];sheet['J23']=changed['management']-original['management']
    sheet['G24']=original['execution'];sheet['J24']=changed['execution']-original['execution']
    sheet['J27']=changed['purchase_vat'];sheet['G29']=changed['total'];sheet['R29']=changed['deduction_total'];sheet['U29']=changed['difference']
    sheet['T44']=changed['difference'];sheet['T45']=sum(changed['deductions'].get(x,0) for x in ('건강보험','국민연금'))
    sheet['T46']=changed['unpaid'];sheet['T47']=int(record.get('public_adjustment') or 0);sheet['T48']=sum(sheet[f'T{row}'].value or 0 for row in range(44,48));sheet['T49']=changed['final']
    _format_money(sheet,['G','J'],13,29);_format_money(sheet,['R','U'],29,29);_format_money(sheet,['T'],44,49)
    for cell in ('D7','K7','S7','D8','K8','S8'):sheet[cell].number_format=MONEY_FORMAT
    sheet['G22'].number_format='0.00%';sheet['J22'].number_format='0.00%'


def _fill_ledger(sheet,record,ledger_rows,payroll_rows):
    sheet['F4']=record.get('company_name') or '';sheet['F6']=record.get('project_name') or ''
    for merged in list(sheet.merged_cells.ranges):
        if merged.min_row<=252 and merged.max_row>=8 and merged.min_col<=7 and merged.max_col>=1:
            sheet.unmerge_cells(str(merged))
    _clear_rows(sheet,8,252,['A','B','C','D','E','F','G'])
    for index,item in enumerate(ledger_rows[:245],8):
        sheet[f'A{index}']=item.get('account','');sheet[f'B{index}']=item.get('posted_at','');sheet[f'C{index}']=item.get('description','')
        sheet[f'D{index}']=item.get('vendor','');sheet[f'E{index}']=item.get('amount',0);sheet[f'F{index}']=item.get('note','');sheet[f'G{index}']=''
    sheet['E253']=sum(item.get('amount',0) for item in ledger_rows)
    totals={'salary':0,'pension':0,'health':0,'longterm':0,'retirement_pension':0}
    for item in payroll_rows:
        for key,flag in (('salary','reflect_salary'),('pension','reflect_pension'),('health','reflect_health'),('longterm','reflect_longterm'),('retirement_pension','reflect_retirement')):
            if item.get(flag,1):totals[key]+=item.get(key,0)
    sheet['E274']=sum(totals.values())+int(record.get('retirement_pension') or 0)
    sheet['E277']=sheet['E253'].value+sheet['E274'].value
    _format_money(sheet,['E'],8,277)


def _fill_payroll(sheet,payroll_rows):
    headers={str(sheet.cell(1,col).value or '').replace('\n','').replace(' ',''):col for col in range(1,sheet.max_column+1)}
    key_map={'employee_code':'사원코드','role':'구분','employee':'사원','hire_date':'입사일','retire_date':'퇴직일','company':'사업장',
      'project':'프로젝트','month':'귀속연월','salary':'급여합계','pension':'국민연금','health':'건강보험','longterm':'장기요양보험료',
      'retirement_pension':'퇴직연금'}
    for row in range(2,max(sheet.max_row,2)+1):
        for col in range(1,sheet.max_column+1):
            cell=sheet.cell(row,col)
            if cell.__class__.__name__!='MergedCell':cell.value=None
    for row_index,item in enumerate(payroll_rows,2):
        for key,label in key_map.items():
            col=headers.get(label)
            if col:
                sheet.cell(row_index,col).value=item.get(key,'')
                if key in ('salary','pension','health','longterm','retirement_pension'):sheet.cell(row_index,col).number_format=MONEY_FORMAT


def workbook(record,ledger_rows,payroll_rows):
    if not TEMPLATE.is_file():raise FileNotFoundError('외주정산 출력 템플릿이 없습니다.')
    ledger_rows=[item for item in ledger_rows if bool(item.get('included',1))]
    book=load_workbook(TEMPLATE)
    original_record=dict(record);original_record['contract_amount']=record.get('original_contract_amount') or record.get('contract_amount')
    original_record['levy_rate']=record.get('original_levy_rate') or record.get('levy_rate')
    original=db.calculations(original_record,ledger_rows,payroll_rows,changed=False)
    changed=db.calculations(record,ledger_rows,payroll_rows,changed=True)
    _fill_contract(book['도급'],record,changed,ledger_rows)
    _fill_change(book['도급(변경有경우)'],record,original,changed)
    _fill_ledger(book['원장'],record,ledger_rows,payroll_rows)
    _fill_payroll(book['급여현황(사원별)'],payroll_rows)
    output=io.BytesIO();book.save(output);return output.getvalue()


def _won(value):
    amount=int(value or 0)
    return '-' if amount == 0 else f'{amount:,}'


def _text(value):return escape(str(value or ''))


LEDGER_ACCOUNT_ORDER=(
    '원재료(도급)','외주비','중기임차료','복리후생비','여비교통비','접대비','통신비','수도광열비',
    '세금과공과','지급임차료','수선비','보험료','차량유지비','운반비','유류비','교육훈련비',
    '도서인쇄비','퇴직공제부금비','소모품비','지급수수료','안전관리비','광고선전비','보상비',
    '전력비','협회비','잡비',
)


def _account_order_key(account):
    normalized=''.join(str(account or '').split())
    indexes={''.join(name.split()):index for index,name in enumerate(LEDGER_ACCOUNT_ORDER)}
    # Accept the user's original spelling as the same account as 교육훈련비.
    indexes['교육훈려비']=indexes['교육훈련비']
    return (0,indexes[normalized]) if normalized in indexes else (1,normalized)


def _ledger_body(ledger_rows):
    groups={}
    for sequence,item in enumerate(ledger_rows):
        account=str(item.get('account') or '').strip()
        groups.setdefault(account,[]).append((sequence,item))
    output=[];grand=0
    for account in sorted(groups,key=_account_order_key):
        entries=groups[account]
        entries.sort(key=lambda pair:(str(pair[1].get('posted_at') or ''),int(pair[1].get('source_row') or 0),pair[0]))
        subtotal=0
        for _,item in entries:
            amount=int(item.get('amount') or 0);subtotal+=amount;grand+=amount
            output.append('<tr>'+f'<td>{_text(account)}</td><td>{_text(item.get("posted_at"))}</td><td>{_text(item.get("description"))}</td><td>{_text(item.get("vendor"))}</td><td class="money">{_won(amount)}</td><td>{_text(item.get("note"))}</td></tr>')
        output.append(f'<tr class="subtotal"><td colspan="4">[ 소&nbsp;&nbsp;&nbsp;계 ]</td><td class="money">{_won(subtotal)}</td><td></td></tr>')
    output.append(f'<tr class="grand"><td colspan="4">[ 합&nbsp;&nbsp;&nbsp;계 ]</td><td class="money">{_won(grand)}</td><td></td></tr>')
    return ''.join(output),grand


def _payroll_body(payroll_rows,legacy_retirement=0):
    grouped={}
    for item in payroll_rows:
        name=str(item.get('employee') or '성명 미입력');entry=grouped.setdefault(name,{'salary':0,'pension':0,'health':0,'longterm':0,'retirement':0,'months':[]})
        for key,flag,target in (('salary','reflect_salary','salary'),('pension','reflect_pension','pension'),('health','reflect_health','health'),('longterm','reflect_longterm','longterm'),('retirement_pension','reflect_retirement','retirement')):
            if item.get(flag,1):entry[target]+=int(item.get(key) or 0)
        if item.get('month'):entry['months'].append(str(item.get('month')))
    rows=[];total=0
    for name,entry in grouped.items():
        months=sorted(set(entry['months']));period=(months[0]+' ~ '+months[-1]) if months else ''
        values=[('급여','급여','임·직원',entry['salary']),('복리후생비','건강보험 회사부담금','국민건강보험공단',entry['health']+entry['longterm']),('세금과공과','국민연금 회사부담금','국민건강보험공단',entry['pension']),('퇴직연금','퇴직연금','금융기관',entry['retirement'])]
        for account,description,vendor,amount in values:
            total+=amount;rows.append(f'<tr><td>{account}</td><td>{_text(name)}</td><td>{description}</td><td>{vendor}</td><td class="money">{_won(amount)}</td><td>{_text(period)}</td></tr>')
    if legacy_retirement:
        total+=int(legacy_retirement);rows.append(f'<tr><td>퇴직연금</td><td>미배정</td><td>이전자료 퇴직연금</td><td>금융기관</td><td class="money">{_won(legacy_retirement)}</td><td></td></tr>')
    rows.append(f'<tr class="grand"><td colspan="4">합&nbsp;&nbsp;&nbsp;계</td><td class="money">{_won(total)}</td><td></td></tr>')
    return ''.join(rows),total


def print_html(record,ledger_rows,payroll_rows):
    """Black-and-white A4 report matching the supplied settlement PDF."""
    calc=db.calculations(record,ledger_rows,payroll_rows,changed=bool(db.json_items(record,'changed')))
    items=db.json_items(record,'changed') or db.json_items(record,'original')
    detail=[(str(item.get('항목')).strip(),db.money(item.get('금액'))) for item in items if item.get('반영') and str(item.get('항목') or '').strip()]
    left_rows=''.join(f'<tr><td class="indent">{_text(name)}</td><td class="money">{_won(amount)}</td></tr>' for name,amount in detail)
    deduction_order=['급여','본사직불금액','미지급금','산재보험','고용보험','건강보험','국민연금','퇴직공제부금','건설기계보증수수료','건설하도급지급보증']
    right_rows=''.join(f'<tr><td>{_text(name)}</td><td class="money">{_won(calc["deductions"].get(name,0))}</td></tr>' for name in deduction_order)
    receipts=''.join(f'<tr><td>{_text(item.get("일자"))}</td><td>{_text(item.get("내역"))}</td><td class="money">{_won(db.money(item.get("금액")))}</td></tr>' for item in db.receipts(record));receipt_total=sum(db.money(item.get('금액')) for item in db.receipts(record))
    ledger_html,ledger_total=_ledger_body(ledger_rows);payroll_html,payroll_total=_payroll_body(payroll_rows,record.get('retirement_pension') or 0)
    company=_text(record.get('company_name'));project=_text(record.get('project_name'));contractor=_text(record.get('contractor'))
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>{project} 외주정산 보고서</title><style>
@page{{size:A4 portrait;margin:12mm 11mm 13mm}}*{{box-sizing:border-box}}body{{margin:0;background:#e9eceb;color:#000;font-family:"Malgun Gothic","Noto Sans KR",sans-serif;font-size:10px}}.toolbar{{position:sticky;top:0;z-index:2;padding:10px;text-align:center;background:#eef5f2;border-bottom:1px solid #bcc8c3}}.toolbar button{{padding:8px 18px;border:0;border-radius:5px;background:#087b58;color:#fff;font-weight:700}}.page{{width:210mm;min-height:297mm;margin:12px auto;padding:12mm 11mm 13mm;background:#fff;box-shadow:0 2px 12px #999}}h1{{margin:0 0 12px;text-align:center;font-size:22px;letter-spacing:5px}}h2{{margin:0 0 10px;font-size:16px;text-align:center}}.topline{{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:5px}}.approval{{border-collapse:collapse;width:290px;text-align:center}}.approval th,.approval td{{border:1px solid #000;padding:4px;height:25px}}.approval .vertical{{width:25px;writing-mode:vertical-rl;letter-spacing:4px}}table{{width:100%;border-collapse:collapse;table-layout:fixed}}th,td{{border:1px solid #000;padding:3px 5px;height:23px}}th{{background:#f2f2f2;font-weight:700}}.money{{text-align:right;font-variant-numeric:tabular-nums}}.center{{text-align:center}}.info td.label{{background:#f2f2f2;text-align:center;font-weight:700}}.section-title{{margin:12px 0 4px;font-size:12px;font-weight:700}}.twocol{{display:grid;grid-template-columns:1.05fr .95fr;gap:0}}.twocol>table:first-child{{border-right:0}}.twocol>table:first-child td,.twocol>table:first-child th{{border-right:0}}.indent{{padding-left:18px}}.result td,.grand td{{font-weight:700;background:#f0f0f0}}.subtotal td{{text-align:center;font-weight:700}}.subtotal td.money,.grand td.money{{text-align:right}}.ledger thead{{display:table-header-group}}.ledger tr{{break-inside:avoid}}.ledger th:nth-child(1){{width:15%}}.ledger th:nth-child(2){{width:13%}}.ledger th:nth-child(3){{width:27%}}.ledger th:nth-child(4){{width:20%}}.ledger th:nth-child(5){{width:15%}}.ledger th:nth-child(6){{width:10%}}.ledger td:nth-child(6){{text-align:center}}.ledger .subtotal td:first-child,.ledger .grand td:first-child,.payroll .grand td:first-child,.final-total td:first-child{{text-align:center}}.footer{{margin-top:6px;display:flex;justify-content:space-between;font-size:9px}}.break{{break-before:page}}.payroll th:nth-child(1){{width:13%}}.payroll th:nth-child(2){{width:12%}}.payroll th:nth-child(3){{width:24%}}.payroll th:nth-child(4){{width:20%}}.payroll th:nth-child(5){{width:16%}}.payroll th:nth-child(6){{width:15%}}@media print{{body{{background:#fff}}.toolbar{{display:none}}.page{{width:auto;min-height:auto;margin:0;padding:0;box-shadow:none}}}}
</style></head><body><div class="toolbar"><button onclick="window.print()">인쇄 / PDF 저장</button></div>
<section class="page"><h1>실행내역 검토서</h1><div class="topline"><div><b>작 성 일 :</b>&nbsp; {_text(record.get('written_at'))}</div><table class="approval"><tr><th class="vertical" rowspan="2">결재</th><th>담 당</th><th>부 장</th><th>이 사</th><th>상 무</th><th>사 장</th></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table></div>
<table class="info"><tr><td class="label">공사명</td><td colspan="5">{project}</td><td class="center"><b>{company}</b></td></tr><tr><td class="label">도급금액</td><td class="money">{_won(record.get('contract_amount'))}</td><td class="label">공급가액</td><td class="money">{_won(calc['supply'])}</td><td class="label">부가세</td><td class="money">{_won(calc['vat'])}</td><td>{contractor}</td></tr><tr><td class="label">계약일</td><td>{_text(record.get('contract_date'))}</td><td class="label">착공일</td><td>{_text(record.get('start_date'))}</td><td class="label">준공일</td><td>{_text(record.get('end_date'))}</td><td><b>발주처</b>&nbsp; {_text(record.get('client_name'))}</td></tr></table>
<div class="twocol"><table><tr><th colspan="2">공사내역 및 지출과목</th></tr><tr><th>산출내역</th><th>금액</th></tr><tr><td><b>① 공급가액</b></td><td class="money"><b>{_won(calc['supply'])}</b></td></tr>{left_rows}<tr><td><b>② 보험료 합계</b></td><td class="money"><b>{_won(calc['insurance'])}</b></td></tr><tr><td><b>③ 외주비 금액[①-②]</b></td><td class="money"><b>{_won(calc['outsource'])}</b></td></tr><tr><td>부금율</td><td class="money">{float(record.get('levy_rate') or 0):.2f}%</td></tr><tr><td><b>④ 관리비</b></td><td class="money"><b>{_won(calc['management'])}</b></td></tr><tr><td><b>⑤ 실행금액[①-④]</b></td><td class="money"><b>{_won(calc['execution'])}</b></td></tr><tr><td>⑥ 매입VAT</td><td class="money">{_won(calc['purchase_vat'])}</td></tr><tr class="result"><td>계(⑤+⑥)</td><td class="money">{_won(calc['total'])}</td></tr></table><table><tr><th colspan="2">공제과목금액</th></tr><tr><th>과목</th><th>금액</th></tr>{right_rows}<tr class="result"><td>계</td><td class="money">{_won(calc['deduction_total'])}</td></tr><tr><td>정산차액</td><td class="money">{_won(calc['difference'])}</td></tr><tr class="grand"><td>결재금액</td><td class="money">{_won(calc['final'])}</td></tr></table></div>
<div class="section-title">공 사 비 수 령 내 역 (공급가액)</div><table><tr><th>일자</th><th>내역</th><th>금액</th></tr>{receipts}<tr class="grand"><td colspan="2">합계</td><td class="money">{_won(receipt_total)}</td></tr><tr><td colspan="2">수금율</td><td class="money">{(receipt_total/calc['supply']*100 if calc['supply'] else 0):.2f}%</td></tr></table></section>
<section class="page break"><h2>프로젝트별 계정내역현황</h2><div class="topline"><span>기 간 : 전체 업로드 자료</span><b>{project}</b></div><div class="section-title">■ 현장 원가 (①)</div><table class="ledger"><thead><tr><th>계정과목명</th><th>기표일자</th><th>적요</th><th>거래처명</th><th>지출</th><th>비고</th></tr></thead><tbody>{ledger_html}</tbody></table><div class="footer"><span>{project}</span><span>프로젝트별 계정내역현황</span></div></section>
<section class="page break"><h2>직원 급여 및 4대보험</h2><div class="topline"><b>■ 직원 급여 및 4대보험 (②)</b><b>{project}</b></div><table class="payroll"><tr><th>계정과목명</th><th>사원명</th><th>적요</th><th>거래처명</th><th>지출액</th><th>비고</th></tr>{payroll_html}</table><table class="final-total" style="margin-top:22px"><tr class="grand"><td>총계 (현장원가+직원급여=①+②)</td><td class="money" style="width:28%">{_won(ledger_total+payroll_total)}</td></tr></table><div class="footer"><span>{project}</span><span>{company}</span></div></section></body></html>'''

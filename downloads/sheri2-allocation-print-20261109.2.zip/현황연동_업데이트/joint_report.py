"""Excel-style settlement and official-letter layouts; all user content is escaped."""
from html import escape
from decimal import Decimal, ROUND_HALF_UP
import json
from joint_store import num, EXCLUSIONS


def esc(v):return escape(str(v if v is not None else ''))
def money(v):return f'{num(v).quantize(Decimal("1"),rounding=ROUND_HALF_UP):,}'
def amount(v):
    n=num(v)
    return '<span class="negative">'+esc(money(n))+'</span>' if n<0 else (esc(money(n)) if n else '−')
def td(value='',numeric=False,**attrs):
    attrs['class']=(attrs.get('class','')+' '+('number' if numeric else 'text')).strip()
    attributes=''.join(' '+k+'="'+esc(v)+'"' for k,v in attrs.items())
    return '<td'+attributes+'>'+(amount(value) if numeric else esc(value))+'</td>'
def short_date(value):
    value=str(value or '')
    return value[2:].replace('-','.') if len(value)==10 and value[4]=='-' else value

def numeric_cells(values):return ''.join(td(v,True) for v in values)
def table(headers,records):
    return '<table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(td(x,False,**{'class':'number' if any(t in headers[i] for t in ['공급가액','VAT','계산서','영수증','합계']) else 'text'}) for i,x in enumerate(row))+'</tr>' for row in records)+'</tbody></table>'


def period_label(start,end):
    if start==end:return start[:4]+'년 '+start[5:]+'월'
    if start[:4]==end[:4]:return start[:4]+'년 '+start[5:]+'~'+end[5:]+'월'
    return start[:4]+'년 '+start[5:]+'월 ~ '+end[:4]+'년 '+end[5:]+'월'


def monthly_claims(d):
    m=d['member'];p=d['project'];monthly={}
    if d.get('nonlead'):
        for x in d.get('direct_claims',[]):
            v=monthly.setdefault(x['month'],[num(0),num(0),num(0)])
            for i,k in enumerate(['base','vat','invested']):v[i]+=num(x[k])
        return sorted(monthly.items())
    for x in d['allocations']:
        if x['member_id']==m['id']:
            v=monthly.setdefault(x['allocation_month'],[num(0),num(0),num(0)])
            v[0]+=num(x['base']);v[1]+=num(x['vat'])
    if m['company_id']!=p['owner_id']:
        for x in d['allocations']:
            if x['investing_company']==m['company_id']:
                monthly.setdefault(x['allocation_month'],[num(0),num(0),num(0)])[2]+=num(x['original_base'])
    return sorted(monthly.items())


def settlement_body(d,meta,number,issued):
    p,m,a=d['project'],d['member'],d['amounts'];entries=d['entries']
    management=d.get('management_entries',[e for e in entries if e['kind']=='progress']);progress=d.get('receipt_entries',[e for e in entries if e['kind']=='progress'])+d.get('deduction_entries',[]);recoveries=[e for e in entries if e['kind']=='recovery'];subs=[e for e in entries if e['kind']=='subcontract'];claims=monthly_claims(d)
    enabled=bool(m['fee_enabled']);receipt_columns=9 if enabled else 5
    rates={e['data'].get('fee_rate',m['fee_rate']) for e in management}
    fee_label=('관리비 ('+(next(iter(rates)) if len(rates)==1 else '기성별')+('%)' if len(rates)==1 else ')')) if m['fee_enabled'] else '관리비 (미적용)'
    body='<section class="settlement-sheet"><div class="sheet-heading"><h1>■ 공동도급 공사원가 정산내역 · '+esc(m['name'])+' <span>'+esc(m['share'])+'%</span></h1><div>'+esc(p['name'])+'</div></div>'
    scope='정산명: '+esc(d.get('run_name','원가정산'))
    body+='<div class="sheet-meta"><span>'+scope+'</span><span>문서번호: '+esc(number)+'　발행일: '+esc(issued)+'　[단위: 원]</span></div>'
    body+='<div class="sheet-scroll"><table id="settlement-grid" class="settlement-grid"><colgroup>'
    widths=[4.2,4.4,6.1,4.5,6.2,4.5,4.5,4.5,5.8,4.2,4.1,6.1,4.5,4.8,6.1,4.2,6.1,4.5,6.1,6.1,6.8]
    if not enabled:widths=widths[:5]+widths[9:]
    body+=''.join('<col style="width:'+str(w/sum(widths)*100)+'%">' for w in widths)+'</colgroup>'
    deduction_header='<th colspan="4">공 제 내 역</th>' if enabled else ''
    remaining_label='미회수액<br>(①−②+③−④−⑤)' if enabled else '미회수액<br>(청구내역 계−회수액 계)'
    body+='<thead><tr><th colspan="5">공사대금 수령</th>'+deduction_header+'<th colspan="6">원가분담금 청구내역</th><th colspan="4">회 수 내 역</th><th rowspan="2">'+remaining_label+'</th><th rowspan="2">비 고</th></tr><tr>'
    headers=['수령일자','구분','공급가액\n①','VAT','계']+([fee_label,'산재보험','고용보험','공제계\n②'] if enabled else [])+['청구연월','구분','공급가액','VAT\n③','회원사투입\n④','계','회수일자','공급가액','VAT','회수액\n⑤']
    body+=''.join('<th>'+esc(x).replace('\n','<br>')+'</th>' for x in headers)+'</tr></thead><tbody>'
    display_recoveries=list(recoveries)
    display_recoveries.sort(key=lambda e:(e['entry_date'],e['id']))
    for i in range(max(14,len(progress),len(claims),len(display_recoveries))):
        row=''
        if i<len(progress):
            e=progress[i];v=e['data'];fee=num(v['fee']) if m['fee_enabled'] else num(0);industrial=num(v['산재보험']);employment=num(v['고용보험'])
            row+=td(short_date(e['entry_date']))+td(v.get('label',''))+numeric_cells([v['supply'],v['vat'],num(v['supply'])+num(v['vat'])]+([fee,industrial,employment,fee+industrial+employment] if enabled else []))
        else:row+='<td></td>'*receipt_columns
        if i<len(claims):
            month,v=claims[i];row+=td(month)+td(str(int(month[-2:]))+'월분')+numeric_cells(v+[v[0]+v[1]-v[2]])
        else:row+='<td></td>'*6
        if i<len(display_recoveries):
            e=display_recoveries[i];v=e['data'];row+=td(short_date(e['entry_date']))+numeric_cells([v['supply'],v['vat'],num(v['supply'])+num(v['vat'])]);note=v.get('note','')
        else:row+='<td></td>'*4;note=''
        body+='<tr class="data-row">'+row+td('')+td(note,**{'class':'text-note'})+'</tr>'
    base=num(a['base']);vat=num(a['vat']);invested=num(a['invested']);sub=num(a['subcontract']);subvat=num(a['subcontract_vat']);paid_supply=sum((num(e['data'].get('paid_supply',0)) for e in subs),num(0));paid_vat=sum((num(e['data'].get('paid_vat',0)) for e in subs),num(0));rs=sum((num(e['data']['supply']) for e in recoveries),num(0));rv=sum((num(e['data']['vat']) for e in recoveries),num(0))
    if d.get('claim_only') and not d.get('simultaneous_subcontracts'):paid_supply=paid_vat=num(0)
    body+='<tr class="subtotal">'+td('',colspan=str(receipt_columns))+td('소계(원가분담금)',colspan='2')+numeric_cells([base,vat,invested,base+vat-invested])+td('')+numeric_cells([rs,rv,rs+rv])+td('')+td('')+'</tr>'
    body+='<tr class="subtotal">'+td('',colspan=str(receipt_columns))+td('소계(하도급대금)',colspan='2')+numeric_cells([sub,subvat,0,sub+subvat])+td('')+numeric_cells([paid_supply,paid_vat,paid_supply+paid_vat])+td('')+td('')+'</tr>'
    receipt_vat=sum((num(e['data']['vat']) for e in progress),num(0))
    body+='<tr class="grand-total">'+td('합 계',colspan='2')+numeric_cells([a['received'],receipt_vat,num(a['received'])+receipt_vat]+([a['fee'],a['industrial'],a['employment'],a['deductions']] if enabled else []))+td('합 계',colspan='2')+numeric_cells([base+sub,vat+subvat,invested,a['claim']])+td('합 계')+numeric_cells([rs+paid_supply,rv+paid_vat,a['recovery'],a['remaining']])+td('')+'</tr></tbody></table></div>'
    rule='① − ② + ③ − ④ − ⑤' if m['fee_enabled'] else '청구내역 계 − 회수액 계'
    body+='<div class="sheet-bottom"><span>미회수액 산식: '+esc(rule)+'</span><span>청구연월은 원장의 배분월 기준입니다. 각 영역은 독립된 내역이며 같은 행이 동일 거래를 의미하지 않습니다.</span></div></section>'
    if d.get('nonlead') and d.get('nonlead_status'):
        from joint_status_report import render as status_report
        body=body[:-10]+status_report(d['nonlead_status'])+'</section>'
    # Supporting sheet 2 follows the supplied horizontal milestone layout.
    if enabled:
        body+='<section class="support-sheet"><h2>■ 관리비 산출내역 · '+esc(m['name'])+'</h2><div class="sheet-scroll"><table id="management-grid"><thead><tr><th>구분</th>'
        slots=management or [None]
        body+=''.join('<th>'+esc(e['data'].get('label') or e['entry_date'] if e else '관리비·보험료 미선택')+'</th>' for e in slots)+'<th>소계</th></tr></thead><tbody>'
        lines=[('공급가액',lambda v:num(v['supply']))]+[(k,lambda v,k=k:num(v[k])) for k in EXCLUSIONS]+[('제외분 합계',lambda v:sum((num(v[k]) for k in EXCLUSIONS),num(0))),('관리대상액',lambda v:num(v['supply'])-sum((num(v[k]) for k in EXCLUSIONS),num(0))),('관리비',lambda v:num(v['fee']) if m['fee_enabled'] else num(0))]
        for label,fn in lines:
            if label=='관리비':
                body+='<tr>'+td('비율')+''.join(td((e['data']['fee_rate']+'%') if e and m['fee_enabled'] else '미적용') for e in slots)+td('')+'</tr>'
            values=[fn(e['data']) if e else num(0) for e in slots]
            body+='<tr class="'+('subtotal' if label in ['제외분 합계','관리대상액','관리비'] else '')+'">'+td(label)+numeric_cells(values+[sum(values,num(0))])+'</tr>'
        body+='</tbody></table></div><p class="sheet-bottom">보험료·제외항목은 회원사분 입력액입니다. 관리비는 기성별 원 미만 버림을 적용합니다.</p></section>'
    if d.get('claim_only') and not d.get('simultaneous_subcontracts'):
        body+='<section class="support-sheet"><h2>■ 하도급 청구내역 ['+esc(m['name'])+']</h2><div class="sheet-scroll"><table id="subcontract-grid"><thead><tr>'
        body+=''.join('<th>'+x+'</th>' for x in ['청구일','업체명','공급가액','VAT','합계금액','공종명','지급방식','비고'])+'</tr></thead><tbody>'
        for e in subs:
            v=e['data'];body+='<tr>'+td(short_date(e['entry_date']))+td(v.get('vendor',''))+numeric_cells([v['supply'],v['vat'],num(v['supply'])+num(v['vat'])])+td(v.get('work_type',''))+td(v.get('method',''))+td(v.get('note',''))+'</tr>'
        body+='<tr class="grand-total">'+td('합 계',colspan='2')+numeric_cells([sub,subvat,sub+subvat])+td('',colspan='3')+'</tr></tbody></table></div></section>'
    else:
        # Supporting sheet 3 mirrors the claim/payment columns of the original.
        body+='<section class="support-sheet"><h2>■ 하도급 청구 및 지급현황 ['+esc(m['name'])+']</h2><div class="sheet-scroll"><table id="subcontract-grid"><thead><tr>'
        headers=['청구년월','업체명','공급가액','VAT','합계금액','지급일자','공급가액','VAT','지급액','미지급액','공종명','지급방식']
        body+=''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'
        for i in range(max(10,len(subs))):
            if i>=len(subs):body+='<tr class="data-row">'+'<td></td>'*12+'</tr>';continue
            e=subs[i];v=e['data'];pay=num(v['paid_supply'])+num(v['paid_vat']);claim=num(v['supply'])+num(v['vat']);method=v.get('method','')
            body+='<tr>'+td(short_date(e['entry_date']))+td(v.get('vendor',''))+numeric_cells([v['supply'],v['vat'],claim])+td(short_date(v.get('paid_date','')))+numeric_cells([v['paid_supply'],v['paid_vat'],pay,claim-pay])+td(v.get('work_type',''))+td(method)+'</tr>'
        body+='<tr class="grand-total">'+td('합 계',colspan='2')+numeric_cells([sub,subvat,sub+subvat])+td('')+numeric_cells([paid_supply,paid_vat,paid_supply+paid_vat,sub+subvat-paid_supply-paid_vat])+td('')+td('')+'</tr></tbody></table></div></section>'
    return body


def letter_body(d,meta,number,issued,owner,info):
    m,p,a=d['member'],d['project'],d['amounts'];title=meta.get('title') or period_label(d['start'],d['end'])+' 공동원가 안분정산 및 자금청구의 건'
    contact1=meta['contact1'] if 'contact1' in meta else ' '.join(str(info.get(k,'')) for k in ['직급','담당자']).strip()
    contact2=meta['contact2'] if 'contact2' in meta else ' '.join(str(info.get(k,'')) for k in ['직급2','담당자2']).strip()
    contacts=meta.get('contact_separator',' / ').join(x for x in [contact1,contact2] if x)
    body='<article class="official-letter"><h1 class="letter-company">'+esc(owner['name'])+'</h1><div class="letter-address">발신 : '+esc(info.get('주소',''))+' / 전화 '+esc(info.get('전화',''))+' / FAX '+esc(info.get('팩스',''))+'<br><span>담당자 : '+esc(contacts)+'</span></div>'
    body+='<div class="letter-top"><dl class="letter-fields">'
    for label,value in [('문서번호',number),('발신일자',str(issued).replace('-','.')),('수 신',m['name']),('참 조',meta.get('reference','공동도급 담당자')),('제 목',title)]:body+='<div><dt>'+esc(label)+' :</dt><dd>'+esc(value)+'</dd></div>'
    body+='</dl></div><hr class="letter-rule">'
    body+='<div class="letter-paragraphs"><p>1. 귀사의 무궁한 발전을 기원합니다.</p><p>2. 귀사와 공동도급으로 시공중인 「'+esc(p['name'])+'」의 현장에서 투자한 공사원가에 대하여 정산내역을 송부하오니, 업무에 참조하여 주시기 바랍니다.</p>'
    if meta.get('body'):body+='<p class="custom-body">'+esc(meta['body'])+'</p>'
    body+='</div><div class="letter-table-wrap"><table id="letter-amounts"><thead><tr><th rowspan="2">구 분</th><th rowspan="2">당월<br>총공사원가</th>'
    parties=d.get('parties') or [dict(name=m['name'],share=m['share'],**{k:a[k] for k in ['base','vat','invested','arrears','interest']})]
    columns='<colgroup><col style="width:26%"><col style="width:17%">'+''.join('<col style="width:'+str(48/len(parties))+'%">' for _ in parties)+'<col style="width:9%"></colgroup>'
    body=body.replace('<table id="letter-amounts">','<table id="letter-amounts">'+columns,1)
    body+=''.join('<th>'+esc(x['name'])+'</th>' for x in parties)+'<th rowspan="2">비 고</th></tr><tr>'+''.join('<th>'+esc(x['share'])+'%</th>' for x in parties)+'</tr></thead><tbody>'
    for label,fn in [('원가투입액 (①)',lambda x:num(x['base'])),('부가가치세 (②)',lambda x:num(x['vat'])),('합 계 (③, ①+②)',lambda x:num(x['base'])+num(x['vat'])),('공제액 (④)',lambda x:num(x['invested'])),('전월 미수액 (⑤)',lambda x:num(x['arrears'])),('지연이자 (⑥)',lambda x:num(x['interest'])),('금월청구액 (⑦, ③−④+⑤+⑥)',lambda x:num(x['base'])+num(x['vat'])-num(x['invested'])+num(x['arrears'])+num(x['interest']))]:
        values=[fn(x) for x in parties]
        body+='<tr class="'+('letter-claim' if label.startswith('금월') else '')+'">'+td(label)+numeric_cells([sum(values,num(0))]+values)+td('')+'</tr>'
    body+='</tbody></table></div><div class="letter-tail">'
    if meta.get('due'):body+='<p>'+esc(meta['due'])+'까지 아래의 예금계좌로 입금하여 주시기 바랍니다.</p>'
    body+='<p class="bank">※ 입금계좌 : '+esc(meta.get('bank',info.get('입금계좌','')))+'</p><div class="attachments"><span># 첨 부 :</span><div>'
    attachments=meta.get('attachments') or '공동원가 투입 및 배분내역서 1부, 현장별 원장 1부'
    for i,x in enumerate(attachments.replace('\n',',').split(','),1):
        if x.strip():body+='<div>'+esc(str(i)+'. '+x.strip())+'</div>'
    body+='끝.</div></div></div><div class="letter-signature"><div>'+esc(owner['name'])+'</div><div>대표이사　'+esc(info.get('대표자',''))+'</div>'
    if meta.get('signature_layout')==1:
        def distributed(text):
            return ''.join('<span>'+esc(ch)+'</span>' for ch in str(text) if not ch.isspace())
        old='<div>'+esc(owner['name'])+'</div><div>대표이사　'+esc(info.get('대표자',''))+'</div>'
        new='<div class="sender-lines"><div class="sender-line">'+distributed(owner['name'])+'</div><div class="sender-line">'+distributed('대표이사'+info.get('대표자',''))+'</div></div>'
        body=body.replace(old,new,1)
    # Only an explicitly selected PNG/JPEG data URL is embedded, never arbitrary markup.
    seal=meta.get('seal','')
    if isinstance(seal,str) and len(seal)<1500000 and seal.startswith(('data:image/png;base64,','data:image/jpeg;base64,')):
        import re
        if re.fullmatch(r'data:image/(?:png|jpeg);base64,[A-Za-z0-9+/=]+',seal):body+='<img class="seal" alt="선택한 직인" src="'+esc(seal)+'">'
    if d.get('investment_letter'):
        import re
        text=meta.get('investment_body','「'+p['name']+'」와 관련한 당사의 공동원가 투입내역을 붙임과 같이 제출하오니, 공동원가 배분시 반영하여 주시기 바랍니다.')
        body=re.sub(r'<div class="letter-paragraphs">.*?<div class="letter-signature">', lambda match: '<div class="letter-paragraphs"><p>1. 귀사의 무궁한 발전을 기원합니다.</p><p>2. '+esc(text)+'</p></div><p style="text-align:center">- 아 래 -</p><div class="letter-table-wrap">'+table(['구분','계산서','영수증','부가세','합계','비고'],[[period_label(d['start'],d['end'])]+[money(d['investment_totals'][k]) for k in ['invoice','receipt','vat','total']]+['']])+'</div><p># 첨부 : 1. 공동원가 투입내역 1부. 끝.</p><div class="letter-signature">',body,flags=re.S)
    if meta.get('uploaded_files'):
        names=[row['name'] for row in meta['uploaded_files']]
        if d.get('investment_letter'):
            listing='<div class="attachments letter-extra-names"><span># 첨부 :</span><div><div>1. 공동원가 투입내역 1부.</div>'+''.join('<div>'+esc(str(i)+'. '+name+' 1부.')+'</div>' for i,name in enumerate(names,2))+'끝.</div></div>'
            body=body.replace('<p># 첨부 : 1. 공동원가 투입내역 1부. 끝.</p>',listing,1)
        else:
            start=len([x for x in (meta.get('attachments') or '공동원가 투입 및 배분내역서 1부, 현장별 원장 1부').replace('\n',',').split(',') if x.strip()])+1
            extra=''.join('<div class="letter-extra-names">'+esc(str(i)+'. '+name+' 1부.')+'</div>' for i,name in enumerate(names,start))
            body=body.replace('끝.</div></div></div><div class="letter-signature">',extra+'끝.</div></div></div><div class="letter-signature">',1)
    return body+'</div></article>'


CSS='''
*{box-sizing:border-box}body{margin:0;color:#111;font-family:"Malgun Gothic","Noto Sans CJK KR",Arial,sans-serif;background:#edf0f2;font-size:14px;line-height:1.5}.tools{display:flex;justify-content:space-between;align-items:center;padding:12px 20px;background:white;border-bottom:1px solid #d8dde1;gap:12px}.tools button{padding:9px 18px;background:#009f57;color:white;border:0;border-radius:5px;font:inherit;cursor:pointer}.status{color:#65717b;font-size:13px}.document{background:white;margin:18px auto;padding:24px;max-width:2400px}.sheet-heading{display:flex;justify-content:space-between;align-items:baseline;gap:15px;border-bottom:1px solid #111;padding-bottom:5px;min-width:900px}.sheet-heading h1{font-size:20px;margin:0}.sheet-heading h1 span{color:#225b91}.sheet-heading>div{font-size:18px;font-weight:600}.sheet-meta{display:flex;justify-content:space-between;gap:20px;font-size:12px;margin:6px 0}.sheet-scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums;font-size:14px}th,td{border:1px solid #333;padding:5px 6px;text-align:right;vertical-align:middle}th{font-weight:600;text-align:center;background:white;line-height:1.35}td{white-space:nowrap}.negative{color:#c42121}.settlement-grid{min-width:2100px;table-layout:fixed}.settlement-grid th{font-size:13px}.settlement-grid td{padding:5px 3px;border-bottom-style:dotted}.settlement-grid .data-row td:nth-child(1),.settlement-grid .data-row td:nth-child(2),.settlement-grid .data-row td:nth-child(10),.settlement-grid .data-row td:nth-child(11),.settlement-grid .data-row td:nth-child(16){text-align:center}.settlement-grid .text-note{white-space:normal;font-size:12px}.data-row{height:28px}.data-row:nth-child(odd){background:#eef7fb}.subtotal{background:#f3f3ef;font-weight:650}.grand-total{font-weight:700;border-top:2px solid black}.grand-total td{border-bottom-style:solid}.sheet-bottom{font-size:12px;display:flex;justify-content:space-between;gap:20px;margin:7px 0 0;color:#4d555b}.support-sheet{margin-top:36px;border-top:1px solid #c5c9cc;padding-top:20px}.support-sheet h2{font-size:18px;margin:0 0 10px}.support-sheet td:first-child{text-align:left}.support-sheet #management-grid{min-width:850px}.support-sheet #subcontract-grid{min-width:1250px}.document-letter{max-width:210mm;padding:14mm 14mm 12mm;box-shadow:0 2px 8px #0001}.official-letter{font-family:Batang,"바탕","Noto Serif CJK KR","Malgun Gothic",serif;font-size:15px;line-height:1.8}.letter-company{text-align:center;font-size:30px;letter-spacing:5px;margin:0 0 15px;font-weight:700}.letter-address{font-family:"Malgun Gothic",sans-serif;font-size:11px;line-height:1.6;border-bottom:2px solid #111;padding-bottom:9px}.letter-address span{display:block;text-align:right}.letter-top{position:relative;min-height:160px;margin:22px 0}.letter-fields{margin:0;padding-right:138px}.letter-fields>div{display:flex;gap:5px;margin:5px 0}.letter-fields dt{flex:0 0 75px;white-space:pre;text-align:justify}.letter-fields dd{margin:0;overflow-wrap:anywhere}.letter-fields>div:last-child{padding-top:4px}.processing-box{position:absolute;right:0;top:0;width:124px;font-family:"Malgun Gothic",sans-serif;font-size:10px}.processing-box{table-layout:fixed;border:1px solid #111;outline:1px solid #111;outline-offset:-1px}.processing-box th,.processing-box td{padding:3px;height:22px}.processing-box th{width:33px}.processing-box td{min-width:0}.letter-paragraphs{margin:20px 0 22px}.letter-paragraphs p{margin:12px 0;text-align:justify}.custom-body{white-space:pre-wrap}.letter-table-wrap{margin:20px 0 26px}#letter-amounts{outline:1px solid #111;outline-offset:-1px;border:1px solid #111;max-width:100%;font-family:"Malgun Gothic",sans-serif;font-size:12px;table-layout:fixed}#letter-amounts th,#letter-amounts td{padding:7px 4px}#letter-amounts th:first-child{width:26%}#letter-amounts th:last-child{width:9%}#letter-amounts td:first-child{white-space:normal;text-align:left}#letter-amounts td{overflow-wrap:anywhere;white-space:normal}#letter-amounts .letter-claim{font-weight:700;border-top:2px solid black}.letter-tail{font-size:14px}.bank{margin:15px 0 18px}.attachments{display:flex;gap:12px;margin:12px 0}.attachments>span{white-space:nowrap}.letter-signature{position:relative;text-align:center;margin:30px auto 0;font-size:23px;line-height:1.8;letter-spacing:4px;font-weight:600;min-height:85px}.seal{position:absolute;width:24mm;height:24mm;object-fit:contain;right:6%;bottom:0}h1,h2{break-after:avoid}tr{break-inside:avoid}
@media(max-width:900px){.document{padding:14px}.document-letter{margin:12px;min-width:700px}.sheet-heading{min-width:800px}.sheet-meta{flex-wrap:wrap}.sheet-bottom{flex-wrap:wrap}}
@media print{body{background:white;margin:0}.tools{display:none!important}.document{margin:0;padding:0;max-width:none;box-shadow:none}.sheet-scroll{overflow:visible}.sheet-heading{min-width:0}.sheet-heading h1{font-size:15pt}.sheet-heading>div{font-size:12pt}.sheet-meta{font-size:9pt}.settlement-grid{min-width:0;width:100%;font-size:10pt}.settlement-grid th{font-size:9pt}.settlement-grid td{padding:4px 2px;line-height:1.25}.settlement-grid .text-note{font-size:9pt}.data-row{height:7mm}.sheet-bottom{font-size:8pt}.support-sheet{break-before:page;border:0;margin:0;padding:0}.support-sheet table{font-size:10pt}.support-sheet #management-grid,.support-sheet #subcontract-grid{min-width:0}.support-sheet th,.support-sheet td{padding:4px}.document-letter{width:auto;min-width:0;max-width:none;padding:0;margin:0}.official-letter{font-size:11pt;line-height:1.65}.letter-company{font-size:23pt;margin-bottom:10px}.letter-address{font-size:9pt}.letter-top{margin:16px 0;min-height:135px}.letter-fields>div{margin:4px 0}.letter-paragraphs{margin:14px 0 18px}.letter-paragraphs p{margin:9px 0}.letter-table-wrap{margin:16px 0 20px}#letter-amounts{font-size:9pt}#letter-amounts th,#letter-amounts td{padding:6px 4px}.letter-tail{font-size:10pt}.letter-signature{font-size:17pt;margin-top:22px;min-height:75px}td,th,.data-row,.subtotal{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
.letter-fields{padding-right:0}.letter-top{min-height:0;margin:20px 0 12px}.letter-rule{border:0;border-top:1px solid #111;margin:16px 0}.letter-signature{text-align:right}.letter-signature:has(.seal){padding-right:28mm}.seal{right:0}.tools button:disabled{background:#9ca6ac;cursor:default}
@media print{.letter-top{min-height:0;margin:15px 0 10px}.letter-rule{margin:12px 0}.letter-signature{text-align:right}}
'''


def render(d,kind='정산서',meta=None,printable=True):
    meta=meta or d.get('meta',{});co={x['id']:x for x in d['companies']};owner=co[d['project']['owner_id']];info=json.loads(owner['info']);issued=d.get('issued',meta.get('issued',''));number=d.get('number',meta.get('number','미확정'))
    letter=kind=='공문';body=letter_body(d,meta,number,issued,owner,info) if letter else settlement_body(d,meta,number,issued)
    if d.get('nonlead') and not letter:
        for old,new in [('원가분담금 청구내역','원가배분 접수내역'),('회원사투입','반영투입'),('회 수 내 역','지 급 내 역'),('회수일자','지급일자'),('회수액','지급액'),('미회수액','미지급액'),('회수 내역','지급 내역')]:body=body.replace(old,new)
    if d.get('warnings'):body='<div class="preview-notes">'+''.join('<p>'+esc(x)+'</p>' for x in d['warnings'])+'</div>'+body
    status='확정 발행본' if 'snapshot_id' in d or d.get('number') else '미확정 미리보기'
    page='A4 portrait' if letter else 'A3 landscape'
    control='<button onclick="window.print()">인쇄 / PDF 저장</button>' if printable else '<button disabled>월 마감 후 출력 가능</button>'
    layout=letter and d.get('letter_layout_version',0)>=2
    extra_css='';fit_script=''
    if layout:
        from joint_letter_pages import CSS as letter_css,ledger_pages,FIT_SCRIPT
        extra_css=letter_css;fit_script=FIT_SCRIPT
        if d.get("investment_letter") and d.get("letter_layout_version",0)>=3:
            from joint_investment_print import CSS as investment_css
            extra_css+=investment_css
        if len(str(meta.get('investment_body',''))+str(meta.get('body',''))+str(meta.get('title',''))+''.join(row['name'] for row in meta.get('uploaded_files',[])))>900:
            body=body.replace('<article class="official-letter">','<article class="official-letter letter-flow">',1)
        if d.get('investment_letter') and not meta.get('mail_no_ledger_append'):body+=ledger_pages(d)
    if layout and d.get('lead_letter_layout_version')==1 and not d.get('investment_letter'):
        from joint_lead_letter import CSS as lead_css,FIT_SCRIPT as lead_fit,wrap as lead_wrap
        body=lead_wrap(body);extra_css+=lead_css;fit_script=lead_fit
    if letter and meta.get('uploaded_files') and not meta.get('mail_no_embedded_files'):
        from joint_letter_files import unpack,name as safe_name
        import base64
        links=''.join('<a download="'+esc(safe_name(row['name']))+'" href="data:application/octet-stream;base64,'+base64.b64encode(unpack(row)).decode()+'">'+esc(row['name'])+'</a>' for row in meta['uploaded_files'])
        control+='<div class="file-links">'+links+'</div>'
    return '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+esc(kind)+'</title><style>'+CSS+'@page{size:'+page+';margin:12mm}'+extra_css+'</style></head><body><div class="tools"><span class="status">'+esc(status)+' · 금액 단위: 원</span>'+control+'</div><main class="document '+('document-letter'+(' letter-v2' if layout else '') if letter else 'document-settlement')+'">'+body+'</main>'+fit_script+'</body></html>'


def monthly_package(package,member_id,meta):
    """Only accepts a server-frozen close package, never live mutable source rows."""
    from io import BytesIO
    import base64,hashlib,zipfile
    month=package['month'];project=package['project']['name'];letter=render(dict(package['letters'][str(member_id)],letter_layout_version=2,lead_letter_layout_version=1),'공문',meta)
    ledger_headers=['원장ID','기표일자','배분연월','원가투입 회사','계정과목','거래처','적요','세금계산서 공급가액','VAT','계산서','기타영수증','합계','입력 출처','비고']
    ledger_rows=[]
    for r in package['ledger']:
        ledger_rows.append([r['id'],r['posting_date'],r['allocation_month'],r['company'],r['account'],r['vendor'],r['description']]+[money(r[k]) for k in ['tax_supply','vat','invoice','receipt']]+[money(sum((num(r[k]) for k in ['tax_supply','vat','invoice','receipt']),num(0))),'업로드' if r['batch_id'] else '수기',r['note']])
    alloc_headers=['원장ID','배분연월','회원사','계정과목','적요','적용지분(%)','배분 공급가액','배분 VAT','합계','수정 사유']
    alloc_rows=[[r['ledger_id'],r['allocation_month'],r['name'],r['account'],r['description'],r['share'],money(r['base']),money(r['vat']),money(num(r['base'])+num(r['vat'])),r['reason']] for r in package['allocations']]
    def document(title,headers,records):
        return '<!doctype html><html lang="ko"><meta charset="utf-8"><title>'+esc(title)+'</title><style>'+CSS+'@page{size:A3 landscape;margin:12mm}table{font-size:12px}td{white-space:normal}</style><body><div class="tools"><button onclick="window.print()">인쇄 / PDF 저장</button></div><main class="document"><h1>'+esc(title)+'</h1><p>'+esc(project)+' · '+esc(month)+' · 마감 보관본</p>'+table(headers,records)+'</main></body></html>'
    ledger_rows.append(['합 계','','','','','','']+[money(sum((num(r[k]) for r in package['ledger']),num(0))) for k in ['tax_supply','vat','invoice','receipt']]+[money(sum((sum((num(r[k]) for k in ['tax_supply','vat','invoice','receipt']),num(0)) for r in package['ledger']),num(0))),'',''])
    ledger_html=document('해당월 원장',ledger_headers,ledger_rows)
    from joint_allocation import matrix_data,render_matrix
    data=matrix_data(package['project'],package['letters'][str(member_id)]['members'],package['ledger'],package['allocations'],package.get('prior_ledger',[]),package.get('allocation_details',[]),prior_known='prior_ledger' in package)
    alloc_html=render_matrix(data,month)
    stream=BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
        for name,html in [('공문.html',letter),('해당월_원장.html',ledger_html),('원가배분내역서.html',alloc_html)]:z.writestr(name,html.encode('utf-8'))
        for i,row in enumerate(meta.get('uploaded_files',[]),1):
            from joint_letter_files import unpack,name as safe_name
            z.writestr('추가서류/'+str(i)+'_'+safe_name(row['name']),unpack(row))
        for original in package.get('originals',[]):
            blob=base64.b64decode(original['content'],validate=True)
            if original.get('digest') and hashlib.sha256(blob).hexdigest()!=original['digest']:raise ValueError('보관된 원본 파일의 무결성이 맞지 않습니다.')
            z.writestr('업로드원본/원본_'+str(original['id'])+'.xlsx',blob)
    return stream.getvalue(),ledger_html,alloc_html

CSS += "td.text, .support-sheet td.text:first-child, #letter-amounts td.text:first-child{text-align:center}td.number{text-align:right}.grand-total{background:#e8edf0}.grand-total td{border-top:2px solid #66737d}"

@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
echo [Sheri2 integrated prepaid calculation update 2026.11.14.5]
echo Close the running Sheri2 server window first.
echo Select start.bat in the existing Sheri2 installation folder.
pause
call find_python.bat
if errorlevel 1 goto fail
%FINANCE_PYTHON% apply_update.py
if errorlevel 1 goto fail
echo Update completed. Run start.bat from the existing installation folder.
pause
exit /b 0
:fail
echo Update failed. Review the message above.
pause
exit /b 1

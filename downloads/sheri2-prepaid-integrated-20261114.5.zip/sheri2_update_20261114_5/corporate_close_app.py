"""Corporate close workspace centered on the approved Excel-shaped tax flow."""
from datetime import date
from html import escape
from io import BytesIO
import pandas as pd
from pandas.io.formats.style import Styler
import streamlit as st
import streamlit.components.v1 as components
import corporate_close_store as db
import corporate_close_calc as calc
import corporate_close_import as ledger
import corporate_close_report as report
import corporate_close_dashboard as dashboard
import corporate_close_prepaid as prepaid
import corporate_close_promotion as promotion
import corporate_progress as progress
import corporate_progress_report as progress_report

VERSION='2026.11.14.5'
ADJUSTMENT_SUBPAGES=['세금과공과명세서','선급비용명세서','기업업무추진비명세서']
PAGES=['대시보드','법인세 계산 흐름표','기초정보입력','공사수입·원가대비','세무조정 항목',*ADJUSTMENT_SUBPAGES,'소득구분계산서','세액 계산','유보잔액 관리','법인·업종 설정','결산 확정·출력']
VALUE_FIELDS=[('construction_revenue','공사수입'),('service_revenue','용역수입'),('progress_adjustment','진행률조정수입(예상)'),('cost','매출원가'),('sga','판매관리비'),('nonop_income','영업외수익'),('nonop_expense','영업외비용'),('prior_sales','전기매출'),('prior_progress','전기 진행률 수입조정'),('prior_unfinished','전기 미완성공사'),('current_unfinished','당기 미완성공사')]
REVIEW_FIELDS=[('entertainment_cost','접대비·경비'),('entertainment_sga','접대비·판관비'),('tax_cost','세금과공과·경비'),('tax_sga','세금과공과·판관비'),('interest','이자비용'),('donation','기부금')]
TAX_FIELDS=[('donation_excess','기부금한도초과'),('donation_carry_deduction','기부금이월손금'),('carry_loss','전기이월결손금'),('special_reduction','중소기업 특별세액감면'),('rd_prior','R&D 세액공제 전기이월'),('rd_current','R&D 세액공제 당기'),('undocumented_base','증빙미수취 대상금액'),('land_gain','토지 등 양도차익'),('prepaid_corp_interim','법인세 중간예납'),('prepaid_corp_withholding','법인세 원천납부'),('prepaid_local','지방소득세 기납부'),('accrued_tax','미지급법인세')]
NEXT_FIELDS=[('donation_carry_next','차기 기부금 이월잔액'),('carry_loss_next','차기 이월결손금'),('rd_carry_next','차기 R&D 세액공제 이월액')]
CSS='''<style>.cc-title{background:#087a4f;color:#fff;border-radius:7px;padding:8px 12px;font-weight:800;font-size:18px;margin:5px 0 8px}.cc-card{border:1px solid #b8d5c6;border-radius:8px;padding:10px;background:#fff;margin-bottom:8px}.cc-legend{font-size:12px;color:#60776c;text-align:right}.cc-blue{color:#2788e8;font-weight:700}.cc-red{color:#ef2424;font-weight:700}.cc-yellow{background:#fff600;padding:1px 5px;font-weight:700}.st-key-cc_direct_flow [data-testid="stNumberInput"] input,.st-key-cc_direct_flow [data-testid="stTextInput"] input,.st-key-cc_tax_direct [data-testid="stNumberInput"] input,.st-key-cc_tax_direct [data-testid="stTextInput"] input{background:#eef6ff;color:#176dc2;font-weight:700}.cc-auto{background:#fff600;border:1px solid #b9ad00;padding:8px;border-radius:5px;text-align:right;font-weight:800;color:#ef2424;margin-bottom:7px}.cc-section{background:#c8c8c8;border:1px solid #777;padding:7px;text-align:center;font-weight:800;margin:4px 0 7px}.cc-adjust-title{background:#087a4f;color:#fff;border-radius:7px 7px 0 0;padding:8px 11px;font-weight:800;font-size:15px;margin-top:12px}.cc-grid-head{text-align:center;font-weight:800;color:#36594a;padding:6px 2px;border-bottom:2px solid #90b6a3}.cc-grid-auto{height:38px;display:flex;align-items:center;justify-content:flex-end;padding:0 9px;background:#fff7bd;border:1px solid #dfcd5a;border-radius:6px;color:#d92323;font-weight:800;font-variant-numeric:tabular-nums}.cc-grid-na{height:38px;display:flex;align-items:center;justify-content:center;background:#f2f5f3;border:1px solid #d7dfdb;border-radius:6px;color:#8a9992}.cc-adjust-total{text-align:right;background:#fff200;border:1px solid #d6c900;border-radius:6px;padding:10px 12px;color:#e32323;font-weight:800;font-variant-numeric:tabular-nums;margin:5px 0 13px}[class*="st-key-cc_add_"][class*="_amount"] input,[class*="st-key-cc_add_"][class*="_cost"] input,[class*="st-key-cc_deduct_"][class*="_amount"] input,[class*="st-key-cc_deduct_"][class*="_cost"] input,[class*="st-key-flow_"] input,[class*="st-key-tax_"] input,[class*="st-key-reserve_"] input{color:#126bb0!important;text-align:right!important;font-weight:700!important;font-variant-numeric:tabular-nums}</style>'''
def money(v):
    if v is None or v=='':return 0
    try:
        if pd.isna(v):return 0
    except (TypeError,ValueError):pass
    return int(float(str(v).replace(',','').replace('원','').strip() or 0))
def money_field(scope,label,value,key=None,disabled=False,label_visibility='visible'):
    return money(scope.text_input(label,value=f'{money(value):,}',key=key,disabled=disabled,label_visibility=label_visibility))
def show_frame(data,*args,**kwargs):
    if isinstance(data,Styler):return st.dataframe(data,*args,**kwargs)
    frame=pd.DataFrame(data);numeric=[c for c in frame.columns if pd.api.types.is_numeric_dtype(frame[c]) and not pd.api.types.is_bool_dtype(frame[c])];text=[c for c in frame.columns if c not in numeric]
    styled=frame.style.format({c:'{:,.0f}' for c in numeric},na_rep='').set_properties(subset=numeric,**{'text-align':'right','color':'#126bb0','font-weight':'600'}).set_properties(subset=text,**{'text-align':'center'}).set_table_styles([{'selector':'th','props':[('text-align','center'),('font-weight','700'),('background','#edf5f1')]}])
    return st.dataframe(styled,*args,**kwargs)
def statement_print_html(title,year,sections):
    """Create a standalone A4-landscape calculation sheet for browser printing."""
    tables=[]
    for heading,data in sections:
        frame=pd.DataFrame(data).copy()
        numeric=[c for c in frame.columns if pd.api.types.is_numeric_dtype(frame[c]) and not pd.api.types.is_bool_dtype(frame[c])]
        formatters={c:(lambda v: '' if pd.isna(v) else f'{int(v):,}') for c in numeric}
        tables.append(f'<h2>{escape(str(heading))}</h2>'+frame.to_html(index=False,border=0,na_rep='',formatters=formatters,escape=True))
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>{escape(str(title))}</title><style>
    @page{{size:A4 landscape;margin:10mm}}body{{font-family:"Malgun Gothic",sans-serif;color:#111;margin:0}}h1{{font-size:20px;text-align:center;margin:0 0 4px}}.year{{text-align:right;font-size:12px;margin-bottom:12px}}h2{{font-size:14px;background:#087a4f;color:white;padding:6px 8px;margin:14px 0 0}}table{{width:100%;border-collapse:collapse;font-size:10px;page-break-inside:auto}}thead{{display:table-header-group}}tr{{page-break-inside:avoid}}th,td{{border:1px solid #777;padding:4px 5px}}th{{background:#e7eeea;text-align:center}}td{{text-align:center}}td:nth-child(n+2){{font-variant-numeric:tabular-nums}}.print{{margin-bottom:8px;padding:6px 12px}}@media print{{.print{{display:none}}}}
    </style></head><body><button class="print" onclick="window.print()">인쇄</button><h1>{escape(str(title))}</h1><div class="year">결산연도 {int(year)}년</div>{''.join(tables)}</body></html>'''
def tax_input_values(raw):
    tax=dict(raw or {});parts=calc.prepaid_tax(tax)
    tax.update(parts);return tax
def refresh():st.rerun()
def active_company(c,id):return next(x for x in db.companies(c) if x['id']==id)
def reserve_summary(c,x):
    out=[]
    for r in db.reserves(c,x['company_id']):
        y=next((z for z in db.reserve_years(c,r['id']) if z['year']==x['year']),None)
        if y:period={k:y[k] for k in ['beginning','increase','deduction','other','ending']}
        else:
            prior=[z for z in db.reserve_years(c,r['id']) if z['year']<x['year']]
            beginning=prior[-1]['ending'] if prior else r['initial_amount']
            period={'beginning':beginning,'increase':0,'deduction':0,'other':0,'ending':beginning}
        out.append({**r,**period})
    return out
def readiness(c,x,company,inc):
    missing=[]
    value_keys={k for k,_ in VALUE_FIELDS};tax_keys={k for k,_ in TAX_FIELDS}
    if not value_keys.issubset(x.get('values',{})):missing.append('손익계산서·예상금액 저장')
    if not tax_keys.issubset(x.get('tax',{})):missing.append('세액 계산 입력 저장')
    if inc['check']!=0:missing.append('업종별 매출액 합계 일치')
    if not inc.get('expense_manual'):missing.append('영업외비용 감면분·기타분 직접 입력')
    elif inc.get('expense_check'):missing.append('영업외비용 구분 합계 일치')
    blanks=[r for r in db.ledger_rows(c,x['id']) if r['kind']=='영업외수익' and '잡이익' in db.normalized(r['account']) and not r['classification']]
    if blanks:missing.append(f'잡이익 적요 분류 {len(blanks)}건')
    projects=db.progress_projects(c,x['id'])
    if projects:
        ps=progress.summary(projects,x.get('progress',{}));values=x.get('values',{})
        if money(values.get('construction_revenue'))!=ps['table_revenue'] or money(values.get('progress_adjustment'))!=ps['expected_adjustment']:missing.append('공사수입·진행률조정 검산값 흐름표 반영')
    return missing
def computed(c,x,company):
    adjustments=db.adjustments(c,x['id']);lr=db.ledger_rows(c,x['id']);other_income=sum(r['amount'] for r in lr if r['kind']=='영업외수익' and '잡이익' in db.normalized(r['account']) and r['classification']=='감면분');manual=x.get('income_manual',{})
    values=x.get('values',{});f=calc.flow(values,adjustments);businesses=[{'name':name,'revenue':x.get('business_revenue',{}).get(name,0)} for name in company.get('businesses',['건설업'])]
    if len(businesses)==1 and not businesses[0]['revenue']:businesses[0]['revenue']=f['sales']
    inc=calc.income_division(values,adjustments,businesses,other_income,manual.get('nonop_expense_exempt'),manual.get('nonop_expense_other'),x.get('losses',{}));inc['classification_details']=[{'kind':r['kind'],'account':r['account'],'description':r['description'],'reason':str(r.get('business','')).replace('자동:',''),'classification':r['classification'],'amount':r['amount']} for r in lr if r['kind']=='영업외수익' and '잡이익' in db.normalized(r['account'])];tax=calc.tax_calculation(inc['current_income'],{**x.get('tax',{}),'pre_tax':f['pre_tax']});return adjustments,inc,tax,reserve_summary(c,x)
def save_payload(c,x,payload):db.save_case(c,x,payload,x['version']);refresh()

def dashboard_page(c,x,company):
    adjustments,inc,tax_result,reserves=computed(c,x,company);view=dashboard.html(company['name'],x['year'],x,adjustments,inc,tax_result)
    comparison=[]
    for co in db.companies(c):
        case=db.case(c,co['id'],x['year'],create=False)
        if not case:comparison.append({'name':co['name'],'entered':False});continue
        a,i,t,_=computed(c,case,co);f=calc.flow(case.get('values',{}),a);sales=f['sales']
        comparison.append({'name':co['name'],'entered':True,'sales':sales,'gross':f['gross_profit'],'operating':f['operating_profit'],'pretax':f['pre_tax'],'net':t['net_income'],'gross_rate':(f['gross_profit']/sales*100 if sales else 0),'operating_rate':(f['operating_profit']/sales*100 if sales else 0),'pretax_rate':f['pre_tax_rate'],'net_rate':(t['net_income']/sales*100 if sales else 0),'cost_rate':f['cost_rate'],'taxable':t['taxable'],'credits':t['credits'],'payable':t['corp_payable']+t['local_payable']})
    st.html('<div class="cc-title">대시보드</div>');st.caption('저장된 기초정보·세무조정·소득구분·세액 계산 결과를 한 화면에 표시합니다. 별도 입력 없이 자동 갱신됩니다.')
    individual_tab,compare_tab=st.tabs(['개별회사 분석','회사 비교'])
    with individual_tab:components.html(view,height=930,scrolling=True)
    with compare_tab:components.html(dashboard.comparison_html(x['year'],comparison),height=900,scrolling=True)

def basic_input_page(c,x,company):
    st.html('<div class="cc-title">기초정보입력</div>');st.caption('기존 법인세 계산 흐름표의 입력 항목과 계산 기준을 그대로 유지했습니다. 연파랑 칸에 입력하고 저장하세요.')
    with st.container(key='cc_direct_flow'):
      # This page intentionally does not use st.form: the detail-mode checkbox
      # must rerun immediately so its dependent inputs become editable.
      with st.container():
        values=dict(x.get('values',{}));review=dict(x.get('review',{}));tax=tax_input_values(x.get('tax',{}));business=dict(x.get('business_revenue',{}));disabled=x['status']=='confirmed';p1,p2,p3,p4=st.columns([1.05,1.05,1.35,1.0])
        p1.html('<div class="cc-section">손익계산서 점검</div>')
        for key,label in VALUE_FIELDS[:7]:values[key]=money_field(p1,label,values.get(key),key='flow_'+key,disabled=disabled)
        live=calc.flow(values,db.adjustments(c,x['id']));p1.html(f'<div class="cc-auto">매출계　{live["sales"]:,}</div><div class="cc-auto">영업이익　{live["operating_profit"]:,}</div>')
        p2.html('<div class="cc-section">전기·예상 지표</div>')
        for key,label in VALUE_FIELDS[7:]:values[key]=money_field(p2,label,values.get(key),key='flow_'+key,disabled=disabled)
        p2.html(f'<div class="cc-auto">진행률조정 계　{money(values.get("prior_progress"))+money(values.get("progress_adjustment")):,}</div>');p3.html('<div class="cc-section">조정 전 검토사항</div>')
        for key,label in REVIEW_FIELDS:review[key]=money_field(p3,label,review.get(key),key='flow_review_'+key,disabled=disabled)
        p4.html('<div class="cc-section">기납부세액</div>');tax['prepaid_corp_interim']=money_field(p4,'법인세 중간예납',tax.get('prepaid_corp_interim'),key='flow_prepaid_interim',disabled=disabled);tax['prepaid_corp_withholding']=money_field(p4,'법인세 원천납부',tax.get('prepaid_corp_withholding'),key='flow_prepaid_withholding',disabled=disabled);tax['prepaid_local']=money_field(p4,'지방소득세 기납부',tax.get('prepaid_local'),key='flow_prepaid_local',disabled=disabled);tax['prepaid_corp']=tax['prepaid_corp_interim']+tax['prepaid_corp_withholding'];p4.html(f'<div class="cc-auto">선납세금 합계　{tax["prepaid_corp"]+tax["prepaid_local"]:,}</div>')
        st.markdown('**연구 및 인력개발비(세액공제)**');old=calc.research_totals(review);detail=st.checkbox('세부항목으로 계산',value=old['detail_enabled'] or not review,disabled=disabled);r1,r2,r3,r4=st.columns(4);review['rnd_employee_count']=r1.number_input('연구 인건비 인원(명)',min_value=0,value=old['employee_count'],disabled=disabled or not detail);review['rnd_labor']=money_field(r1,f'인건비({review["rnd_employee_count"]}명)',old['labor'],key='rnd_labor',disabled=disabled or not detail);review['rnd_material']=money_field(r2,'재료비',old['material'],key='rnd_material',disabled=disabled or not detail);review['rnd_other']=money_field(r2,'기타 연구개발비',old['other'],key='rnd_other',disabled=disabled or not detail);review['rnd_outsourced']=money_field(r3,'위탁·공동연구비',old['outsourced'],key='rnd_outsourced',disabled=disabled or not detail);review['training_sga']=money_field(r3,'(판)교육훈련비',old['training_sga'],key='training_sga',disabled=disabled or not detail);review['training_cost']=money_field(r4,'(경)교육훈련비',old['training_cost'],key='training_cost',disabled=disabled or not detail);review['rnd_detail_enabled']=detail;rt=calc.research_totals(review);review['rnd']=rt['current_total'];review['tech_total']=rt['tech_total'];r4.html(f'<div class="cc-auto">경상연구개발비 계　{rt["current_total"]:,}</div><div class="cc-auto">인력개발비 계　{rt["personnel_total"]:,}</div><div class="cc-auto">기술개발투자비　{rt["tech_total"]:,}</div>')
        if len(company.get('businesses',[]))>1:
            st.markdown('**겸업 업종별 매출액**');cols=st.columns(min(4,len(company['businesses'])))
            for i,name in enumerate(company['businesses']):business[name]=money_field(cols[i%len(cols)],name+' 매출액',business.get(name),key='business_'+str(i),disabled=disabled)
        disposal=st.date_input('처분확정일',value=date.fromisoformat(x.get('disposal_date',f'{x["year"]+1}-03-31')),disabled=disabled);submit=st.button('흐름표 입력값 저장',type='primary',disabled=disabled,key='cc_values_save')
    if submit:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload.update(values=values,review=review,tax=tax,business_revenue=business,disposal_date=str(disposal));save_payload(c,x,payload)

def entry_page(c,x,company):
    adjustments,inc,tax_result,reserves=computed(c,x,company);preview=report.html(company['name'],x['year'],x,adjustments,inc,tax_result,reserves);xlsx=report.workbook(company['name'],x['year'],x,adjustments,inc,tax_result,reserves)
    st.html('<div class="cc-title">법인세 계산 흐름표</div>');st.caption('기초정보입력과 각 세부 메뉴에서 저장한 내용을 기존 흐름표 구조로 표시합니다.')
    a,b=st.columns(2);a.download_button('인쇄용 HTML 내려받기',preview,file_name=f'{x["year"]}_{company["name"]}_법인세계산흐름표.html',mime='text/html',use_container_width=True);b.download_button('Excel 내려받기',xlsx,file_name=f'{x["year"]}_{company["name"]}_법인세계산흐름표.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)
    components.html(preview,height=1180,scrolling=True)

def _adjustment_group(name,existing=''):
    if existing in calc.ACCOUNT_GROUPS:return existing
    text=str(name or '')
    if '법인세' in text:return '법인세'
    if any(k in text for k in ['선급','퇴직급여충당','감가상각','유형자산','대손충당']):return '자산'
    if any(k in text for k in ['수익','환입','보상','매각','환수']):return '영업외수익'
    if any(k in text for k in ['이자비용','기부금','잡손실','처분손실']):return '영업외비용'
    return '원가'

GROUP_LABELS={'원가계정':'원가','고정자산':'자산','영업외비용':'영업외비용','영업외수익':'영업외수익','법인세':'법인세'}
GROUP_NAMES={v:k for k,v in GROUP_LABELS.items()}

def _adjustment_inline_grid(c,x,active,side,title,cost_label,sga_label):
    rows=[r for r in active if r['side']==side and not r['source_key'].startswith('reserve:')]
    st.html(f'<div class="cc-adjust-title">{title}</div>')
    with st.container(key=f'cc_{side}_grid'):
        heads=st.columns([1.05,1.25,1.05,1.0,1.0,1.2,.46,.46])
        for col,label in zip(heads,['계정 구분','과목','금액 · 직접입력',cost_label,sga_label,'근거·메모','저장','삭제']):col.html(f'<div class="cc-grid-head">{label}</div>')
        for r in rows:
            cols=st.columns([1.05,1.25,1.05,1.0,1.0,1.2,.46,.46]);prefix=f'cc_{side}_{r["id"]}'
            current=GROUP_NAMES.get(r.get('account_group') or '원가','원가계정');group_label=cols[0].selectbox('계정 구분',list(GROUP_LABELS),index=list(GROUP_LABELS).index(current),key=prefix+'_group',label_visibility='collapsed',disabled=x['status']=='confirmed');group=GROUP_LABELS[group_label]
            name=cols[1].text_input('과목',value=r['name'],key=prefix+'_name',label_visibility='collapsed',disabled=x['status']=='confirmed');amount=money_field(cols[2],'금액',r['amount'],key=prefix+'_amount',disabled=x['status']=='confirmed',label_visibility='collapsed')
            old_cost=r['amount'] if r['target']=='원가' else r.get('cost_amount',0) if r['target']=='공통' else 0
            if group=='원가':cost=money_field(cols[3],cost_label,old_cost,key=prefix+'_cost',disabled=x['status']=='confirmed',label_visibility='collapsed');cols[4].html(f'<div class="cc-grid-auto">{amount-cost:,}</div>')
            else:cost=0;cols[3].text_input(cost_label,value='',key=prefix+'_cost_blank',disabled=True,label_visibility='collapsed');cols[4].html('<div class="cc-grid-na">―</div>')
            note=cols[5].text_input('근거·메모',value=r.get('note',''),key=prefix+'_note',label_visibility='collapsed',disabled=x['status']=='confirmed')
            if cols[6].button('저장',key=prefix+'_save',disabled=x['status']=='confirmed',use_container_width=True):
                if not name.strip():st.error('과목을 입력하세요.');return
                if group=='원가' and (cost<0 or cost>amount):st.error(name+'의 원가 조정액은 0 이상이며 금액 이하여야 합니다.');return
                target='원가' if group=='원가' and cost==amount else '공통' if group=='원가' and cost else '판관비';db.save_adjustment(c,x,side,name,amount,target,cost,note,r['id'],r['version'],account_group=group);refresh()
            if cols[7].button('삭제',key=prefix+'_delete',disabled=x['status']=='confirmed',use_container_width=True):db.delete_adjustment(c,x,r['id'],r['version'],'입력표에서 삭제');refresh()
        # Always-visible new row at the bottom of the same grid.
        cols=st.columns([1.05,1.25,1.05,1.0,1.0,1.2,.94]);prefix=f'cc_{side}_new';group_label=cols[0].selectbox('새 계정 구분',list(GROUP_LABELS),key=prefix+'_group',label_visibility='collapsed',disabled=x['status']=='confirmed');group=GROUP_LABELS[group_label];name=cols[1].text_input('새 과목',placeholder='새 과목 추가',key=prefix+'_name',label_visibility='collapsed',disabled=x['status']=='confirmed');amount=money_field(cols[2],'새 금액',0,key=prefix+'_amount',disabled=x['status']=='confirmed',label_visibility='collapsed')
        if group=='원가':cost=money_field(cols[3],cost_label,0,key=prefix+'_cost',disabled=x['status']=='confirmed',label_visibility='collapsed');cols[4].html(f'<div class="cc-grid-auto">{amount-cost:,}</div>')
        else:cost=0;cols[3].text_input(cost_label,value='',key=prefix+'_cost_blank',disabled=True,label_visibility='collapsed');cols[4].html('<div class="cc-grid-na">―</div>')
        note=cols[5].text_input('새 근거·메모',key=prefix+'_note',label_visibility='collapsed',disabled=x['status']=='confirmed')
        if cols[6].button('＋ 추가',key=prefix+'_add',type='primary',disabled=x['status']=='confirmed',use_container_width=True):
            if not name.strip():st.error('새 과목명을 입력하세요.');return
            if group=='원가' and (cost<0 or cost>amount):st.error('원가 조정액은 0 이상이며 금액 이하여야 합니다.');return
            target='원가' if group=='원가' and cost==amount else '공통' if group=='원가' and cost else '판관비';db.save_adjustment(c,x,side,name,amount,target,cost,note,account_group=group);refresh()
    current=[r for r in active if r['side']==side];totals=calc.adjustment_totals(current)
    st.html(f'<div class="cc-adjust-total">계　금액 {totals[side+"_amount"]:,}　/　{cost_label} {totals[side+"_cost"]:,}　/　{sga_label} {totals[side+"_sga"]:,}</div>')

def adjustment_page(c,x):
    st.html('<div class="cc-title">과목별 세무조정 내역</div>');st.caption('표의 각 행에서 직접 수정·저장·삭제할 수 있습니다. 새 과목은 각 표의 마지막 행에서 바로 추가합니다. 원가계정 외 구분은 금액만 입력합니다.')
    active=db.adjustments(c,x['id']);deleted=[r for r in db.adjustments(c,x['id'],True) if r['deleted']]
    left,right=st.columns(2,gap='medium')
    with left:_adjustment_inline_grid(c,x,active,'add','익금산입 및 손금불산입','원가부인','판관비부인')
    with right:_adjustment_inline_grid(c,x,active,'deduct','손금산입 및 익금불산입','원가추인','판관비추인')
    linked=[r for r in active if r['source_key'].startswith('reserve:')]
    if linked:
        st.caption('유보잔액 연계 항목은 유보잔액 관리에서 수정합니다.');show_frame(pd.DataFrame([{'과목':r['name'],'금액':r['amount'],'구분':'익금산입' if r['side']=='add' else '손금산입'} for r in linked]),hide_index=True,use_container_width=True)
    if deleted:
        with st.expander('삭제자료 복구'):
            did=st.selectbox('삭제 조정항목',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z))
            if st.button('조정항목 복구',disabled=x['status']=='confirmed'):r=next(r for r in deleted if r['id']==did);db.restore_adjustment(c,x,did,r['version']);refresh()

def _statement_uploads(c,x,kinds,prefix):
    active=[r for r in db.imports(c,x['id']) if not r['deleted'] and r['kind'] in kinds]
    for start in range(0,len(kinds),3):
        group=kinds[start:start+3];cols=st.columns(len(group))
        for col,kind in zip(cols,group):
            with col:
                st.markdown('**'+kind+' 원장**');up=st.file_uploader('XLS, XLSX 또는 CSV',type=['xls','xlsx','csv'],key=prefix+'_'+kind);parsed=None
                if up:
                    try:
                        original=ledger.parse(up.name,up.getvalue());parsed=db.filter_statement_rows(original);excluded=len(original)-len(parsed);st.caption(f'{len(parsed):,}행 인식'+(f' · [월 계]·[누 계] {excluded:,}행 제외' if excluded else '')+' · 등록 전 미리보기');show_frame(pd.DataFrame(parsed[:10]),hide_index=True,use_container_width=True)
                    except ValueError as e:st.error(str(e))
                if st.button(kind+' 원장 등록',key=prefix+'_save_'+kind,disabled=not parsed or x['status']=='confirmed',use_container_width=True):db.save_statement_import(c,x,kind,up.name,up.getvalue(),parsed);refresh()
    if active:
        with st.expander('등록 원장 관리'):
            show_frame(pd.DataFrame(active),hide_index=True,use_container_width=True);iid=st.selectbox('삭제할 원장',[r['id'] for r in active],format_func=lambda z:next(r['kind']+' · '+r['name'] for r in active if r['id']==z),key=prefix+'_delete_select')
            if st.button('선택 원장 삭제',key=prefix+'_delete',disabled=x['status']=='confirmed'):db.delete_import(c,x,iid);refresh()

def tax_dues_page(c,x):
    st.html('<div class="cc-title">세금과공과명세서</div>');st.caption('원가·판관비 원장의 적요 문구로 손금불산입 검토대상을 찾습니다. 자동판정은 작업자가 표에서 직접 변경한 뒤 세무조정에 반영합니다.')
    _statement_uploads(c,x,db.TAX_DUES_KINDS,'cc_tax_dues')
    with st.expander('손금불산입 적요 문구 추가·수정·삭제',expanded=True):
        rules=db.statement_rules(c,x['company_id']);deleted=[r for r in db.statement_rules(c,x['company_id'],'tax_dues',True) if r['deleted']]
        show_frame(pd.DataFrame([{'ID':r['id'],'검색 문구':r['keyword']} for r in rules]),hide_index=True,use_container_width=True)
        selected=st.selectbox('수정할 문구',['새 문구']+[r['id'] for r in rules],format_func=lambda z:'새 문구' if z=='새 문구' else next(r['keyword'] for r in rules if r['id']==z),key='cc_tax_dues_rule_select');rr=next((r for r in rules if r['id']==selected),None)
        with st.form('cc_tax_dues_rule_form'):
            keyword=st.text_input('적요에 포함되는 문구',value=rr['keyword'] if rr else '');save_rule=st.form_submit_button('문구 저장·재판정',disabled=x['status']=='confirmed')
        if save_rule:db.save_statement_rule(c,x,keyword,rr['id'] if rr else None,rr['version'] if rr else None);refresh()
        if rr and st.button('선택 문구 삭제',disabled=x['status']=='confirmed'):db.delete_statement_rule(c,x,rr['id'],rr['version']);refresh()
        if deleted:
            rid=st.selectbox('삭제 문구 복구',[r['id'] for r in deleted],format_func=lambda z:next(r['keyword'] for r in deleted if r['id']==z),key='cc_tax_dues_rule_restore')
            if st.button('문구 복구',disabled=x['status']=='confirmed'):r=next(r for r in deleted if r['id']==rid);db.restore_statement_rule(c,x,rid,r['version']);refresh()
    rows=db.statement_ledger_rows(c,x['id'],db.TAX_DUES_KINDS)
    if not rows:st.info('세금과공과(원가) 또는 세금과공과(판관비) 원장을 등록하세요.');return
    frame=pd.DataFrame([{'ID':r['id'],'구분':'원가' if r['kind'].endswith('(원가)') else '판관비','일자':r['posting_date'],'계정과목':r['account'],'적요':r['description'],'차변금액':r['debit'] if r['debit'] is not None else r['amount'],'찾은 문구':str(r['business']).replace('자동:','') if str(r['business']).startswith('자동:') else '수동','세무조정 판정':r['classification'] or '손금산입'} for r in rows])
    edited=st.data_editor(frame,hide_index=True,use_container_width=True,disabled=['ID','구분','일자','계정과목','적요','차변금액','찾은 문구'],column_config={'차변금액':st.column_config.NumberColumn(format='%,d'),'세무조정 판정':st.column_config.SelectboxColumn(options=['손금불산입','손금산입'])},key='cc_tax_dues_grid')
    amounts={'원가':0,'판관비':0}
    for _,r in edited.iterrows():
        if r['세무조정 판정']=='손금불산입':amounts[r['구분']]+=money(r['차변금액'])
    cards=st.columns(3);cards[0].metric('원가 손금불산입',f'{amounts["원가"]:,}원');cards[1].metric('판관비 손금불산입',f'{amounts["판관비"]:,}원');cards[2].metric('손금불산입 합계',f'{sum(amounts.values()):,}원')
    tax_summary=pd.DataFrame([{'구분':'원가 손금불산입','금액':amounts['원가']},{'구분':'판관비 손금불산입','금액':amounts['판관비']},{'구분':'손금불산입 합계','금액':sum(amounts.values())}])
    a,b,c1,d=st.columns(4)
    if a.button('판정내역 저장',type='primary',disabled=x['status']=='confirmed',use_container_width=True):db.classify_tax_dues_rows(c,x,[(int(r['ID']),r['세무조정 판정']) for _,r in edited.iterrows()]);refresh()
    b.download_button('인쇄용 계산내역',statement_print_html('세금과공과명세서',x['year'],[('손금불산입 집계',tax_summary),('원장 판정내역',edited)]),file_name=f'{x["year"]}_세금과공과명세서_인쇄.html',mime='text/html',use_container_width=True)
    c1.download_button('CSV 내려받기',edited.to_csv(index=False).encode('utf-8-sig'),file_name=f'{x["year"]}_세금과공과명세서.csv',mime='text/csv',use_container_width=True)
    if d.button('세무조정 항목에 반영',disabled=x['status']=='confirmed',use_container_width=True):db.classify_tax_dues_rows(c,x,[(int(r['ID']),r['세무조정 판정']) for _,r in edited.iterrows()]);db.sync_tax_dues_adjustments(c,x);refresh()

def _prepaid_payload(x,items,overrides,opening_rows):
    payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['prepaid_overrides']=overrides;payload['prepaid_opening_rows']=opening_rows;payload.pop('prepaid_initial_opening',None)
    payload['prepaid_closing']=[{k:r.get(k) for k in ['source_key','kind','description','identifier','site','counterparty','ending']} for r in items if r.get('amount') and r.get('ending')]
    return payload
def prepaid_page(c,x):
    st.html('<div class="cc-title">선급비용 계산현황</div>');st.caption('기준일은 결산연도 12월 31일입니다. 같은 차량번호는 계약별 일할계산 후 차량번호별로 합산하며, 지급임차료는 지번별로 합산합니다.')
    _statement_uploads(c,x,db.PREPAID_KINDS,'cc_prepaid')
    prior=db.prior_case(c,x['company_id'],x['year']);prior_closing=prior.get('prepaid_closing',[]) if prior else [];overrides=dict(x.get('prepaid_overrides',{}));current=db.statement_ledger_rows(c,x['id'],db.PREPAID_KINDS);items=prepaid.build(current,[],overrides,x['year'])
    saved_openings=x.get('prepaid_opening_rows')
    if saved_openings is not None:opening_rows=[dict(r) for r in saved_openings]
    elif prior_closing:opening_rows=prepaid.grouped_openings(prior_closing)
    else:
        opening_rows=[];legacy=dict(x.get('prepaid_initial_opening',{}))
        for kind,amount in legacy.items():
            if money(amount):opening_rows.append({'source_key':prepaid.opening_source_key(kind,'미분류 전기잔액',len(opening_rows)),'kind':kind,'identifier':'미분류 전기잔액','opening':money(amount),'note':'기존 총액 입력자료 · 차량번호·지번을 수정하세요.'})
        for item in items:
            if item.get('opening'):opening_rows.append({'source_key':prepaid.opening_source_key(item['kind'],item['identifier'],len(opening_rows)),'kind':item['kind'],'identifier':item['identifier'],'opening':item['opening'],'note':'기존 개별 입력자료'})
    if prior_closing and saved_openings is None:st.success(f'{x["year"]-1}년 기말 선급비용 {sum(int(r.get("ending") or 0) for r in prior_closing):,}원을 차량번호·지번별 전기잔액으로 자동 이월했습니다.')
    elif not prior_closing:st.info('최초 적용연도입니다. 당기계약 행의 전기잔액 칸에 직접 입력하세요. 당기계약이 없는 차량번호·지번만 전기잔액 전용 행으로 추가합니다.')
    extra_key=f'cc_prepaid_extra_openings_{x["id"]}'
    if extra_key not in st.session_state:st.session_state[extra_key]=[]
    with st.expander('＋ 당기계약이 없는 전기잔액 전용 행 추가'):
        with st.form('cc_prepaid_add_opening_form',clear_on_submit=True):
            add_cols=st.columns([1.2,1.2,1,1.4]);add_kind=add_cols[0].selectbox('구분',db.PREPAID_KINDS,key='cc_prepaid_add_kind');add_identifier=add_cols[1].text_input('차량번호·지번',key='cc_prepaid_add_identifier');add_opening=money_field(add_cols[2],'전기잔액',0,key='cc_prepaid_add_amount');add_note=add_cols[3].text_input('비고',key='cc_prepaid_add_note');add_submit=st.form_submit_button('전기잔액 전용 행 추가',disabled=x['status']=='confirmed')
        if add_submit:
            if not add_identifier.strip() or add_opening<=0:st.error('차량번호·지번과 전기잔액을 입력하세요.')
            else:
                st.session_state[extra_key].append({'source_key':prepaid.opening_source_key(add_kind,add_identifier,len(st.session_state[extra_key])),'kind':add_kind,'identifier':add_identifier.strip(),'opening':add_opening,'note':add_note});refresh()
    integrated=prepaid.merge_openings(items,[*opening_rows,*st.session_state[extra_key]])
    if not integrated:st.info('보험료 또는 지급임차료 원장을 등록하거나 전기잔액 전용 행을 추가하세요.');return
    st.markdown('**당기원장 계약별 통합 계산내역**')
    st.caption('연파랑 입력란에서 차량번호·지번, 전기잔액, 계약기간을 직접 수정합니다. 같은 차량번호·지번의 전기잔액은 첫 계약행에 표시되며 검산표에서 한 번만 합산됩니다.')
    detail=pd.DataFrame([{'자료키':r['source_key'],'자료구분':'당기계약' if r.get('amount') else '전기잔액 전용','구분':r['kind'],'차량번호·지번':r['identifier'],'현장명':r.get('site',''),'거래처':r.get('counterparty',''),'전기잔액':r['opening'],'원장금액':r['amount'],'계약시작일':r['start'],'계약종료일':r['end'],'선급비용':r['ending'],'당기비용':r['current_expense'],'전기잔액+당기비용':r['combined'],'비고':r.get('note',''),'반영상태':('저장 제외 · '+prepaid.validation_error(r)) if prepaid.validation_error(r) else '정상 반영','전기잔액행 삭제':False} for r in integrated])
    edited=st.data_editor(detail,hide_index=True,use_container_width=True,disabled=['자료키','자료구분','구분','현장명','거래처','원장금액','선급비용','당기비용','전기잔액+당기비용','반영상태'],column_config={k:st.column_config.NumberColumn(format='%,d',min_value=0) for k in ['전기잔액','원장금액','선급비용','당기비용','전기잔액+당기비용']},key='cc_prepaid_integrated_grid')
    rebuilt=[];new_overrides={};ignored_current_deletes=0
    originals={r['source_key']:r for r in integrated}
    for _,row in edited.iterrows():
        key=row['자료키'];base=dict(originals[key]);delete=bool(row.get('전기잔액행 삭제'))
        if delete and not base.get('amount'):continue
        if delete and base.get('amount'):ignored_current_deletes+=1
        identifier=str(row['차량번호·지번'] or '').strip();opening=money(row['전기잔액']);note=str(row['비고'] or '')
        if base.get('amount'):
            change={'identifier':identifier,'start':str(row['계약시작일'] or ''),'end':str(row['계약종료일'] or ''),'opening':0,'note':note};base.update(change);base['opening']=opening;z=prepaid.calculate(base,x['year']);rebuilt.append(z)
            if not prepaid.validation_error(z):new_overrides[key]=change
        else:
            z={**base,'identifier':identifier,'opening':opening,'combined':opening,'note':note,'valid':True};rebuilt.append(z)
    excluded=[r for r in rebuilt if prepaid.validation_error(r)];included=[r for r in rebuilt if not prepaid.validation_error(r)]
    opening_rows_to_save=prepaid.opening_rows_from_items(included)
    grouped=prepaid.grouped(included);grouped_frame=pd.DataFrame([{'구분':r['kind'],'차량번호·지번':r['identifier'],'계약건수':r['contract_count'],'전기잔액':r['opening'],'원장금액':r['amount'],'선급비용':r['ending'],'당기비용':r['current_expense'],'전기+당기비용':r['combined']} for r in grouped]);st.markdown('**차량번호·지번별 합산 결과**');show_frame(grouped_frame,hide_index=True,use_container_width=True)
    sums=prepaid.summary(included);cards=st.columns(3)
    for col,kind in zip(cards,db.PREPAID_KINDS):col.metric(kind+' 기말 선급비용',f'{sums[kind]["ending"]:,}원',delta=f'전기 {sums[kind]["opening"]:,}원')
    if ignored_current_deletes:st.info('당기 원장에서 가져온 계약행은 삭제하지 않습니다. 전기잔액 전용 행만 삭제할 수 있습니다.')
    if excluded:
        reasons={}
        for row in excluded:reasons[prepaid.validation_error(row)]=reasons.get(prepaid.validation_error(row),0)+1
        st.warning(' · '.join(f'{reason} {count:,}건' for reason,count in reasons.items())+'은 합계·저장·세무조정 반영에서 제외됩니다. 화면에서 차량번호·지번 또는 기간을 수정하면 다시 포함됩니다.')
    current_print=pd.DataFrame([{'자료구분':'당기계약' if r.get('amount') else '전기잔액 전용','구분':r['kind'],'차량번호·지번':r['identifier'],'현장명':r.get('site',''),'거래처':r.get('counterparty',''),'전기잔액':r['opening'],'원장금액':r['amount'],'계약시작일':r['start'],'계약종료일':r['end'],'선급비용':r['ending'],'당기비용':r['current_expense'],'전기잔액+당기비용':r['combined'],'반영상태':('저장 제외 · '+prepaid.validation_error(r)) if prepaid.validation_error(r) else '정상 반영'} for r in rebuilt])
    a,b,c1,d=st.columns(4);payload=_prepaid_payload(x,included,new_overrides,opening_rows_to_save)
    if a.button('계산내역 저장',type='primary',disabled=x['status']=='confirmed',use_container_width=True):st.session_state[extra_key]=[];db.save_case(c,x,payload,x['version']);refresh()
    b.download_button('인쇄용 계산내역',statement_print_html('선급비용명세서',x['year'],[('당기원장 계약별 통합 계산내역',current_print),('차량번호·지번별 검산 결과',grouped_frame)]),file_name=f'{x["year"]}_선급비용명세서_인쇄.html',mime='text/html',use_container_width=True)
    c1.download_button('CSV 내려받기',grouped_frame.to_csv(index=False).encode('utf-8-sig'),file_name=f'{x["year"]}_선급비용명세서.csv',mime='text/csv',use_container_width=True)
    if d.button('세무조정·유보잔액에 반영',disabled=x['status']=='confirmed',use_container_width=True):st.session_state[extra_key]=[];db.save_case(c,x,payload,x['version']);db.sync_prepaid_adjustments(c,x,sums);refresh()

def promotion_page(c,x):
    st.html('<div class="cc-title">기업업무추진비 조정명세서 금액 집계</div>');st.caption('위하고 입력 행 ⑤~⑱을 그대로 구성합니다. 수입금액·수입금액 한도·한도초과액은 계산하지 않으며, 6개 원장의 차변 거래금액만 사용합니다.')
    _statement_uploads(c,x,db.PROMOTION_KINDS,'cc_promotion')
    ledger_rows=db.statement_ledger_rows(c,x['id'],db.PROMOTION_KINDS)
    if not ledger_rows:st.info('접대비(신용카드등·경조사비·기타접대비)의 원가·판관비 원장을 등록하세요.');return

    settings=dict(x.get('promotion_settings',{}));threshold_cols=st.columns([1,1,2])
    condolence_threshold=money_field(threshold_cols[0],'경조사비 기준금액',settings.get('condolence_threshold',200000),key='cc_promotion_condolence_threshold',disabled=x['status']=='confirmed')
    general_threshold=money_field(threshold_cols[1],'일반 기준금액',settings.get('general_threshold',30000),key='cc_promotion_general_threshold',disabled=x['status']=='confirmed')
    threshold_cols[2].info('기본 자동판정: 경조사비는 20만원 초과 거래, 일반 기업업무추진비는 3만원 초과 거래입니다. 원장만으로 확정할 수 없는 금액은 아래 표에서 직접 수정합니다.')
    working=promotion.build_rows(ledger_rows,x.get('promotion_overrides',{}),condolence_threshold,general_threshold)
    labels={
        'private':'⑥ 사적사용','condolence_unused':'⑨ 경조 미사용','condolence_total':'⑩ 경조 총액',
        'foreign_unused':'⑪ 국외 미사용','foreign_total':'⑫ 국외 총액','farmer_unsubmitted':'⑬ 농어민 미제출',
        'farmer_total':'⑭ 농어민 총액','general_unused':'⑮ 일반 미사용','general_total':'⑯ 일반 총액',
        'culture':'문화사업','traditional_market':'전통시장','local_gift':'지역사랑상품권'}
    detail_rows=[]
    for row in working:
        item={'ID':row['id'],'판/도':row['division'],'원장 구분':row['kind'],'일자':row['date'],'거래처':row['counterparty'],'적요':row['description'],'차변금액':row['amount']}
        item.update({label:row[field] for field,label in labels.items()});detail_rows.append(item)
    st.markdown('**거래별 판정·수정**')
    st.caption('파란색 차변금액은 원장값이며 변경하지 않습니다. ⑥·⑨~⑯과 별도 구분금액은 작업자가 거래별로 직접 수정할 수 있습니다. 각 입력금액은 해당 거래의 차변금액을 초과할 수 없습니다.')
    detail=pd.DataFrame(detail_rows)
    editable_columns=list(labels.values());disabled_columns=['ID','판/도','원장 구분','일자','거래처','적요','차변금액']
    edited=st.data_editor(detail,hide_index=True,use_container_width=True,disabled=disabled_columns,column_config={name:st.column_config.NumberColumn(format='%,d') for name in ['차변금액',*editable_columns]},key='cc_promotion_grid')
    by_id={row['id']:dict(row) for row in working};reverse={label:field for field,label in labels.items()};rebuilt=[]
    for _,record in edited.iterrows():
        row=by_id[int(record['ID'])]
        for label,field in reverse.items():row[field]=money(record[label])
        rebuilt.append(row)
    errors=promotion.validate(rebuilt)
    if errors:
        st.error('\n'.join(errors[:10])+(f'\n외 {len(errors)-10:,}건' if len(errors)>10 else ''))

    summary=promotion.summary(rebuilt);summary_rows=[]
    for label,values in summary:
        if values is None:summary_rows.append({'위하고 입력 구분':label,'합계':None,'접대비(기업업무추진비)(판)':None,'접대비(기업업무추진비)(도)':None})
        else:summary_rows.append({'위하고 입력 구분':label,'합계':values['합계'],'접대비(기업업무추진비)(판)':values['판'],'접대비(기업업무추진비)(도)':values['도']})
    st.markdown('**위하고 입력용 집계금액**');show_frame(pd.DataFrame(summary_rows),hide_index=True,use_container_width=True)
    account=summary[0][1];disallowance=summary[16][1]
    cards=st.columns(4);cards[0].metric('⑤ 계정금액',f'{account["합계"]:,}원');cards[1].metric('판관비(판)',f'{account["판"]:,}원');cards[2].metric('공사원가(도)',f'{account["도"]:,}원');cards[3].metric('⑱ 부인액',f'{disallowance["합계"]:,}원')

    payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['promotion_settings']={'condolence_threshold':condolence_threshold,'general_threshold':general_threshold};payload['promotion_overrides']=promotion.overrides_from_rows(rebuilt)
    save_col,reset_col,print_col,excel_col,csv_col=st.columns(5)
    if save_col.button('판정내역 저장',type='primary',disabled=x['status']=='confirmed' or bool(errors),use_container_width=True):db.save_case(c,x,payload,x['version']);refresh()
    if reset_col.button('자동 판정으로 초기화',disabled=x['status']=='confirmed',use_container_width=True):
        reset_payload=dict(payload);reset_payload['promotion_overrides']={};db.save_case(c,x,reset_payload,x['version']);refresh()
    print_col.download_button('인쇄용 계산내역',statement_print_html('기업업무추진비명세서',x['year'],[('위하고 입력용 집계금액',pd.DataFrame(summary_rows)),('거래별 판정내역',edited)]),file_name=f'{x["year"]}_기업업무추진비명세서_인쇄.html',mime='text/html',use_container_width=True)
    out=BytesIO()
    with pd.ExcelWriter(out,engine='openpyxl') as writer:pd.DataFrame(summary_rows).to_excel(writer,index=False,sheet_name='위하고 입력금액');edited.to_excel(writer,index=False,sheet_name='거래별 판정내역')
    excel_col.download_button('Excel 내려받기',out.getvalue(),file_name=f'{x["year"]}_기업업무추진비_위하고입력.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)
    csv_col.download_button('CSV 내려받기',pd.DataFrame(summary_rows).to_csv(index=False).encode('utf-8-sig'),file_name=f'{x["year"]}_기업업무추진비_위하고입력.csv',mime='text/csv',use_container_width=True)

def adjustment_statement_page(c,x,name):
    if name=='세금과공과명세서':return tax_dues_page(c,x)
    if name=='선급비용명세서':return prepaid_page(c,x)
    if name=='기업업무추진비명세서':return promotion_page(c,x)
    st.html(f'<div class="cc-title">{name}</div>');st.info('원본 명세서 양식과 계산 기준을 반영하기 전까지 임의 계산하지 않습니다.')

def import_page(c,x,embedded=False):
    if not embedded:st.html('<div class="cc-title">계정별 원장 업로드·소득구분</div>')
    else:st.subheader('소득구분용 원장 업로드·적요 분류')
    kind=st.selectbox('원장 종류',['합계잔액·계정별원장','영업외수익','영업외비용']);up=st.file_uploader('XLSX 또는 CSV 원장',type=['xlsx','csv'])
    parsed=None
    if up:
        try:parsed=ledger.parse(up.name,up.getvalue());show_frame(pd.DataFrame(parsed[:200]),hide_index=True,use_container_width=True);st.caption(f'전체 {len(parsed):,}행 중 최대 200행 미리보기')
        except ValueError as e:st.error(str(e))
    if st.button('미리보기 자료 등록',disabled=not parsed or x['status']=='confirmed'):
        db.save_import(c,x,kind,up.name,up.getvalue(),parsed);refresh()
    imports=db.imports(c,x['id']);active=[r for r in imports if not r['deleted']]
    if active:
        st.subheader('등록 원장');show_frame(active,hide_index=True,use_container_width=True)
        if db.imports_need_amount_rebuild(c,x['id']):
            st.warning('기존 원장에 잔액 기준 금액이 남아 있습니다. 아래 버튼을 한 번 누르면 원본 파일을 다시 읽어 영업외수익은 대변, 영업외비용은 차변 기준으로 고칩니다.')
            if st.button('기존 원장 차변·대변 기준 재계산',type='primary',disabled=x['status']=='confirmed'):
                count=db.rebuild_ledger_amounts(c,x);st.success(f'{count:,}개 원장을 차변·대변 기준으로 재계산했습니다.');refresh()
        iid=st.selectbox('관리할 원장',[r['id'] for r in active],format_func=lambda z:next(r['kind']+' · '+r['name'] for r in active if r['id']==z))
        if st.button('선택 원장 삭제',disabled=x['status']=='confirmed'):db.delete_import(c,x,iid);refresh()
    allrows=db.ledger_rows(c,x['id'])
    if allrows:
        with st.expander('감면분 적요 문구 관리·추천',expanded=True):
            rules=db.income_rules(c,x['company_id']);deleted_rules=[r for r in db.income_rules(c,x['company_id'],True) if r['deleted']]
            st.caption('잡이익 적요에서 환입, 기부금시인액, 보상비, 고재매각, 환수 등의 등록 문구를 찾아 감면분으로 분류합니다.')
            show_frame(pd.DataFrame([{'ID':r['id'],'적용 대상':'계정과목' if r['kind']=='account' else '적요','문구':r['keyword']} for r in rules]),hide_index=True,use_container_width=True)
            selected=st.selectbox('수정할 감면분 문구',['새 문구']+[r['id'] for r in rules],format_func=lambda z:'새 문구' if z=='새 문구' else next(r['keyword'] for r in rules if r['id']==z));rr=next((r for r in rules if r['id']==selected),None)
            with st.form('cc_income_rule'):
                q1,q2=st.columns(2);rule_kind=q1.selectbox('검색 대상',['description','account'],index=['description','account'].index(rr['kind']) if rr else 0,format_func=lambda z:'적요' if z=='description' else '계정과목');keyword=q2.text_input('포함 문구',value=rr['keyword'] if rr else '');rule_save=st.form_submit_button('문구 저장·원장 재분류',disabled=x['status']=='confirmed')
            if rule_save:db.save_income_rule(c,x,rule_kind,keyword,rr['id'] if rr else None,rr['version'] if rr else None);refresh()
            if rr and st.button('선택 문구 삭제',disabled=x['status']=='confirmed'):db.delete_income_rule(c,x,rr['id'],rr['version']);refresh()
            recommendations=db.rule_recommendations(c,x)
            if recommendations:st.markdown('**추천 문구**');show_frame(pd.DataFrame(recommendations),hide_index=True,use_container_width=True)
            if st.button('현재 문구로 원장 다시 분류',disabled=x['status']=='confirmed'):db.apply_income_rules(c,x);refresh()
            if deleted_rules:
                rid=st.selectbox('삭제 문구 복구',[r['id'] for r in deleted_rules],format_func=lambda z:next(r['keyword'] for r in deleted_rules if r['id']==z))
                if st.button('감면분 문구 복구',disabled=x['status']=='confirmed'):r=next(r for r in deleted_rules if r['id']==rid);db.restore_income_rule(c,x,rid,r['version']);refresh()
        summary=ledger.aggregate(allrows)
        if st.button('원장 집계금액을 파란색 항목에 적용',disabled=x['status']=='confirmed'):
            payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};values=dict(payload.get('values',{}));tax=dict(payload.get('tax',{}))
            for k in ['construction_revenue','service_revenue','cost','sga','nonop_income','nonop_expense']:
                if summary.get(k):values[k]=summary[k]
            for k in ['prepaid_corp_interim','prepaid_corp_withholding','prepaid_local']:
                if summary.get(k):tax[k]=summary[k]
            tax['prepaid_corp']=money(tax.get('prepaid_corp_interim'))+money(tax.get('prepaid_corp_withholding'))
            payload.update(values=values,tax=tax);save_payload(c,x,payload)
        subset=[r for r in allrows if r['kind']=='영업외수익' and '잡이익' in db.normalized(r['account'])]
        if subset:
            st.subheader('잡이익 적요 분류');frame=pd.DataFrame([{'ID':r['id'],'구분':r['kind'],'계정과목':r['account'],'적요':r['description'],'금액':r['amount'],'소득구분':r['classification']} for r in subset]);edited=st.data_editor(frame,hide_index=True,use_container_width=True,disabled=['ID','구분','계정과목','적요','금액'],column_config={'소득구분':st.column_config.SelectboxColumn(options=['','감면분','기타분'])})
            if st.button('소득구분 저장',disabled=x['status']=='confirmed'):db.classify_rows(c,x,[(int(r['ID']),r['소득구분'],'') for _,r in edited.iterrows()]);refresh()
    deleted=[r for r in imports if r['deleted']]
    if deleted:
        with st.expander('삭제 원장 복구'):
            iid=st.selectbox('삭제 원장',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z),key='cc_restore_import')
            if st.button('원장 복구'):db.restore_import(c,x,iid);refresh()

def progress_page(c,x,company):
    st.html('<div class="cc-title">공사수입·원가대비 및 진행률 조정 검산</div>')
    st.caption('현장별 공사수입·원가를 집계하고 예상원가율에 따른 진행률 조정액을 법인세 계산 흐름표와 검산합니다.')
    up=st.file_uploader('공사수입·원가대비표 Excel',type=['xlsx'],key='cc_progress_upload');parsed=None;sheet=''
    if up:
        try:
            choices=progress.sheet_candidates(up.getvalue(),x['year'],company['name'])
            sheet=st.selectbox('가져올 법인·연도 시트',choices) if choices else ''
            if sheet:sheet,parsed=progress.parse(up.getvalue(),x['year'],company['name'],sheet);st.success(f'{sheet} · 현장 {len(parsed):,}건을 확인했습니다.');show_frame(pd.DataFrame(parsed[:20]),hide_index=True,use_container_width=True)
        except ValueError as e:st.error(str(e))
    if st.button('미리보기 현장자료 등록·갱신',type='primary',disabled=not parsed or x['status']=='confirmed'):
        try:db.save_progress_import(c,x,up.name,sheet,up.getvalue(),parsed);refresh()
        except ValueError as e:st.error(str(e))
    rows=db.progress_projects(c,x['id']);extra=dict(x.get('progress',{}));s=progress.summary(rows,extra);flow_revenue=money(x.get('values',{}).get('construction_revenue'));ledger_revenue=money(extra.get('ledger_construction_revenue',flow_revenue));flow_adjustment=money(x.get('values',{}).get('progress_adjustment'))
    tabs=st.tabs(['현장별 진행률 검산','원가율·조정값 관리','업로드·변경 이력','A4 출력·Excel'])
    with tabs[0]:
        cards=st.columns(5)
        for col,label,value in zip(cards,['원장 공사수입','현장표 당기 공사수입','공사수입 검산차이','진행률조정 예상액','흐름표 반영 차이'],[ledger_revenue,s['table_revenue'],ledger_revenue-s['table_revenue'],s['expected_adjustment'],flow_adjustment-s['expected_adjustment']]):col.metric(label,f'{value:,}원')
        view=[]
        for r in rows:
            z=progress.recalculate(r);view.append({'ID':r['id'],'검산':'예상원가율 확인' if not z['expected_cost_rate'] and z['status'] not in ['준공','준 공','준        공'] else '정상','발주처':z['client'],'공사명':z['project'],'계약공급가액':z['contract'],'전기수입':z['prior_revenue'],'당기수입':z['current_revenue'],'누계수입':z['total_revenue'],'전기원가':z['prior_cost'],'당기원가':z['current_cost'],'누계원가':z['total_cost'],'예상원가율(%)':round(z['expected_cost_rate']*100,4),'예상누적수입':z['expected_revenue'],'진행률조정':z['calculated_adjustment'],'상태':z['status']})
        show_frame(pd.DataFrame(view),hide_index=True,use_container_width=True,column_config={k:st.column_config.NumberColumn(format='%,d') for k in ['계약공급가액','전기수입','당기수입','누계수입','전기원가','당기원가','누계원가','예상누적수입','진행률조정']})
        if not rows:st.info('공사수입·원가대비표 Excel을 업로드하세요.')
        elif s['missing_rates']:st.warning(f'이월공사 중 예상원가율이 없는 현장 {s["missing_rates"]:,}건을 확인하세요.')
        if rows and st.button('검산값을 흐름표 공사수입·진행률조정(예상)에 반영',type='primary',disabled=x['status']=='confirmed'):
            payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};values=dict(payload.get('values',{}));extra.setdefault('ledger_construction_revenue',flow_revenue);values['construction_revenue']=s['table_revenue'];values['progress_adjustment']=s['expected_adjustment'];payload.update(values=values,progress=extra);save_payload(c,x,payload)
    with tabs[1]:
        if rows:
            edit=pd.DataFrame([{'ID':r['id'],'버전':r['version'],'발주처':r['client'],'공사명':r['project'],'착공일':r['start'],'준공일':r['end'],'계약공급가액':r['contract'],'전기수입':r['prior_revenue'],'당기수입':r['current_revenue'],'전기원가':r['prior_cost'],'당기원가':r['current_cost'],'예상원가율(%)':round(float(r['expected_cost_rate'])*100,5),'공종':r['trade'],'상태':r['status'],'전기진행률조정':r['prior_adjustment'],'가져온당기조정':r['current_adjustment'],'전기미완성':r['prior_unfinished'],'당기미완성':r['current_unfinished'],'비고':r['note']} for r in rows])
            edited=st.data_editor(edit,hide_index=True,use_container_width=True,disabled=['ID','버전'],column_config={k:st.column_config.NumberColumn(format='%,d') for k in ['계약공급가액','전기수입','당기수입','전기원가','당기원가','전기진행률조정','가져온당기조정','전기미완성','당기미완성']})
            if st.button('현장별 수정값 저장',disabled=x['status']=='confirmed'):
                for _,r in edited.iterrows():
                    vals={'client':r['발주처'],'project':r['공사명'],'start':r['착공일'],'end':r['준공일'],'contract':money(r['계약공급가액']),'prior_revenue':money(r['전기수입']),'current_revenue':money(r['당기수입']),'prior_cost':money(r['전기원가']),'current_cost':money(r['당기원가']),'expected_cost_rate':float(r['예상원가율(%)'] or 0)/100,'trade':r['공종'],'status':r['상태'],'prior_adjustment':money(r['전기진행률조정']),'current_adjustment':money(r['가져온당기조정']),'prior_unfinished':money(r['전기미완성']),'current_unfinished':money(r['당기미완성']),'note':r['비고']}
                    db.save_progress_project(c,x,int(r['ID']),int(r['버전']),vals)
                refresh()
            st.markdown('**현장 삭제**');pid=st.selectbox('삭제할 현장',[r['id'] for r in rows],format_func=lambda z:next(r['project'] for r in rows if r['id']==z));reason=st.text_input('현장 삭제 사유');ack=st.checkbox('현장 삭제가 합계와 흐름표 검산에 미치는 영향을 확인했습니다.')
            if st.button('선택 현장 삭제',disabled=x['status']=='confirmed' or not ack):r=next(r for r in rows if r['id']==pid);db.delete_progress_project(c,x,pid,r['version'],reason);refresh()
        with st.form('cc_progress_extra'):
            a,b=st.columns(2);extra['vat_adjustment']=money_field(a,'VAT 신고 진행률 조정',extra.get('vat_adjustment'),key='progress_vat_adjustment',disabled=x['status']=='confirmed');extra['manual_adjustment']=money_field(b,'기타 수동 조정',extra.get('manual_adjustment'),key='progress_manual_adjustment',disabled=x['status']=='confirmed');extra['note']=st.text_input('조정 근거·메모',value=extra.get('note',''),disabled=x['status']=='confirmed');save_extra=st.form_submit_button('조정값 저장',disabled=x['status']=='confirmed')
        if save_extra:
            payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['progress']=extra;save_payload(c,x,payload)
        deleted=[r for r in db.progress_projects(c,x['id'],True) if r['deleted']]
        if deleted:
            with st.expander('삭제 현장 복구'):
                pid=st.selectbox('복구할 현장',[r['id'] for r in deleted],format_func=lambda z:next(r['project'] for r in deleted if r['id']==z),key='cc_progress_restore_project')
                if st.button('선택 현장 복구',disabled=x['status']=='confirmed'):r=next(r for r in deleted if r['id']==pid);db.restore_progress_project(c,x,pid,r['version']);refresh()
    with tabs[2]:
        imports=db.progress_imports(c,x['id'],True);show_frame(pd.DataFrame(imports),hide_index=True,use_container_width=True)
        active=[r for r in imports if not r['deleted']];deleted=[r for r in imports if r['deleted']]
        if active:
            iid=st.selectbox('삭제할 업로드',[r['id'] for r in active],format_func=lambda z:next(r['name']+' · '+r['sheet_name'] for r in active if r['id']==z))
            if st.button('업로드 자료 삭제',disabled=x['status']=='confirmed'):db.delete_progress_import(c,x,iid);refresh()
        if deleted:
            iid=st.selectbox('복구할 업로드',[r['id'] for r in deleted],format_func=lambda z:next(r['name']+' · '+r['sheet_name'] for r in deleted if r['id']==z),key='cc_progress_restore_import')
            if st.button('업로드 자료 복구',disabled=x['status']=='confirmed'):db.restore_progress_import(c,x,iid);refresh()
    with tabs[3]:
        html=progress_report.html(company['name'],x['year'],rows,flow_revenue,extra);xlsx=progress_report.workbook(company['name'],x['year'],rows,flow_revenue,extra)
        a,b=st.columns(2);a.download_button('A4 인쇄 HTML',html,file_name=f'{x["year"]}_{company["name"]}_공사수입원가대비.html',mime='text/html',use_container_width=True);b.download_button('검산 Excel',xlsx,file_name=f'{x["year"]}_{company["name"]}_공사수입원가대비.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)
        components.html(html,height=800,scrolling=True)

def income_summary_page(c,x,company):
    adjustments,inc,tax,reserves=computed(c,x,company);st.caption('영업외수익은 잡이익 원장만 적요로 감면·기타 구분합니다. 영업외비용 전체 합계는 장부금액에서 손금불산입을 빼고 손금산입을 더하며, 감면분·기타분은 직접 입력합니다.')
    with st.form('cc_income_expense_manual'):
        st.markdown('**영업외비용 소득구분 직접 입력**');m1,m2,m3=st.columns(3)
        expense_exempt=money_field(m1,'감면분',inc['exempt_expense'],key='income_expense_exempt',disabled=x['status']=='confirmed');expense_other=money_field(m2,'기타분',inc['other_expense'],key='income_expense_other',disabled=x['status']=='confirmed');m3.metric('조정 후 전체 합계',f'{inc["totals"]["nonop_expense"]:,}원',delta=f'입력 차액 {inc["expense_check"]:,}원',delta_color='inverse' if inc['expense_check'] else 'off');save_expense=st.form_submit_button('영업외비용 구분 저장',type='primary',disabled=x['status']=='confirmed')
    if save_expense:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['income_manual']={'nonop_expense_exempt':expense_exempt,'nonop_expense_other':expense_other};save_payload(c,x,payload)
    if inc['expense_check']:st.error(f'영업외비용 감면분과 기타분의 합계가 조정 후 전체 합계와 {abs(inc["expense_check"]):,}원 차이납니다.')
    metrics=[('매출액','revenue'),('매출원가','cost'),('판매관리비','sga'),('영업외수익','nonop_income'),('영업외비용','nonop_expense'),('각사업연도소득','current_income'),('이월결손금','loss'),('과세표준','taxable')]
    view=[]
    for label,key in metrics:
        total_key={'revenue':'sales'}.get(key,key);row={'구분':label,'전체 합계':money(inc['totals'].get(total_key,sum(money(r[key]) for r in inc['rows'])))}
        if key in ['current_income','loss','taxable']:row['전체 합계']=sum(money(r[key]) for r in inc['rows'])
        row.update({r['name']:money(r[key]) for r in inc['rows']});view.append(row)
    frame=pd.DataFrame(view);money_cols=[c for c in frame.columns if c!='구분']
    styled=frame.style.format({c:'{:,.0f}' for c in money_cols}).set_properties(subset=money_cols,**{'text-align':'right'}).set_properties(subset=['구분'],**{'text-align':'center'}).apply(lambda r:['background-color:#fff600;font-weight:700' if r['구분'] in ['각사업연도소득','과세표준'] else 'background-color:#eef6ff' if r['구분']=='이월결손금' else '' for _ in r],axis=1)
    show_frame(styled,hide_index=True,use_container_width=True)
    flow=calc.flow(x.get('values',{}),adjustments);groups=calc.adjustment_group_totals(adjustments);basis=[]
    for label,key,flow_key in [('매출액','sales','sales'),('매출원가','cost','cost'),('판매관리비','sga','sga'),('영업외수익','nonop_income','nonop_income'),('영업외비용','nonop_expense','nonop_expense')]:
        total=money(inc['totals'][key]);base=money(flow[flow_key]);detail=''
        if key=='nonop_income':detail=f'익금산입 +{groups["영업외수익"]["add"]:,} / 익금불산입 -{groups["영업외수익"]["deduct"]:,}'
        elif key=='nonop_expense':detail=f'손금불산입 -{groups["영업외비용"]["add"]:,} / 손금산입 +{groups["영업외비용"]["deduct"]:,}'
        basis.append({'항목':label,'흐름표 금액':f'{base:,}','세무조정 계산':detail or f'{total-base:+,}','세무조정 반영액':f'{total-base:,}','소득구분 전체 합계':f'{total:,}'})
    st.markdown('**전체 합계 계산 근거**');show_frame(pd.DataFrame(basis),hide_index=True,use_container_width=True)
    classified=[r for r in db.ledger_rows(c,x['id']) if r['kind']=='영업외수익' and '잡이익' in db.normalized(r['account'])]
    if classified:
        st.markdown('**잡이익 적요 판정 내역**');st.caption('등록한 감면분 검색 문구가 잡이익 적요에 포함되면 감면분, 그 밖의 잡이익은 기타분으로 표시합니다.')
        detail=pd.DataFrame([{'구분':r['kind'],'계정과목':r['account'],'적요':r['description'],'판정 근거':str(r.get('business','')).replace('자동:',''),'소득구분':r['classification'],'금액':f'{r["amount"]:,}'} for r in classified])
        show_frame(detail,hide_index=True,use_container_width=True)
        sums=[]
        for cls in ['감면분','기타분']:
            sums.append({'구분':'영업외수익·잡이익','소득구분':cls,'합계금액':f'{sum(r["amount"] for r in classified if r["classification"]==cls):,}'})
        show_frame(pd.DataFrame(sums),hide_index=True,use_container_width=True)
    else:st.info('원장 업로드·적요 분류 탭에서 잡이익 원장을 등록하면 적요 판정 내역이 여기에 표시됩니다.')
    if inc['check']:st.error(f'업종별 매출액 합계와 매출계가 {inc["check"]:,}원 차이납니다.')
    with st.form('cc_losses'):
        losses=dict(x.get('losses',{}));cols=st.columns(min(4,len(inc['rows'])))
        for i,r in enumerate(inc['rows']):losses[r['name']]=money_field(cols[i%len(cols)],r['name']+' 이월결손금',losses.get(r['name']),key='loss_'+str(i),disabled=x['status']=='confirmed')
        save=st.form_submit_button('이월결손금 저장',disabled=x['status']=='confirmed')
    if save:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['losses']=losses;save_payload(c,x,payload)

def income_page(c,x,company):
    st.html('<div class="cc-title">소득구분계산서</div>')
    summary_tab,ledger_tab=st.tabs(['소득구분계산서','원장 업로드·적요 분류'])
    with summary_tab:income_summary_page(c,x,company)
    with ledger_tab:import_page(c,x,embedded=True)

def reserve_page(c,x):
    if x['status']!='confirmed' and db.sync_all_reserves(c,x):refresh()
    st.html('<div class="cc-title">유보잔액 관리대장</div>');rs=db.reserves(c,x['company_id']);deleted=[r for r in db.reserves(c,x['company_id'],True) if r['deleted']];summary=reserve_summary(c,x)
    show_frame(pd.DataFrame([{'ID':r['id'],'관리항목':r['name'],'발생연도':r['origin_year'],'최초유보액':r['initial_amount'],'기초유보액':r['beginning'],'당기증가액':r['increase'],'당기추인액':r['deduction'],'기말유보잔액':r['ending'],'반영':r['target']} for r in summary]),hide_index=True,use_container_width=True)
    selected=st.selectbox('등록·수정할 유보항목',['새 항목']+[r['id'] for r in rs],format_func=lambda z:'새 항목' if z=='새 항목' else next(r['name'] for r in rs if r['id']==z));r=next((r for r in rs if r['id']==selected),None)
    with st.form('cc_reserve'):
        a,b,c1=st.columns(3);name=a.text_input('관리항목',value=r['name'] if r else '');origin=b.number_input('발생연도',2000,2100,value=r['origin_year'] if r else x['year']);initial=money_field(c1,'최초 유보액',r['initial_amount'] if r else 0,key='reserve_initial',disabled=x['status']=='confirmed');target=st.selectbox('세무조정 반영 계정',db.RESERVE_TARGETS,index=db.RESERVE_TARGETS.index(r['target']) if r and r['target'] in db.RESERVE_TARGETS else 1);note=st.text_input('기간·추인계획·근거',value=r['note'] if r else '');save=st.form_submit_button('유보항목 저장',type='primary',disabled=x['status']=='confirmed')
    if save:db.save_reserve(c,x,name,origin,initial,target,note,r['id'] if r else None,r['version'] if r else None);refresh()
    if r:
        current=next((z for z in db.reserve_years(c,r['id']) if z['year']==x['year']),None)
        link=db.reserve_adjustment_status(c,x,r)
        if link['ambiguous']:st.error('같은 이름의 유보항목이 여러 개라 세무조정 자동 연결을 중지했습니다. 관리항목 이름을 구분해 주세요.')
        elif link['overage']:
            st.error(f'손금추인액이 사용 가능 잔액을 {link["overage"]:,}원 초과했습니다. 원본 금액은 변경하지 않았습니다.')
            st.info(f'사용 가능액 {link["available"]:,}원 / 입력된 손금추인액 {link["deduction"]:,}원입니다. 「세무조정 항목」에서 과목 「{r["name"]}」의 금액을 수정하거나 삭제한 뒤 다시 확인하세요.')
        elif link['count']:st.success(f'세무조정 {link["count"]:,}건 연계: 당기증가액 {link["increase"]:,}원 / 당기추인액 {link["deduction"]:,}원')
        with st.form('cc_reserve_year'):
            cols=st.columns(3);auto=bool(link['count']);increase=money_field(cols[0],'당기 유보 증가액',link['increase'] if auto else current['increase'] if current else 0,key='reserve_increase',disabled=x['status']=='confirmed' or auto);deduction=money_field(cols[1],'당기 손금추인액',link['deduction'] if auto else current['deduction'] if current else 0,key='reserve_deduction',disabled=x['status']=='confirmed' or auto);other=money_field(cols[2],'기타 조정액',current['other'] if current else 0,key='reserve_other',disabled=x['status']=='confirmed');saveyear=st.form_submit_button('당해연도 유보잔액 저장·세무조정 반영',disabled=x['status']=='confirmed' or link['ambiguous'] or bool(link['overage']))
        if saveyear:db.save_reserve_year(c,x,r['id'],x['year'],increase,deduction,other);refresh()
        show_frame(pd.DataFrame(db.reserve_years(c,r['id'])),hide_index=True,use_container_width=True)
        reason=st.text_input('유보항목 삭제 사유');ack=st.checkbox('이월·세무조정 영향을 확인했습니다.')
        if st.button('유보항목 삭제',disabled=x['status']=='confirmed' or not ack):db.delete_reserve(c,x,r['id'],r['version'],reason);refresh()
    if deleted:
        with st.expander('삭제자료 복구'):
            rid=st.selectbox('삭제 유보항목',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z));rr=next(r for r in deleted if r['id']==rid)
            if st.button('유보항목 복구'):db.restore_reserve(c,x,rid,rr['version']);refresh()

def tax_page(c,x,company):
    adjustments,inc,result,reserves=computed(c,x,company);st.html('<div class="cc-title">세액 계산</div>');st.caption('연파랑 칸은 작업자 입력, 노란색 칸은 자동 계산 결과입니다.')
    prior=db.prior_case(c,x['company_id'],x['year'])
    if prior and st.button(f'{x["year"]-1}년 차기 이월자료 불러오기',disabled=x['status']=='confirmed'):
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};tax=dict(payload.get('tax',{}));pt=prior.get('tax',{})
        tax.update(donation_excess=pt.get('donation_carry_next',0),carry_loss=pt.get('carry_loss_next',0),rd_prior=pt.get('rd_carry_next',0));payload['tax']=tax;save_payload(c,x,payload)
    elif not prior:st.caption('전년도 결산자료가 없어 이월자료를 수동 입력합니다.')
    with st.container(key='cc_tax_direct'):
      with st.form('cc_tax'):
        tax=tax_input_values(x.get('tax',{}));disabled=x['status']=='confirmed';a,b,c1=st.columns([1,1.8,1.3])
        a.markdown('**과세표준 계산**')
        for key,label in TAX_FIELDS[:3]:tax[key]=money_field(a,label,tax.get(key),key='tax_'+key,disabled=disabled)
        a.html(f'<div class="cc-auto">각사업연도소득　{result["current_income"]:,}</div><div class="cc-auto">과세표준　{result["taxable"]:,}</div>')
        b.markdown('**공제·감면 및 가산세**');x1,x2= b.columns(2)
        tax['special_base']=money_field(x1,'중소기업 감면 대상금액',tax.get('special_base'),key='tax_special_base',disabled=disabled);tax['special_rate']=x2.number_input('중소기업 감면율(%)',value=float(tax.get('special_rate',15)),step=.1,disabled=disabled);tax['reduced_headcount']=x2.number_input('감소 인원(명)',min_value=0,value=int(tax.get('reduced_headcount',0) or 0),disabled=disabled)
        tax['rd_prior']=money_field(x1,'R&D 세액공제 전기이월',tax.get('rd_prior'),key='tax_rd_prior',disabled=disabled);tax['rd_current']=money_field(x2,'R&D 세액공제 당기',tax.get('rd_current'),key='tax_rd_current',disabled=disabled)
        tax['undocumented_base']=money_field(x1,'증빙미수취 대상금액',tax.get('undocumented_base'),key='tax_undocumented_base',disabled=disabled);tax['undocumented_rate']=x2.number_input('증빙미수취 가산세율(%)',value=float(tax.get('undocumented_rate',2)),step=.1,disabled=disabled)
        tax['land_gain']=money_field(x1,'토지 등 양도차익',tax.get('land_gain'),key='tax_land_gain',disabled=disabled);tax['land_rate']=x2.number_input('토지 등 양도소득 세율(%)',value=float(tax.get('land_rate',20)),step=.1,disabled=disabled)
        c1.markdown('**납부·환급 및 이월**');tax['prepaid_corp_interim']=money_field(c1,'법인세 중간예납',tax.get('prepaid_corp_interim'),key='tax_prepaid_interim',disabled=disabled);tax['prepaid_corp_withholding']=money_field(c1,'법인세 원천납부',tax.get('prepaid_corp_withholding'),key='tax_prepaid_withholding',disabled=disabled);tax['prepaid_local']=money_field(c1,'지방소득세 기납부',tax.get('prepaid_local'),key='tax_prepaid_local',disabled=disabled);tax['accrued_tax']=money_field(c1,'미지급법인세',tax.get('accrued_tax'),key='tax_accrued',disabled=disabled);tax['prepaid_corp']=tax['prepaid_corp_interim']+tax['prepaid_corp_withholding']
        for key,label in NEXT_FIELDS:tax[key]=money_field(c1,label,tax.get(key),key='tax_next_'+key,disabled=disabled)
        live=calc.tax_calculation(inc['current_income'],{**tax,'pre_tax':calc.flow(x.get('values',{}),adjustments)['pre_tax']});b.html(f'<div class="cc-auto">산출세액　{live["output_tax"]:,}</div><div class="cc-auto">공제·감면　{live["credits"]:,}</div><div class="cc-auto">법인세 총부담　{live["corp_total"]:,}</div>');c1.html(f'<div class="cc-auto">확정 법인세등　{live["confirmed_tax"]:,}</div>')
        save=st.form_submit_button('세액 계산 입력 저장',type='primary',disabled=disabled)
    if save:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['tax']=tax;save_payload(c,x,payload)
    show_frame(pd.DataFrame([{'항목':k,'금액':v} for k,v in [('각사업연도소득',result['current_income']),('과세표준',result['taxable']),('산출세액',result['output_tax']),('중소기업 특별세액감면',result['special_reduction']),('공제·감면',result['credits']),('가산세',result['penalty']),('토지 등 양도소득 법인세',result['land_tax']),('법인세 총부담',result['corp_total']),('법인세 납부·환급',result['corp_payable']),('지방소득세 총부담',result['local_total']),('지방소득세 납부·환급',result['local_payable']),('확정 법인세등',result['confirmed_tax'])]]),hide_index=True,use_container_width=True)

def company_page(c):
    st.html('<div class="cc-title">법인·겸업 업종 설정</div>');allc=db.companies(c);selected=st.selectbox('등록·수정할 법인',['새 법인']+[r['id'] for r in allc],format_func=lambda z:'새 법인' if z=='새 법인' else next(r['name'] for r in allc if r['id']==z));r=next((r for r in allc if r['id']==selected),None)
    with st.form('cc_company'):
        name=st.text_input('법인명',value=r['name'] if r else '');business=st.text_input('업종명(쉼표로 구분)',value=', '.join(r.get('businesses',[])) if r else '건설업');save=st.form_submit_button('법인·업종 저장',type='primary')
    if save:db.save_company(c,name,business.split(','),r['id'] if r else None,r['version'] if r else None);refresh()
    if r:
        reason=st.text_input('법인 삭제 사유');ack=st.checkbox('법인 삭제 영향을 확인했습니다.')
        if st.button('법인 삭제',disabled=not ack):db.delete_company(c,r['id'],r['version'],reason);refresh()
    deleted=[r for r in db.companies(c,True) if r['deleted']]
    if deleted:
        rid=st.selectbox('삭제 법인',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z))
        if st.button('법인 복구'):r=next(r for r in deleted if r['id']==rid);db.restore_company(c,rid,r['version']);refresh()

def output_page(c,x,company):
    adjustments,inc,tax,reserves=computed(c,x,company);html=report.html(company['name'],x['year'],x,adjustments,inc,tax,reserves);xlsx=report.workbook(company['name'],x['year'],x,adjustments,inc,tax,reserves)
    st.html('<div class="cc-title">결산 확정·출력</div>');st.download_button('법인결산 전체 인쇄 HTML',html,file_name=f'{x["year"]}_{company["name"]}_법인결산.html',mime='text/html');st.download_button('법인결산 전체 Excel',xlsx,file_name=f'{x["year"]}_{company["name"]}_법인결산.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    if x['status']=='confirmed':
        reason=st.text_input('확정 해제 사유');ack=st.checkbox('확정 해제 후 자료가 다시 수정 가능해짐을 확인했습니다.')
        if st.button('결산 확정 해제',disabled=not ack):db.reopen(c,x,reason);refresh()
    else:
        missing=readiness(c,x,company,inc);ready=not missing;ack=st.checkbox('소득구분 검산과 세액 계산 결과를 확인했습니다.')
        if st.button('법인결산 확정',type='primary',disabled=not ready or not ack):db.confirm(c,x);refresh()
        if not ready:st.error('확정 전 완료할 사항: '+', '.join(missing))

def render(user):
    st.html(CSS);c=db.connect();companies=db.companies(c)
    if not companies:st.warning('법인·업종 설정에서 법인을 먼저 등록하세요.');company_page(c);return
    top=st.columns([1.4,.7,.7]);cid=top[0].selectbox('결산법인',[r['id'] for r in companies],format_func=lambda z:next(r['name'] for r in companies if r['id']==z),key='cc_company');year=top[1].number_input('결산연도',2015,2100,value=date.today().year-1,key='cc_year');company=active_company(c,cid);x=db.case(c,cid,year)
    top[2].metric('상태','확정' if x['status']=='confirmed' else '작성 중');st.caption(f'법인결산 · 버전 {VERSION} · 파란색은 원장·작업자 입력, 빨간색은 자동계산, 노란색은 주요 자동결과입니다.')
    with st.sidebar:page=st.radio('법인결산 메뉴',PAGES,key='cc_page',format_func=lambda z:'　↳ '+z if z in ADJUSTMENT_SUBPAGES else z)
    if page=='대시보드':dashboard_page(c,x,company)
    elif page=='법인세 계산 흐름표':entry_page(c,x,company)
    elif page=='기초정보입력':basic_input_page(c,x,company)
    elif page=='공사수입·원가대비':progress_page(c,x,company)
    elif page=='세무조정 항목':adjustment_page(c,x)
    elif page in ADJUSTMENT_SUBPAGES:adjustment_statement_page(c,x,page)
    elif page=='소득구분계산서':income_page(c,x,company)
    elif page=='세액 계산':tax_page(c,x,company)
    elif page=='유보잔액 관리':reserve_page(c,x)
    elif page=='법인·업종 설정':company_page(c)
    elif page=='결산 확정·출력':output_page(c,x,company)

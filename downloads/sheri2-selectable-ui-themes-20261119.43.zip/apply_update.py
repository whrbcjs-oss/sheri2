"""Install update 43 without touching accounting data or company settings."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import secrets
import shutil
import sys

ROOT = Path(__file__).resolve().parent
VERSION = "2026.11.19.43"
CORE = ["multiuser_app.py", "ui_theme.py"]
NAV = "app_navigation.py"
NEW = {
    "multiuser_app.py": "3dcbd20fcffe17d4c7712055e75071bc30899cab782ddf2bbe18ed9c4f19245e",
    "ui_theme.py": "d6cd59a79be7160c6607018276de784ff3744d22478450a5d2eedb6b1d57f352",
}
ACCEPTED_MULTIUSER = {
    "b28599bc30fa0e961c442483b4b29647d02783d979a8ce2113ddba7fb0bf7a9f",
    NEW["multiuser_app.py"],
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def patched_navigation(path):
    text = path.read_text(encoding="utf-8")
    if "VERSION" not in text or "st." not in text:
        raise ValueError("현재 메뉴 파일 형식을 확인할 수 없습니다. 아무 파일도 변경하지 않았습니다.")
    updated, count = re.subn(
        r"(VERSION\s*=\s*)(['\"])([^'\"]+)\2",
        lambda match: match.group(1) + match.group(2) + VERSION + match.group(2),
        text,
        count=1,
    )
    if count != 1:
        raise ValueError("현재 메뉴 파일의 버전 항목을 찾지 못했습니다. 아무 파일도 변경하지 않았습니다.")
    updated = re.sub(r"버전\s+\d{4}\.\d{2}\.\d{2}\.\d+", "버전 " + VERSION, updated)
    compile(updated, NAV, "exec")
    return updated


def validate_package():
    for name in CORE:
        source = ROOT / name
        if not source.is_file() or digest(source) != NEW[name]:
            raise ValueError("업데이트 패키지 파일 검증에 실패했습니다: " + name)
        compile(source.read_text(encoding="utf-8"), name, "exec")


def update(target):
    target = Path(target).expanduser().resolve()
    if target.is_file():
        target = target.parent
    if target == ROOT:
        raise ValueError("현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.")
    if not (target / "start.bat").is_file():
        raise ValueError("현재 사용하는 Sheri2 프로그램 폴더가 아닙니다.")

    validate_package()
    installed_multiuser = target / "multiuser_app.py"
    nav_path = target / NAV
    if not installed_multiuser.is_file():
        raise ValueError("필수 프로그램 파일이 없습니다: multiuser_app.py")
    if digest(installed_multiuser) not in ACCEPTED_MULTIUSER:
        raise ValueError("확인된 최신 운영본과 다른 multiuser_app.py입니다. 아무 파일도 변경하지 않았습니다.")
    if not nav_path.is_file():
        raise ValueError("메뉴 파일이 없습니다: " + NAV)
    nav_text = patched_navigation(nav_path)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    backup = target / "private" / "code-updates" / stamp
    backup.mkdir(parents=True)
    manifest = {"version": VERSION, "files": {}}
    original_names = ["multiuser_app.py", NAV]
    theme_path = target / "ui_theme.py"
    if theme_path.is_file():
        original_names.append("ui_theme.py")
    else:
        manifest["ui_theme_was_absent"] = True
    for name in original_names:
        path = target / name
        manifest["files"][name] = digest(path)
        shutil.copy2(path, backup / name)
    (backup / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    installed = []
    try:
        for name in CORE:
            destination = target / name
            temporary = target / (name + ".update-" + secrets.token_hex(4))
            try:
                shutil.copy2(ROOT / name, temporary)
                if digest(temporary) != NEW[name]:
                    raise ValueError("복사 파일 검증에 실패했습니다: " + name)
                temporary.replace(destination)
                installed.append(name)
            finally:
                temporary.unlink(missing_ok=True)

        temporary = target / (NAV + ".update-" + secrets.token_hex(4))
        try:
            temporary.write_text(nav_text, encoding="utf-8")
            compile(temporary.read_text(encoding="utf-8"), NAV, "exec")
            temporary.replace(nav_path)
            installed.append(NAV)
        finally:
            temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed):
            saved = backup / name
            destination = target / name
            if saved.is_file():
                shutil.copy2(saved, destination)
            else:
                destination.unlink(missing_ok=True)
        raise

    for name in CORE:
        if digest(target / name) != NEW[name]:
            raise ValueError("설치 후 검증에 실패했습니다: " + name)
    if VERSION not in nav_path.read_text(encoding="utf-8"):
        raise ValueError("메뉴 버전 표시 확인에 실패했습니다.")

    print("화면 테마 선택 기능 업데이트 완료:", target)
    print("사용자별 테마 설정은 private/accounts.db에 분리 저장됩니다.")
    print("기존 DB, 원장, 정산, 결산, 마감 및 발행자료는 변경하지 않았습니다.")
    print("기존 코드 백업:", backup)


def choose_target():
    if len(sys.argv) > 1:
        return sys.argv[1].strip().strip('"')
    window = None
    try:
        import tkinter as tk
        from tkinter import filedialog

        window = tk.Tk()
        window.withdraw()
        window.attributes("-topmost", True)
        return filedialog.askopenfilename(
            parent=window,
            title="현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요",
            filetypes=[("start.bat", "start.bat")],
        )
    finally:
        if window:
            window.destroy()


if __name__ == "__main__":
    try:
        selected = choose_target()
        if not selected:
            raise ValueError("취소했습니다. 아무 파일도 변경하지 않았습니다.")
        update(selected)
    except Exception as error:
        raise SystemExit("업데이트 실패: " + str(error))

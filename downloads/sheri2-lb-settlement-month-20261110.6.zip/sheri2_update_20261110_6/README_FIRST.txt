Sheri2 LB monthly report update 2026.11.10.6

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

The update adds construction-income insurance deductions and shows every raw VAT value without correction.

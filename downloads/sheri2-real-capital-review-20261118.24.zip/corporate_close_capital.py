"""Construction-company real-capital review, statement import and reports."""
from __future__ import annotations

from html import escape
from io import BytesIO, StringIO
from pathlib import Path
import csv
import math
import re
import sys

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


ITEM_COLUMNS = ["구분", "계정과목", "원천금액", "차감액", "인정조정액", "판정", "근거·비고", "출처"]
LICENSE_COLUMNS = ["면허명·업종", "요구자본금", "중복·겸업 조정액", "적용연도", "근거·비고"]
DECISION_OPTIONS = ["전액 인정", "일부 인정", "전액 차감", "검토 필요"]
CATEGORY_OPTIONS = ["자본", "차감검토", "인정조정"]

CAPITAL_ALIASES = {
    "자본총계": ["자본총계", "자기자본"],
    "납입자본금": ["납입자본금"],
    "자본금": ["자본금"],
    "자본잉여금": ["자본잉여금"],
    "이익잉여금": ["이익잉여금", "결손금"],
    "기타포괄손익누계액": ["기타포괄손익누계액"],
}
REVIEW_ALIASES = {
    "미수금": ["미수금", "공사미수금"],
    "관계회사대여금": ["관계회사대여금"],
    "주임종단기채권": ["주임종단기채권", "주임종단기대여금"],
    "단기대여금": ["단기대여금"],
    "장기대여금": ["장기대여금"],
    "미수수익": ["미수수익"],
    "선급금": ["선급금"],
    "선급비용": ["선급비용"],
    "미완성공사": ["미완성공사", "미완성공사(분양)"],
    "임목": ["임목"],
    "토지": ["토지"],
    "건물": ["건물"],
    "개발비": ["개발비"],
    "소프트웨어": ["소프트웨어"],
    "임차보증금": ["임차보증금"],
    "회원권": ["회원권"],
}


def norm(value):
    return re.sub(r"[\s\n\r()·._\-\[\]]", "", str(value or "")).lower()


def number(value):
    if value in (None, "", "-") or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(round(float(value))) if math.isfinite(float(value)) else None
    text = str(value).strip().replace(",", "").replace("원", "")
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    try:
        return int(round(float(text)))
    except (TypeError, ValueError):
        return None


def _matrixes(name, content):
    lower = str(name).lower()
    if lower.endswith(".csv"):
        text = content.decode("utf-8-sig", errors="replace")
        return [("CSV", list(csv.reader(StringIO(text))))]
    if lower.endswith(".xls"):
        try:
            import xlrd
        except ImportError:
            wheel = Path(__file__).resolve().parent / "vendor" / "xlrd-2.0.2-py2.py3-none-any.whl"
            if wheel.is_file() and str(wheel) not in sys.path:
                sys.path.insert(0, str(wheel))
            import xlrd
        book = xlrd.open_workbook(file_contents=content, on_demand=True)
        return [(book.sheet_by_index(i).name,
                 [[cell.value for cell in book.sheet_by_index(i).row(r)] for r in range(book.sheet_by_index(i).nrows)])
                for i in range(book.nsheets)]
    if not lower.endswith(".xlsx"):
        raise ValueError("XLS, XLSX 또는 CSV 재무자료만 업로드할 수 있습니다.")
    book = openpyxl.load_workbook(BytesIO(content), data_only=True, read_only=True)
    return [(ws.title, [list(row) for row in ws.iter_rows(values_only=True)]) for ws in book]


def _right_amount(matrix, row_index, column):
    row = matrix[row_index]
    candidates = []
    for value_column in range(column + 1, len(row)):
        value = number(row[value_column])
        if value is None:
            continue
        header = norm(" ".join(str(matrix[up][value_column] or "") for up in range(max(0, row_index - 8), row_index) if value_column < len(matrix[up])))
        score = 0
        if any(word in header for word in ["당기", "기말", "현재"]):score += 60
        if "잔액" in header:score += 35
        if "금액" in header:score += 10
        if any(word in header for word in ["전기", "기초"]):score -= 60
        candidates.append((score, -value_column, value))
    if not candidates:return None
    # When no header is recognizable, retain the first amount to the right.
    if max(score for score, _, _ in candidates) == 0:return max(candidates, key=lambda item:item[1])[2]
    return max(candidates, key=lambda item:(item[0], abs(item[2]), item[1]))[2]


def extract_statement(name, content):
    """Extract exact account labels while leaving legal recognition to the reviewer."""
    found = {}
    alias_map = []
    for account, aliases in CAPITAL_ALIASES.items():
        alias_map.extend((norm(alias), "자본", account) for alias in aliases)
    for account, aliases in REVIEW_ALIASES.items():
        alias_map.extend((norm(alias), "차감검토", account) for alias in aliases)
    for sheet_name, matrix in _matrixes(name, content):
        for row_no, row in enumerate(matrix, 1):
            for column, cell in enumerate(row):
                label = norm(cell)
                if not label:
                    continue
                match = next(((category, account) for alias, category, account in alias_map if alias == label), None)
                if not match:
                    continue
                amount = _right_amount(matrix, row_no - 1, column)
                if amount is None:
                    continue
                category, account = match
                key = (category, account)
                if key not in found:
                    found[key] = {
                        "구분": category, "계정과목": account, "원천금액": amount,
                        "차감액": 0, "인정조정액": 0,
                        "판정": "전액 인정" if category == "자본" else "검토 필요",
                        "근거·비고": "", "출처": f"{sheet_name} {row_no}행",
                    }
    items = list(found.values())
    # A reported total is safer than summing its components twice.
    if any(row["구분"] == "자본" and row["계정과목"] == "자본총계" for row in items):
        items = [row for row in items if row["구분"] != "자본" or row["계정과목"] == "자본총계"]
    items.sort(key=lambda row: (CATEGORY_OPTIONS.index(row["구분"]), row["계정과목"]))
    return {"items": items, "found": len(items)}


def clean_items(items):
    cleaned = []
    for raw in items or []:
        account_value = raw.get("계정과목", "")
        account = "" if account_value is None or str(account_value).strip().lower() == "nan" else str(account_value).strip()
        if not account:
            continue
        category = str(raw.get("구분", "차감검토") or "차감검토")
        if category not in CATEGORY_OPTIONS:
            category = "차감검토"
        decision = str(raw.get("판정", "검토 필요") or "검토 필요")
        if decision not in DECISION_OPTIONS:
            decision = "검토 필요"
        source_amount = number(raw.get("원천금액")) or 0
        deduction = max(0, number(raw.get("차감액")) or 0)
        adjustment = number(raw.get("인정조정액")) or 0
        if category == "차감검토" and decision == "전액 차감" and deduction == 0:
            deduction = max(0, source_amount)
        cleaned.append({
            "구분": category, "계정과목": account, "원천금액": source_amount,
            "차감액": deduction, "인정조정액": adjustment, "판정": decision,
            "근거·비고": str(raw.get("근거·비고", "") or "").strip(),
            "출처": str(raw.get("출처", "직접입력") or "직접입력").strip(),
        })
    return cleaned


def clean_licenses(licenses, year):
    cleaned = []
    for raw in licenses or []:
        name_value = raw.get("면허명·업종", "")
        name = "" if name_value is None or str(name_value).strip().lower() == "nan" else str(name_value).strip()
        if not name:
            continue
        required = max(0, number(raw.get("요구자본금")) or 0)
        adjustment = number(raw.get("중복·겸업 조정액")) or 0
        cleaned.append({
            "면허명·업종": name, "요구자본금": required,
            "중복·겸업 조정액": adjustment,
            "적용연도": int(number(raw.get("적용연도")) or year),
            "근거·비고": str(raw.get("근거·비고", "") or "").strip(),
        })
    return cleaned


def calculate(items, licenses, year=None):
    rows = clean_items(items)
    license_rows = clean_licenses(licenses, year or 0)
    capital_rows = [row for row in rows if row["구분"] == "자본"]
    reported_total = [row for row in capital_rows if norm(row["계정과목"]) in ["자본총계", "자기자본"]]
    capital = sum(row["원천금액"] for row in (reported_total or capital_rows))
    deduction = sum(row["차감액"] for row in rows if row["구분"] == "차감검토")
    adjustment = sum(row["인정조정액"] for row in rows)
    real_capital = capital - deduction + adjustment
    detailed = []
    for row in license_rows:
        applied = max(0, row["요구자본금"] + row["중복·겸업 조정액"])
        detailed.append({**row, "최종 적용자본금": applied})
    required = sum(row["최종 적용자본금"] for row in detailed)
    surplus = real_capital - required
    unresolved = sum(1 for row in rows if row["구분"] == "차감검토" and row["판정"] == "검토 필요")
    status = "면허기준 미입력" if required <= 0 else "검토 중" if unresolved else "충족" if surplus >= 0 else "미충족"
    return {
        "items": rows, "licenses": detailed, "capital": capital, "deduction": deduction,
        "adjustment": adjustment, "real_capital": real_capital, "required": required,
        "surplus": surplus, "status": status,
        "unresolved": unresolved,
    }


def _money(value):
    return f"{int(value or 0):,}"


def report_workbook(company, year, result):
    book = openpyxl.Workbook()
    sheet = book.active
    sheet.title = f"{year}.실질자본금"[:31]
    dark, green, pale, yellow, red = "173F59", "087A4F", "EAF3F7", "FFF2A8", "FCE8E6"
    thin = Side(style="thin", color="AAB8BF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    sheet.merge_cells("A1:H1");sheet["A1"] = f"{year}년 실질자본금 적격여부 검토표"
    sheet["A1"].font = Font(name="맑은 고딕", size=18, bold=True, color="FFFFFF")
    sheet["A1"].fill = PatternFill("solid", fgColor=dark);sheet["A1"].alignment = Alignment(horizontal="center")
    sheet.merge_cells("A2:D2");sheet["A2"] = f"결산법인  {company}"
    sheet.merge_cells("E2:H2");sheet["E2"] = f"결산연도  {year}년"
    for cell in sheet[2]:cell.fill = PatternFill("solid", fgColor=pale);cell.font = Font(name="맑은 고딕", bold=True, color=dark);cell.alignment = Alignment(horizontal="center")
    headers = ITEM_COLUMNS
    sheet.append(headers)
    for row in result["items"]:sheet.append([row.get(key, "") for key in headers])
    start = 3
    for cell in sheet[start]:cell.fill = PatternFill("solid", fgColor=green);cell.font = Font(name="맑은 고딕", bold=True, color="FFFFFF");cell.alignment = Alignment(horizontal="center")
    summary_row = sheet.max_row + 2
    summary = [("자본총계", result["capital"]), ("차감대상 자산", result["deduction"]), ("인정 조정액", result["adjustment"]), ("실질자본금", result["real_capital"]), ("최종 필요자본금", result["required"]), ("충족 여유액(부족액)", result["surplus"])]
    for offset, (label, value) in enumerate(summary):
        row = summary_row + offset;sheet.cell(row, 1, label);sheet.merge_cells(start_row=row, start_column=2, end_row=row, end_column=4);sheet.cell(row, 2, value)
        sheet.cell(row, 1).font = Font(name="맑은 고딕", bold=True);sheet.cell(row, 2).font = Font(name="맑은 고딕", bold=True, color="D92C25" if offset >= 3 else "126BB0")
        for col in range(1, 5):sheet.cell(row, col).fill = PatternFill("solid", fgColor=yellow if offset >= 3 else pale);sheet.cell(row, col).border = border
        sheet.cell(row, 2).number_format = "#,##0;[Red]-#,##0";sheet.cell(row, 2).alignment = Alignment(horizontal="right")
    license_start = summary_row
    sheet.merge_cells(start_row=license_start, start_column=5, end_row=license_start, end_column=8);sheet.cell(license_start, 5, "회사별 면허 기준자본금")
    sheet.cell(license_start, 5).fill = PatternFill("solid", fgColor=green);sheet.cell(license_start, 5).font = Font(name="맑은 고딕", bold=True, color="FFFFFF");sheet.cell(license_start, 5).alignment = Alignment(horizontal="center")
    license_headers = ["면허명·업종", "요구자본금", "조정액", "최종 적용자본금"]
    for col, label in enumerate(license_headers, 5):sheet.cell(license_start + 1, col, label)
    for i, row in enumerate(result["licenses"], license_start + 2):
        values = [row["면허명·업종"], row["요구자본금"], row["중복·겸업 조정액"], row["최종 적용자본금"]]
        for col, value in enumerate(values, 5):sheet.cell(i, col, value)
    max_row = max(sheet.max_row, license_start + len(result["licenses"]) + 1)
    for row in sheet.iter_rows(min_row=3, max_row=max_row, min_col=1, max_col=8):
        for cell in row:
            cell.border = border;cell.font = cell.font.copy(name="맑은 고딕");cell.alignment = Alignment(horizontal="right" if cell.column in [3,4,5,6,7,8] and isinstance(cell.value, (int, float)) else "center", vertical="center", wrap_text=True)
            if isinstance(cell.value, (int, float)):cell.number_format = "#,##0;[Red]-#,##0"
    for col, width in enumerate([13,22,16,16,16,18,28,18], 1):sheet.column_dimensions[get_column_letter(col)].width = width
    sheet.freeze_panes = "A4";sheet.sheet_view.showGridLines = False;sheet.print_area = f"A1:H{max_row}";sheet.page_setup.orientation = "landscape";sheet.page_setup.fitToWidth = 1;sheet.sheet_properties.pageSetUpPr.fitToPage = True
    output = BytesIO();book.save(output);return output.getvalue()


def report_html(company, year, result):
    item_rows = "".join("<tr>" + "".join(f"<td class='{('num' if key in ['원천금액','차감액','인정조정액'] else '')}'>{_money(row[key]) if key in ['원천금액','차감액','인정조정액'] else escape(str(row[key]))}</td>" for key in ITEM_COLUMNS) + "</tr>" for row in result["items"])
    license_rows = "".join(f"<tr><td>{escape(row['면허명·업종'])}</td><td class='num'>{_money(row['요구자본금'])}</td><td class='num'>{_money(row['중복·겸업 조정액'])}</td><td class='num'>{_money(row['최종 적용자본금'])}</td><td>{escape(row['근거·비고'])}</td></tr>" for row in result["licenses"])
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>실질자본금 검토표</title><style>
    @page{{size:A4 landscape;margin:9mm}}body{{font-family:"Malgun Gothic",sans-serif;color:#173f59;margin:0}}button{{padding:7px 14px;margin-bottom:8px}}h1{{background:#173f59;color:#fff;padding:12px;text-align:center;font-size:20px;margin:0}}.identity{{display:flex;justify-content:space-between;background:#eaf3f7;padding:9px 14px;font-weight:700}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin:10px 0}}.card{{border:1px solid #b9cbd4;border-radius:6px;padding:8px;text-align:center;background:#f7fafb}}.card strong{{display:block;color:#126bb0;font-size:16px;margin-top:4px}}.result{{background:#fff2a8}}.result strong{{color:#d92c25}}h2{{font-size:14px;background:#087a4f;color:white;padding:6px 8px;margin:12px 0 0}}table{{border-collapse:collapse;width:100%;font-size:9px}}th,td{{border:1px solid #aab8bf;padding:4px;text-align:center}}th{{background:#eaf3f7}}td.num{{text-align:right;color:#126bb0;font-variant-numeric:tabular-nums}}@media print{{button{{display:none}}}}</style></head><body>
    <button onclick="window.print()">인쇄 · PDF 저장</button><h1>{year}년 실질자본금 적격여부 검토표</h1><div class="identity"><span>결산법인　{escape(company)}</span><span>결산연도　{year}년</span><span>판정　{result['status']}</span></div>
    <div class="cards"><div class="card">자본총계<strong>{_money(result['capital'])}원</strong></div><div class="card">차감대상 자산<strong>{_money(result['deduction'])}원</strong></div><div class="card result">실질자본금<strong>{_money(result['real_capital'])}원</strong></div><div class="card result">여유액(부족액)<strong>{_money(result['surplus'])}원</strong></div></div>
    <h2>실질자본금 계산내역</h2><table><thead><tr>{''.join(f'<th>{escape(key)}</th>' for key in ITEM_COLUMNS)}</tr></thead><tbody>{item_rows}</tbody></table>
    <h2>회사별 면허 기준자본금</h2><table><thead><tr><th>면허명·업종</th><th>요구자본금</th><th>중복·겸업 조정액</th><th>최종 적용자본금</th><th>근거·비고</th></tr></thead><tbody>{license_rows}</tbody></table>
    <p style="font-size:9px;color:#667">면허별 법정 기준과 중복·겸업 조정은 적용연도 및 근거자료를 확인한 후 확정하십시오.</p></body></html>'''.encode("utf-8")

"""Install the joint-settlement display and cumulative-arrears update safely."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import sys

ROOT = Path(__file__).resolve().parent
FILES = ["joint_app.py", "joint_workflow.py", "app_navigation.py"]
SUPPORTED = [
    "2026.11.10.2", "2026.11.10.3", "2026.11.10.4", "2026.11.10.5", "2026.11.10.6",
    "2026.11.11.1", "2026.11.11.2", "2026.11.11.3", "2026.11.11.4", "2026.11.11.5", "2026.11.11.6",
    "2026.11.12.1", "2026.11.12.2", "2026.11.12.3", "2026.11.12.4", "2026.11.12.5", "2026.11.12.6", "2026.11.12.7",
    "2026.11.13.1", "2026.11.13.2", "2026.11.13.3",
    "2026.11.14.1", "2026.11.14.2", "2026.11.14.3", "2026.11.14.4", "2026.11.14.5", "2026.11.14.6", "2026.11.14.7", "2026.11.14.8", "2026.11.14.9", "2026.11.14.10", "2026.11.14.11", "2026.11.14.12", "2026.11.14.13", "2026.11.14.14", "2026.11.14.15", "2026.11.14.16", "2026.11.14.17", "2026.11.14.18",
    "2026.11.16.19", "2026.11.16.20", "2026.11.16.21", "2026.11.16.22", "2026.11.16.23",
    "2026.11.18.24", "2026.11.18.25", "2026.11.18.26", "2026.11.18.27", "2026.11.18.28", "2026.11.18.29", "2026.11.18.30", "2026.11.18.31", "2026.11.18.32",
    "2026.11.19.33", "2026.11.19.34", "2026.11.19.35", "2026.11.19.36", "2026.11.19.37",
]


def update(target):
    target = Path(target).expanduser().resolve()
    if target.is_file():
        target = target.parent
    if target == ROOT:
        raise ValueError("기존 start.bat이 있는 프로그램 폴더를 선택하세요.")
    if not (target / "start.bat").is_file() or not (target / "joint_app.py").is_file() or not (target / "joint_store.py").is_file():
        raise ValueError("공동도급 관리대장이 설치된 기존 프로그램 폴더가 아닙니다.")
    nav = target / "app_navigation.py"
    if not nav.is_file() or not any(version in nav.read_text(encoding="utf-8") for version in SUPPORTED):
        raise ValueError("2026.11.10.2 이상 설치 폴더에 적용해 주세요.")
    for name in FILES:
        if not (ROOT / name).is_file():
            raise ValueError("업데이트 파일 누락: " + name)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    backup = target / "private" / "code-updates" / stamp
    backup.mkdir(parents=True)
    manifest = {}
    for name in FILES:
        path = target / name
        manifest[name] = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
        if path.exists():
            (backup / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup / name)
    (backup / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    installed = []
    try:
        for name in FILES:
            path = target / name
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = target / (name + ".update-" + secrets.token_hex(4))
            try:
                temporary.write_bytes((ROOT / name).read_bytes())
                temporary.replace(path)
                installed.append(name)
            finally:
                temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed):
            if manifest[name] is None:
                (target / name).unlink(missing_ok=True)
            else:
                shutil.copy2(backup / name, target / name)
        raise
    print("공동도급 주관사·비주관사 메뉴 복원 완료:", target)
    print("기존 코드 백업:", backup)
    print("회사 DB, 원장, 마감자료와 발행본은 변경하지 않았습니다.")


def choose_target():
    if len(sys.argv) > 1:
        return sys.argv[1].strip().strip('"')
    window = None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window = tk.Tk()
        window.withdraw()
        window.attributes("-topmost", True)
        return filedialog.askopenfilename(parent=window, title="기존 프로그램의 start.bat을 선택하세요", filetypes=[("start.bat", "start.bat")])
    finally:
        if window:
            window.destroy()


if __name__ == "__main__":
    try:
        value = choose_target()
        if not value:
            raise ValueError("취소했습니다.")
        update(value)
    except Exception as error:
        raise SystemExit("업데이트 실패: " + str(error))

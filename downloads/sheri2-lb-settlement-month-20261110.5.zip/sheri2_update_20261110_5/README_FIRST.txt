Sheri2 LB monthly report update 2026.11.10.5

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

The update uses the Excel settlement-month column and preserves the posting date.

"""Nonlead monthly status snapshots and auditable manual investment exclusions."""
import json
from decimal import ROUND_DOWN
import joint_store as db
import joint_workflow as flow

CATEGORIES=['영업비','보증수수료','급여 및 4대보험','기타비용']
RATIOS=['미설정','수입 ÷ 지출총계 × 100','지출총계 ÷ 수입 × 100']

def install(c):
 c.executescript('''
 CREATE TABLE IF NOT EXISTS jv_status_manual(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES jv_projects(id),member_id INTEGER NOT NULL REFERENCES jv_members(id),month TEXT NOT NULL,kind TEXT NOT NULL,category TEXT NOT NULL,amount TEXT NOT NULL,note TEXT NOT NULL,included INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS jv_status_records(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES jv_projects(id),member_id INTEGER NOT NULL REFERENCES jv_members(id),run_id INTEGER NOT NULL REFERENCES jv_runs(id),month TEXT NOT NULL,payload TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0);
 ''')
 missing_date='entry_date' not in {r[1] for r in c.execute('PRAGMA table_info(jv_status_manual)')}
 if missing_date or c.execute("SELECT 1 FROM jv_status_manual WHERE entry_date='' LIMIT 1").fetchone():
  if hasattr(c,'path') and c.execute('SELECT 1 FROM jv_status_manual LIMIT 1').fetchone():db.shared.backup_database(c.path)
  ctx=db.shared.RUN.get()
  c.create_function('current_actor',0,lambda:ctx['user']['username'] if ctx else 'system')
  if missing_date:c.execute("ALTER TABLE jv_status_manual ADD COLUMN entry_date TEXT NOT NULL DEFAULT ''")
  c.execute("UPDATE jv_status_manual SET entry_date=month||'-01' WHERE entry_date=''")
  for op in ['INSERT','UPDATE','DELETE']:c.execute('DROP TRIGGER IF EXISTS audit_jv_status_manual_'+op)
  c.commit()
def scope(c,p,m):
 if not db.is_nonlead(c,p):raise ValueError('당사비주관공사에서 사용하는 현황입니다.')
 project=next((x for x in db.projects(c) if x['id']==p),None);member=next((x for x in db.members(c,p) if x['id']==m),None)
 if not project or not member or member['company_id']!=project['owner_id']:raise ValueError('해당 공사의 관리법인 회원사를 선택하세요.')
 return project,member

def manual(c,p,m,month,deleted=False):
 return db.rows(c,'SELECT * FROM jv_status_manual WHERE project_id=? AND member_id=? AND month=? AND deleted=? ORDER BY entry_date,id',(p,m,db.period(month),int(deleted)))
def save_manual(c,p,m,month,kind,category,amount,note,included=False,id=None,expected=None,entry_date=None):
 scope(c,p,m);month=db.period(month);flow.ensure_open(c,p,month)
 entry_date=db.day(entry_date or month+'-01')
 if entry_date[:7]!=month:raise ValueError('입력 기준일은 기준월 내로 지정하세요.')
 if kind not in ['영업비','안분제외'] or category not in CATEGORIES or kind=='영업비' and category!='영업비':raise ValueError('비용 구분을 확인하세요.')
 amount=db.num(amount)
 if amount<0:raise ValueError('금액은 0원 이상 입력하세요.')
 if not str(note).strip():raise ValueError('입력 사유·적요를 입력하세요.')
 with c:
  if id:
   old=next((r for r in manual(c,p,m,month) if r['id']==id),None)
   if not old or expected!=old['version']:raise ValueError('수동입력 내역이 변경되었습니다. 다시 불러오세요.')
   c.execute('UPDATE jv_status_manual SET kind=?,category=?,amount=?,note=?,included=?,entry_date=?,version=version+1 WHERE id=?',(kind,category,str(amount),note,int(bool(included) if kind=='안분제외' else False),entry_date,id))
  else:id=c.execute('INSERT INTO jv_status_manual(project_id,member_id,month,kind,category,amount,note,included,entry_date) VALUES(?,?,?,?,?,?,?,?,?)',(p,m,month,kind,category,str(amount),note,int(bool(included) if kind=='안분제외' else False),entry_date)).lastrowid
 return id

def set_manual_deleted(c,p,m,month,id,version,deleted):
 scope(c,p,m);flow.ensure_open(c,p,month)
 old=next((r for r in manual(c,p,m,month,not deleted) if r['id']==id),None)
 if not old or old['version']!=version:raise ValueError('수동입력 내역이 변경되었습니다. 다시 불러오세요.')
 with c:c.execute('UPDATE jv_status_manual SET deleted=?,version=version+1 WHERE id=?',(int(deleted),id))

def records(c,p,m,run_id=None,deleted=False):
 out=[dict(r,data=json.loads(r['payload'])) for r in db.rows(c,'SELECT * FROM jv_status_records WHERE project_id=? AND member_id=? AND deleted=? ORDER BY month DESC,id DESC',(p,m,int(deleted)))]
 return [r for r in out if run_id is None or r['run_id']==run_id]
def get(c,p,m,id,deleted=False):
 r=next((r for r in records(c,p,m,deleted=deleted) if r['id']==id),None)
 if not r:raise ValueError('해당 프로젝트·회원사의 현황을 선택하세요.')
 return r

def notices(c,p,month):
 result=[]
 for r in db.rows(c,"SELECT id,number,issued,snapshot FROM jv_documents WHERE project_id=? AND kind='공문' ORDER BY id DESC",(p,)):
  value=json.loads(r['snapshot'])
  if value.get('investment_letter') and value.get('start')==month and value.get('end')==month:result.append(dict(id=r['id'],number=r['number'],issued=r['issued'],data=value))
 return result

def investment(c,p,m,month,source_doc=None,as_of=None):
 project,member=scope(c,p,m)
 if source_doc:
  doc=next((d for d in notices(c,p,month) if d['id']==source_doc),None)
  if not doc:raise ValueError('선택한 월의 당사투입비 통보 발행본을 확인하세요.')
  source=doc['data']['investment_rows'];label=doc['number']
 else:source=[r for r in db.ledger(c,p) if r['company_id']==project['owner_id'] and r['allocation_month']==month];label='현재 당사투입비 (미발행 자료 포함)'
 if as_of:source=[row for row in source if row['posting_date']<=db.day(as_of)]
 totals={k:db.num(0) for k in CATEGORIES};unknown=[]
 aliases={'급여':'급여 및 4대보험','급여및4대보험':'급여 및 4대보험','급여4대보험':'급여 및 4대보험','보증수수료':'보증수수료','기타비용':'기타비용'}
 for row in source:
  category=aliases.get(''.join(str(row['account']).split()).replace('·','').replace('/',''))
  amount=sum((db.num(row[k]) for k in ['tax_supply','invoice','receipt']),db.num(0))
  if category:totals[category]+=amount
  else:
   totals['기타비용']+=amount
   unknown.append(dict(id=row['id'],account=row['account'],amount=str(amount)))
 return dict(totals={k:str(v) for k,v in totals.items()},source_label=label,source_rows=source,unmapped=unknown)

def contract_defaults(c,p,m,month):
 project,member=scope(c,p,m);members=db.members(c,p)
 prior=next((r['data'] for r in records(c,p,m) if r['month']<month),None)
 previous={int(r['company_id']):r for r in prior.get('contracts',[])} if prior else {}
 # Allocate integer won with the final member receiving the rounding remainder.
 remaining=db.num(project['supply']);out=[]
 for index,r in enumerate(members):
  contract=(db.num(project['supply'])*db.num(r['share'])/100).quantize(db.num(1),rounding=ROUND_DOWN) if index<len(members)-1 else remaining
  remaining-=contract
  out.append(dict(company_id=r['company_id'],name=r['name'],share=r['share'],contract=str(contract),previous=previous.get(r['company_id'],{}).get('cumulative','0'),current='0'))
 return out

def build(c,p,m,run_id,month,v):
 project,member=scope(c,p,m);month=db.period(month);as_of=db.day(v.get('as_of',month+'-01'))
 if as_of[:7]!=month:raise ValueError('기준일은 기준월 내로 지정하세요.')
 run=next((r for r in flow.runs(c,p,m) if r['id']==run_id),None)
 if not run:raise ValueError('먼저 원가정산서에서 정산 건을 저장하고 선택하세요.')
 selection=json.loads(run['selection']);d=flow.selected_settlement(c,p,m,selection)
 claim_lookup={r['id']:r for r in flow.claim_rows(c,p,m)}
 if any(claim_lookup[id]['month']!=month for id in selection.get('claims',[])):raise ValueError('현황은 기준월 하나의 청구 범위를 선택한 정산 건에 연결하세요.')
 selected_payments=[e for e in d['entries'] if e['kind']=='recovery']
 if any(e['entry_date'][:7]!=month or e['entry_date']>as_of for e in selected_payments):raise ValueError('선택 정산의 지급일은 기준월·기준일 범위 내여야 합니다.')
 source=investment(c,p,m,month,v.get('source_doc'),as_of);rows=[r for r in manual(c,p,m,month) if r['entry_date']<=as_of]
 investment_rows=[]
 for category in CATEGORIES:
  target=sum((db.num(r['amount']) for r in rows if r['kind']=='영업비'),db.num(0)) if category=='영업비' else db.num(source['totals'][category])
  excluded=sum((db.num(r['amount']) for r in rows if r['kind']=='안분제외' and r['category']==category),db.num(0))
  investment_rows.append(dict(category=category,target=str(target),excluded=str(excluded),total=str(target+excluded)))
 contracts=[];actual={r['company_id']:r for r in db.members(c,p)};seen=set()
 for row in v.get('contracts',[]):
  cid=int(row['company_id'])
  if cid not in actual or cid in seen:raise ValueError('계약현황의 법인 목록·중복을 확인하세요.')
  seen.add(cid);amounts={k:db.num(row.get(k,0)) for k in ['contract','previous','current']}
  if any(x<0 for x in amounts.values()):raise ValueError('계약·기성 금액은 0원 이상 입력하세요.')
  cumulative=amounts['previous']+amounts['current']
  contracts.append(dict(company_id=cid,name=actual[cid]['name'],share=actual[cid]['share'],**{k:str(a) for k,a in amounts.items()},cumulative=str(cumulative),rate=str(cumulative/amounts['contract']*100) if amounts['contract'] else None))
 if seen!=set(actual):raise ValueError('등록된 모든 법인의 계약현황을 입력하세요.')
 receipts=[e for e in flow.source_entries(c,p,m,'receipt') if e['entry_date']<=as_of]
 payments=[e for e in flow.source_entries(c,p,m,'recovery') if e['entry_date']<=as_of]
 subcontracts=[e for e in flow.source_entries(c,p,m,'subcontract') if e['data'].get('paid_date',e['entry_date'])<=as_of]
 paid_supply=sum((db.num(e['data']['supply']) for e in payments),db.num(0))
 paid_vat=sum((db.num(e['data']['vat']) for e in payments),db.num(0))
 sub_paid_supply=sum((db.num(e['data'].get('paid_supply',0)) for e in subcontracts),db.num(0))
 sub_paid_vat=sum((db.num(e['data'].get('paid_vat',0)) for e in subcontracts),db.num(0))
 target=sum((db.num(r['target']) for r in investment_rows),db.num(0))
 exclusion=sum((db.num(r['excluded']) for r in investment_rows),db.num(0))
 investment_total=target+exclusion
 a=d['amounts'];insurance=db.num(a['industrial'])+db.num(a['employment'])
 previous_status=next((r for r in records(c,p,m) if r['month']<month),None)
 previous_balance=db.num(0)
 if previous_status:
  prior_run=next((r for r in flow.runs(c,p,m) if r['id']==previous_status['run_id']),None)
  if prior_run:previous_balance=db.num(flow.selected_settlement(c,p,m,json.loads(prior_run['selection']))['amounts']['remaining'])
 hold=db.num(v.get('hold',v.get('prior_balance',0)))
 advance=db.num(v.get('advance',0))
 if hold<0 or advance<0:raise ValueError('유보액·선금반제는 0원 이상 입력하세요.')
 carry=previous_balance+hold
 selected_vat=sum((db.num(claim_lookup[id]['vat']) for id in selection.get('claims',[])),db.num(0))
 prior_paid=paid_supply+sub_paid_supply+target
 current=db.num(a['remaining'])-carry-target-selected_vat
 extra=insurance+exclusion
 spending=prior_paid+current+extra
 income=sum((db.num(e['data']['supply']) for e in receipts),db.num(0))
 income_scope='관리법인'
 earned=sum((db.num(row['cumulative']) for row in contracts if row['company_id']==project['owner_id']),db.num(0))
 included=True
 ratio=v.get('ratio','미설정')
 if ratio not in RATIOS:raise ValueError('대비율 산식을 확인하세요.')
 def ratio_value(income):
  if ratio==RATIOS[0]:return None
  numerator,denominator=(income,spending) if ratio==RATIOS[1] else (spending,income)
  return str(numerator/denominator*100) if denominator else None
 gross=sum((db.num(claim_lookup[id]['base'])+db.num(claim_lookup[id]['vat']) for id in selection.get('claims',[])),db.num(0))
 paid=paid_supply+paid_vat+sub_paid_supply+sub_paid_vat
 offset=investment_total+advance
 planned=gross-paid-carry-offset
 return dict(schema_version=8,project_id=p,member_id=m,run_id=run_id,run_name=run['name'],month=month,as_of=as_of,selection=d['selection'],source_doc=v.get('source_doc'),source_label=source['source_label'],investment_rows=investment_rows,investment_source=source,manual_rows=rows,contracts=contracts,insurance_in_payment=included,income_scope=income_scope,ratio=ratio,cash=dict(income=str(income),earned=str(earned),previous=str(prior_paid),current=str(current),insurance=str(insurance),excluded=str(exclusion),extra=str(extra),spending=str(spending),cash_balance=str(income-spending),earned_balance=str(earned-spending),cash_ratio=ratio_value(income),earned_ratio=ratio_value(earned),target=str(target),selected_vat=str(selected_vat),statement_remaining=a['remaining']),payment=dict(claim=str(gross),paid=str(paid),previous_balance=str(previous_balance),hold=str(hold),prior_balance=str(carry),investment_offset=str(investment_total),advance=str(advance),offset=str(offset),planned=str(planned),approved=None),inputs=v,sources=dict(receipts=receipts,payments=payments,subcontracts=subcontracts,previous_status_id=previous_status['id'] if previous_status else None))

def save(c,p,m,run_id,month,v,id=None,expected=None):
 flow.ensure_open(c,p,month);data=build(c,p,m,run_id,month,v)
 with c:
  if id:
   old=get(c,p,m,id)
   if old['version']!=expected:raise ValueError('현황이 변경되었습니다. 다시 불러오세요.')
   if old['run_id']!=run_id or old['month']!=month:raise ValueError('기준월·정산 건을 변경하려면 새 현황으로 저장하세요.')
   c.execute('UPDATE jv_status_records SET payload=?,version=version+1 WHERE id=?',(json.dumps(data,ensure_ascii=False),id))
  else:
   if c.execute('SELECT 1 FROM jv_status_records WHERE project_id=? AND member_id=? AND run_id=? AND month=? AND deleted=0',(p,m,run_id,month)).fetchone():raise ValueError('같은 기준월·정산 건의 현황이 있습니다. 불러와 수정하세요.')
   id=c.execute('INSERT INTO jv_status_records(project_id,member_id,run_id,month,payload) VALUES(?,?,?,?,?)',(p,m,run_id,month,json.dumps(data,ensure_ascii=False))).lastrowid
 return id

def set_deleted(c,p,m,id,version,deleted):
 scope(c,p,m);r=get(c,p,m,id,deleted=not deleted);flow.ensure_open(c,p,r['month'])
 if r['version']!=version:raise ValueError('현황이 변경되었습니다. 다시 불러오세요.')
 if not deleted and c.execute('SELECT 1 FROM jv_status_records WHERE project_id=? AND member_id=? AND run_id=? AND month=? AND deleted=0',(p,m,r['run_id'],r['month'])).fetchone():raise ValueError('같은 기준월·정산 건의 현황이 이미 있습니다.')
 with c:c.execute('UPDATE jv_status_records SET deleted=?,version=version+1 WHERE id=?',(int(deleted),id))

def attach(c,d,p,m,run_id,id,refresh=False):
 r=get(c,p,m,id)
 if r['run_id']!=run_id or r['data']['selection']!=d['selection']:raise ValueError('현황의 연결 정산 범위가 변경되었습니다. 현황을 다시 불러와 저장하세요.')
 data=build(c,p,m,run_id,r['month'],r['data']['inputs']) if refresh else r['data']
 return dict(d,nonlead_status=dict(data,status_id=r['id'],status_version=r['version'],source_mode='현재 원본 재계산' if refresh else '현황 저장값'))

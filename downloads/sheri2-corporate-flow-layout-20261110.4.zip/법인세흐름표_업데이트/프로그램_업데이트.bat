﻿@echo off
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
echo [법인세 흐름표 양식 업데이트 2026.11.10.4]
echo 실행 중인 프로그램 서버 창을 먼저 종료해 주세요.
echo 기존 프로그램 폴더의 start.bat을 선택합니다.
pause
call find_python.bat
if errorlevel 1 goto fail
%FINANCE_PYTHON% apply_update.py
if errorlevel 1 goto fail
echo 업데이트가 완료되었습니다. 기존 start.bat을 실행해 주세요.
pause
exit /b 0
:fail
echo 업데이트를 완료하지 못했습니다. 위 오류를 확인해 주세요.
pause
exit /b 1

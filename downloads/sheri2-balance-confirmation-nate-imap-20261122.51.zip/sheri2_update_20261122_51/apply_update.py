"""Install the balance-confirmation and Nate IMAP reply-tracking update."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import sys

ROOT = Path(__file__).resolve().parent
VERSION = '2026.11.22.51'
FILES = ['app_navigation.py','multiuser_app.py','mail_service.py','balance_confirmation_app.py','balance_confirmation_store.py','balance_confirmation_report.py']
REQUIRED = {'app_navigation.py','multiuser_app.py','mail_service.py'}
NEW = {
 'app_navigation.py':'a82e425a391e19ef85b6ad1b495d78201b0c4e02d580835b2e9062249dcd564a',
 'multiuser_app.py':'895b7096b6fc708a8bf063969f79ffaefa5669444107e1eff4a6be8578b046d5',
 'mail_service.py':'67f588f6dbc8d493b019f0517f071f7c13e21c1bad2f6fe7bdf093888b2bdf50',
 'balance_confirmation_app.py':'e37cbbea156c0e63a7d1ce767125ca54d1c20d6151b3f9dd7142c37a9bcbece5',
 'balance_confirmation_store.py':'3ea686095e58b4a7de7cc350dd22913e725dac5c111eafa3e441d067f3113aa4',
 'balance_confirmation_report.py':'927e563905ca444674edbabed49645366f86033c314a99b4c239c0eeece9c1fb',
}
ACCEPTED = {
 'app_navigation.py':{'4d7264c5267464b1417d7da9264daaf716be73110e7e8a55c63985e76ea1b765',NEW['app_navigation.py']},
 'multiuser_app.py':{'3dcbd20fcffe17d4c7712055e75071bc30899cab782ddf2bbe18ed9c4f19245e',NEW['multiuser_app.py']},
 'mail_service.py':{'5c7f95487a079a06b90dc21871c79a361103e2fc8223da8f5f184e4183a5f872',NEW['mail_service.py']},
}

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_package():
 for name in FILES:
  path=ROOT/name
  if not path.is_file() or digest(path)!=NEW[name]:raise ValueError('업데이트 패키지 파일 검증에 실패했습니다: '+name)
  compile(path.read_text(encoding='utf-8'),name,'exec')

def update(target):
 target=Path(target).expanduser().resolve()
 if target.is_file():target=target.parent
 if target==ROOT:raise ValueError('현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.')
 if not (target/'start.bat').is_file():raise ValueError('현재 사용하는 Sheri2 프로그램 폴더가 아닙니다.')
 verify_package()
 for name in REQUIRED:
  installed=target/name
  if not installed.is_file():raise ValueError('필수 프로그램 파일이 없습니다: '+name)
  if digest(installed) not in ACCEPTED[name]:raise ValueError('확인된 50버전 운영본과 다른 파일입니다: '+name+'. 아무 파일도 변경하지 않았습니다.')
 for name in set(FILES)-REQUIRED:
  installed=target/name
  if installed.exists() and digest(installed)!=NEW[name]:raise ValueError('동일한 이름의 확인되지 않은 파일이 있습니다: '+name+'. 아무 파일도 변경하지 않았습니다.')
 stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)
 backup=target/'private'/'code-updates'/stamp;backup.mkdir(parents=True)
 existing=[name for name in FILES if (target/name).is_file()]
 for name in existing:shutil.copy2(target/name,backup/name)
 (backup/'manifest.json').write_text(json.dumps({'version':VERSION,'files':{n:digest(target/n) for n in existing}},ensure_ascii=False,indent=2),encoding='utf-8')
 installed=[]
 try:
  for name in FILES:
   temporary=target/(name+'.update-'+secrets.token_hex(4))
   try:
    shutil.copy2(ROOT/name,temporary)
    if digest(temporary)!=NEW[name]:raise ValueError('복사 파일 검증에 실패했습니다: '+name)
    temporary.replace(target/name);installed.append(name)
   finally:temporary.unlink(missing_ok=True)
 except BaseException:
  for name in reversed(installed):
   if name in existing:shutil.copy2(backup/name,target/name)
   else:(target/name).unlink(missing_ok=True)
  raise
 for name in FILES:
  if digest(target/name)!=NEW[name]:raise ValueError('설치 후 검증에 실패했습니다: '+name)
 print('채권채무확인서·네이트 회신 확인 업데이트 완료:',target)
 print('기존 DB와 회계자료는 삭제하거나 변경하지 않았습니다.')
 print('기존 코드 백업:',backup)

def choose_target():
 if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
 window=None
 try:
  import tkinter as tk
  from tkinter import filedialog
  window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
  return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
 finally:
  if window:window.destroy()

if __name__=='__main__':
 try:
  selected=choose_target()
  if not selected:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
  update(selected)
 except Exception as error:raise SystemExit('업데이트 실패: '+str(error))

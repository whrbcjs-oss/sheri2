"""Display the approved logo image without modifying its source artwork."""
from base64 import b64encode
from functools import lru_cache
from pathlib import Path
from PIL import Image
import streamlit as st

LOGO = Path(__file__).resolve().parent / 'assets' / 'hs_logo.png'


@lru_cache(maxsize=1)
def logo_markup():
    with Image.open(LOGO) as image:
        width, height = image.size
        box = image.getchannel('A').getbbox() if image.mode == 'RGBA' else (0,0,width,height)
    if not box:
        raise ValueError('로고 이미지가 비어 있습니다.')
    left, top, right, bottom = box
    visible_width, visible_height = right-left, bottom-top
    content = b64encode(LOGO.read_bytes()).decode('ascii')
    # Use a CSS viewport to omit transparent canvas padding; keep the PNG intact.
    style = f'width:{width/visible_width*100:.6f}%;left:{-left/visible_width*100:.6f}%;top:{-top/visible_height*100:.6f}%;'
    return f'<div class="hs-sidebar-logo" style="aspect-ratio:{visible_width}/{visible_height}"><img alt="HS 경리Job\'s" src="data:image/png;base64,{content}" style="{style}"></div>'


def render_sidebar_logo():
    with st.sidebar:
        with st.container(key='hs_sidebar_brand'):
            st.markdown(logo_markup(),unsafe_allow_html=True)

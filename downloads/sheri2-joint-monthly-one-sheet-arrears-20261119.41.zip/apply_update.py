"""Install update 41 over the verified v35/v38/v39/v40 joint source."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import sys

ROOT=Path(__file__).resolve().parent
FILES=['joint_app.py','joint_store.py','joint_workflow.py','joint_report.py','app_navigation.py']
ACCEPTED={
    'joint_app.py':{
        'eb847d16da1b2f96e182bb72c3ef87bd28b44b17d7108f9d52720bf398af2f9b',
        'a29ac529569310900cd0db1e218451b306e7c7e10bf08299bd4605acf8e0d177',
        '248862c7898be6c32e8fad3e8b19d03b8d5c19b3fd1e49ab1ccfd61649ac9ce4',
    },
    'joint_store.py':{
        'a5ee881f649d64f377aed49d9e6e3dc644d3629b07fc7439b81e9194a305d622',
        '372acbc3c66a588587f2088392f660b3f27575f52fd3474590b612f81b6783f8',
        '6d0c6ef042bd78690cda48c9c2165edfb770a4b0627190e3e6ceea9bafe40c91',
    },
    'joint_workflow.py':{
        '096c57d46adc850ae30eb577f0858ca66650d2f15be3c0bebe0ed59f411b0b37',
        '28b31b989c670bd87778508f329af2bfc73c30334db45ff20cbbf8c24391b051',
    },
    'joint_report.py':{
        '69a03ee3574f5c5f8d65bba8ba7a6f965137c44cacfc92057e7053200c3036a2',
    },
    'app_navigation.py':{
        '7c9b797ec16d4b3535210a1691b60a78f250f83b877d93bdf33d7972beab85cf',
        'b06b142440743d5231b32b9ecc9f7e7d19c65c90f415e6337e5837f9f375776f',
        '38a5922b1fd4b515046434baccb7ef6fdc4424d246256ae4ae01d54f68e97c43',
        '7ea2f57532e8d5b0aaf3fe316e57d422dab1ebdb45ac84d68769b0285d266039',
    },
}
NEW={
    'joint_app.py':'c2c6cd8f004c3b5e3670059ad6359e67f88681b37d901fe894add11522a2cb4f',
    'joint_store.py':'6a92d80fffdbfe2f151979e7e3232f7c77d2018c5738b5194b7f3adf4674656f',
    'joint_workflow.py':'2b4982aece4d093188e83ef6add2dd83b6d638f915c8a1a45b971cb9acea6990',
    'joint_report.py':'6623d3785547ec7a7eab6021016f41ef1abce9c43b06432a1a143fd9a765a22e',
    'app_navigation.py':'79f129f4018e5080c01d082abb55d10d799871cba9c613268c9d3a24458a8686',
}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def update(target):
    target=Path(target).expanduser().resolve()
    if target.is_file():target=target.parent
    if target==ROOT:raise ValueError('현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.')
    if not (target/'start.bat').is_file():raise ValueError('현재 사용하는 프로그램 폴더가 아닙니다.')
    for name in FILES:
        source=ROOT/name;installed=target/name
        if not source.is_file() or not installed.is_file():raise ValueError('필수 프로그램 파일이 없습니다: '+name)
        if digest(source)!=NEW[name]:raise ValueError('업데이트 패키지 파일 검증에 실패했습니다: '+name)
        current=digest(installed)
        if current not in ACCEPTED[name] and current!=NEW[name]:
            raise ValueError('확인된 최신 공동도급 운영본과 다른 파일입니다: '+name+'. 아무 파일도 변경하지 않았습니다.')
        compile(source.read_text(encoding='utf-8'),name,'exec')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)
    backup=target/'private'/'code-updates'/stamp;backup.mkdir(parents=True)
    manifest={}
    for name in FILES:
        path=target/name;manifest[name]=digest(path);shutil.copy2(path,backup/name)
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    installed_names=[]
    try:
        for name in FILES:
            destination=target/name;temporary=target/(name+'.update-'+secrets.token_hex(4))
            try:
                shutil.copy2(ROOT/name,temporary)
                if digest(temporary)!=NEW[name]:raise ValueError('복사 파일 검증에 실패했습니다: '+name)
                temporary.replace(destination);installed_names.append(name)
            finally:temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed_names):shutil.copy2(backup/name,target/name)
        raise
    for name in FILES:
        if digest(target/name)!=NEW[name]:raise ValueError('설치 후 검증에 실패했습니다: '+name)
    print('공동도급 월별 통합 정산서·전월 미수 누계 업데이트 완료:',target)
    print('기존 코드 백업:',backup)
    print('DB, 원장, 정산, 마감 및 발행자료는 삭제하거나 변경하지 않았습니다.')

def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
    finally:
        if window:window.destroy()

if __name__=='__main__':
    try:
        value=choose_target()
        if not value:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
        update(value)
    except Exception as error:raise SystemExit('업데이트 실패: '+str(error))

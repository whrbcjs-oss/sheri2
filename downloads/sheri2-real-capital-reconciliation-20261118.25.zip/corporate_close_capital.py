"""Construction-company real-capital review, statement import and reports."""
from __future__ import annotations

from html import escape
from io import BytesIO, StringIO
from pathlib import Path
import csv
import math
import re
import sys

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


ITEM_COLUMNS = ["구분", "계정과목", "원천금액", "차감액", "인정조정액", "판정", "근거·비고", "출처"]
LICENSE_COLUMNS = ["면허명·업종", "요구자본금", "중복·겸업 조정액", "적용연도", "근거·비고"]
TRIAL_COLUMNS = ["계정과목", "차변잔액", "대변잔액", "구분", "분류", "특수처리", "순금액", "근거·비고", "출처"]
TRIAL_GROUPS = ["자산", "부채", "제외", "미분류"]
TRIAL_CLASSES = ["인정", "일반", "부실", "겸업", "검토 필요", ""]
SPECIAL_OPTIONS = ["현금", "예금", "공사미수금", "퇴직급여충당", ""]
DECISION_OPTIONS = ["전액 인정", "일부 인정", "전액 차감", "검토 필요"]
CATEGORY_OPTIONS = ["자본", "차감검토", "인정조정"]

CAPITAL_ALIASES = {
    "자본총계": ["자본총계", "자기자본"],
    "납입자본금": ["납입자본금"],
    "자본금": ["자본금"],
    "자본잉여금": ["자본잉여금"],
    "이익잉여금": ["이익잉여금", "결손금"],
    "기타포괄손익누계액": ["기타포괄손익누계액"],
}
REVIEW_ALIASES = {
    "미수금": ["미수금", "공사미수금"],
    "관계회사대여금": ["관계회사대여금"],
    "주임종단기채권": ["주임종단기채권", "주임종단기대여금"],
    "단기대여금": ["단기대여금"],
    "장기대여금": ["장기대여금"],
    "미수수익": ["미수수익"],
    "선급금": ["선급금"],
    "선급비용": ["선급비용"],
    "미완성공사": ["미완성공사", "미완성공사(분양)"],
    "임목": ["임목"],
    "토지": ["토지"],
    "건물": ["건물"],
    "개발비": ["개발비"],
    "소프트웨어": ["소프트웨어"],
    "임차보증금": ["임차보증금"],
    "회원권": ["회원권"],
}

DEFAULT_ACCOUNT_MAP = {
    "현금": ("자산", "인정", "현금"), "보통예금": ("자산", "인정", "예금"),
    "당좌예금": ("자산", "인정", "예금"), "정기예금": ("자산", "인정", "예금"),
    "정기적금": ("자산", "인정", "예금"), "단기매매증권": ("자산", "부실", ""),
    "공사미수금": ("자산", "인정", "공사미수금"), "받을어음": ("자산", "검토 필요", ""),
    "대손충당금": ("자산", "인정", ""), "미수금": ("자산", "검토 필요", ""),
    "선급금": ("자산", "검토 필요", ""), "선급비용": ("자산", "인정", ""),
    "가지급금": ("자산", "부실", ""), "단기대여금": ("자산", "검토 필요", ""),
    "장기대여금": ("자산", "부실", ""), "부가세대급금": ("자산", "검토 필요", ""),
    "토지": ("자산", "검토 필요", ""), "건물": ("자산", "검토 필요", ""),
    "건물감가상각누계액": ("자산", "인정", ""), "구축물": ("자산", "인정", ""),
    "기계장치": ("자산", "인정", ""), "기계장치감가상각누계액": ("자산", "인정", ""),
    "차량운반구": ("자산", "인정", ""), "차량운반구감가상각누계액": ("자산", "인정", ""),
    "비품": ("자산", "인정", ""), "비품감가상각누계액": ("자산", "인정", ""),
    "공제조합출자금": ("자산", "인정", ""), "임차보증금": ("자산", "검토 필요", ""),
    "특허권": ("자산", "검토 필요", ""), "소프트웨어": ("자산", "검토 필요", ""),
    "개발비": ("자산", "부실", ""), "이연법인세자산": ("자산", "부실", ""),
    "장기투자증권": ("자산", "부실", ""), "외상매입금": ("부채", "일반", ""),
    "미지급금": ("부채", "일반", ""), "미지급비용": ("부채", "일반", ""),
    "미지급세금": ("부채", "일반", ""), "미지급법인세": ("부채", "일반", ""),
    "예수금": ("부채", "일반", ""), "부가세예수금": ("부채", "일반", ""),
    "선수금": ("부채", "일반", ""), "단기차입금": ("부채", "일반", ""),
    "유동성장기부채": ("부채", "일반", ""), "장기차입금": ("부채", "일반", ""),
    "퇴직급여충당부채": ("부채", "일반", "퇴직급여충당"),
    "하자보수충당부채": ("부채", "일반", ""), "공사손실충당부채": ("부채", "일반", ""),
    "자본금": ("제외", "", ""), "자본잉여금": ("제외", "", ""),
    "이익잉여금": ("제외", "", ""), "미처분이익잉여금": ("제외", "", ""),
}


def norm(value):
    return re.sub(r"[\s\n\r()·._\-\[\]]", "", str(value or "")).lower()


def number(value):
    if value in (None, "", "-") or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(round(float(value))) if math.isfinite(float(value)) else None
    text = str(value).strip().replace(",", "").replace("원", "")
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    try:
        return int(round(float(text)))
    except (TypeError, ValueError):
        return None


def _matrixes(name, content):
    lower = str(name).lower()
    if lower.endswith(".csv"):
        text = content.decode("utf-8-sig", errors="replace")
        return [("CSV", list(csv.reader(StringIO(text))))]
    if lower.endswith(".xls"):
        try:
            import xlrd
        except ImportError:
            wheel = Path(__file__).resolve().parent / "vendor" / "xlrd-2.0.2-py2.py3-none-any.whl"
            if wheel.is_file() and str(wheel) not in sys.path:
                sys.path.insert(0, str(wheel))
            import xlrd
        book = xlrd.open_workbook(file_contents=content, on_demand=True)
        return [(book.sheet_by_index(i).name,
                 [[cell.value for cell in book.sheet_by_index(i).row(r)] for r in range(book.sheet_by_index(i).nrows)])
                for i in range(book.nsheets)]
    if not lower.endswith(".xlsx"):
        raise ValueError("XLS, XLSX 또는 CSV 재무자료만 업로드할 수 있습니다.")
    book = openpyxl.load_workbook(BytesIO(content), data_only=True, read_only=True)
    return [(ws.title, [list(row) for row in ws.iter_rows(values_only=True)]) for ws in book]


def _right_amount(matrix, row_index, column):
    row = matrix[row_index]
    candidates = []
    for value_column in range(column + 1, len(row)):
        value = number(row[value_column])
        if value is None:
            continue
        header = norm(" ".join(str(matrix[up][value_column] or "") for up in range(max(0, row_index - 8), row_index) if value_column < len(matrix[up])))
        score = 0
        if any(word in header for word in ["당기", "기말", "현재"]):score += 60
        if "잔액" in header:score += 35
        if "금액" in header:score += 10
        if any(word in header for word in ["전기", "기초"]):score -= 60
        candidates.append((score, -value_column, value))
    if not candidates:return None
    # When no header is recognizable, retain the first amount to the right.
    if max(score for score, _, _ in candidates) == 0:return max(candidates, key=lambda item:item[1])[2]
    return max(candidates, key=lambda item:(item[0], abs(item[2]), item[1]))[2]


def extract_statement(name, content):
    """Extract exact account labels while leaving legal recognition to the reviewer."""
    found = {}
    alias_map = []
    for account, aliases in CAPITAL_ALIASES.items():
        alias_map.extend((norm(alias), "자본", account) for alias in aliases)
    for account, aliases in REVIEW_ALIASES.items():
        alias_map.extend((norm(alias), "차감검토", account) for alias in aliases)
    for sheet_name, matrix in _matrixes(name, content):
        for row_no, row in enumerate(matrix, 1):
            for column, cell in enumerate(row):
                label = norm(cell)
                if not label:
                    continue
                match = next(((category, account) for alias, category, account in alias_map if alias == label), None)
                if not match:
                    continue
                amount = _right_amount(matrix, row_no - 1, column)
                if amount is None:
                    continue
                category, account = match
                key = (category, account)
                if key not in found:
                    found[key] = {
                        "구분": category, "계정과목": account, "원천금액": amount,
                        "차감액": 0, "인정조정액": 0,
                        "판정": "전액 인정" if category == "자본" else "검토 필요",
                        "근거·비고": "", "출처": f"{sheet_name} {row_no}행",
                    }
    items = list(found.values())
    # A reported total is safer than summing its components twice.
    if any(row["구분"] == "자본" and row["계정과목"] == "자본총계" for row in items):
        items = [row for row in items if row["구분"] != "자본" or row["계정과목"] == "자본총계"]
    items.sort(key=lambda row: (CATEGORY_OPTIONS.index(row["구분"]), row["계정과목"]))
    return {"items": items, "found": len(items)}


def _uploaded_account_mapping(matrixes):
    mapping = dict(DEFAULT_ACCOUNT_MAP)
    for sheet_name, matrix in matrixes:
        if "계정매핑" not in norm(sheet_name):
            continue
        header_row = next((i for i, row in enumerate(matrix) if any(norm(value) == "계정과목" for value in row) and any(norm(value) == "구분" for value in row)), None)
        if header_row is None:
            continue
        headers = {norm(value): column for column, value in enumerate(matrix[header_row]) if value not in (None, "")}
        for row in matrix[header_row + 1:]:
            if headers.get("계정과목", 10**6) >= len(row):continue
            account = str(row[headers["계정과목"]] or "").strip()
            if not account:continue
            def cell(key):
                column = headers.get(key)
                return str(row[column] or "").strip() if column is not None and column < len(row) else ""
            mapping[account] = (cell("구분") or "미분류", cell("분류"), cell("특수처리"))
    return mapping


def _header_index(headers, aliases):
    for alias in aliases:
        if norm(alias) in headers:return headers[norm(alias)]
    return None


def extract_trial_balance(name, content):
    """Read debit/credit balances and classifications without replacing source amounts."""
    matrixes = _matrixes(name, content);mapping = _uploaded_account_mapping(matrixes)
    normalized_mapping = {norm(account): value for account, value in mapping.items()}
    output = []
    for sheet_name, matrix in matrixes:
        if "계정매핑" in norm(sheet_name) or "사용법" in norm(sheet_name) or "실질자본금" == norm(sheet_name):continue
        header_row = None;headers = {}
        for i, row in enumerate(matrix):
            candidate = {norm(value): column for column, value in enumerate(row) if value not in (None, "")}
            account_col = _header_index(candidate, ["계정과목", "계정명", "과목"])
            debit_col = _header_index(candidate, ["차변잔액", "차변금액", "차변"])
            credit_col = _header_index(candidate, ["대변잔액", "대변금액", "대변"])
            amount_col = _header_index(candidate, ["당기금액", "당기", "금액", "잔액"])
            if account_col is not None and ((debit_col is not None and credit_col is not None) or amount_col is not None):
                header_row=i;headers=candidate;break
        if header_row is None:continue
        account_col=_header_index(headers,["계정과목","계정명","과목"]);debit_col=_header_index(headers,["차변잔액","차변금액","차변"]);credit_col=_header_index(headers,["대변잔액","대변금액","대변"]);amount_col=_header_index(headers,["당기금액","당기","금액","잔액"])
        group_col=_header_index(headers,["구분"]);class_col=_header_index(headers,["분류"]);special_col=_header_index(headers,["특수처리"]);net_col=_header_index(headers,["순금액","잔액"]);note_col=_header_index(headers,["근거·비고","비고"])
        for row_no, row in enumerate(matrix[header_row + 1:], header_row + 2):
            if account_col >= len(row):continue
            account=str(row[account_col] or "").strip();account_norm=norm(account)
            if not account or account_norm in ["월계","누계"] or re.fullmatch(r"\d{1,2}월계",account_norm):continue
            if account_norm in ["계", "합계", "총계", "자산총계", "부채총계", "자본총계", "부채및자본총계"]:continue
            default_group,default_class,default_special=normalized_mapping.get(account_norm,("미분류","",""))
            def read(column,default=""):
                return str(row[column] or "").strip() if column is not None and column < len(row) else default
            group=read(group_col,default_group) or default_group;classification=read(class_col,default_class);special=read(special_col,default_special)
            if group not in TRIAL_GROUPS:group="미분류"
            if classification not in TRIAL_CLASSES:classification="검토 필요" if group=="자산" else ""
            if debit_col is not None and credit_col is not None:
                debit=number(row[debit_col]) if debit_col < len(row) else 0;credit=number(row[credit_col]) if credit_col < len(row) else 0
            else:
                amount=number(row[amount_col]) if amount_col is not None and amount_col < len(row) else 0
                debit=amount if group=="자산" else 0;credit=amount if group in ["부채","제외"] else 0
            debit=debit or 0;credit=credit or 0
            if not debit and not credit:continue
            calculated=debit-credit if group=="자산" else credit-debit if group=="부채" else 0
            supplied=number(row[net_col]) if net_col is not None and net_col < len(row) else None
            net=calculated if supplied is None or group in ["자산","부채"] else supplied
            output.append({"계정과목":account,"차변잔액":debit,"대변잔액":credit,"구분":group,"분류":classification,"특수처리":special,"순금액":net,"근거·비고":read(note_col),"출처":f"{sheet_name} {row_no}행"})
    imported_adjustments={};reference_required_capital=None
    input_labels={"예금결산일전후30일평균잔액":"deposit_average","공사미수금중인정기간2년초과분":"expired_receivables","기타부실자산조정차감액":"other_bad_assets","퇴직급여추계액결산일전원퇴직가정":"retirement_estimate","기타부외부채미지급세금등":"other_offbook_liabilities"}
    for sheet_name,matrix in matrixes:
        if "실질자본금" not in norm(sheet_name):continue
        for row in matrix:
            if len(row)<2:continue
            if norm(row[0]) in ["등록기준자본금보유면허기준","등록기준자본금"] and number(row[1]) is not None:reference_required_capital=number(row[1])
            key=input_labels.get(norm(row[0]));value=number(row[1])
            if key and value is not None:imported_adjustments[key]=value
    return {"trial_rows":output,"adjustments":imported_adjustments,"reference_required_capital":reference_required_capital,"found":len(output),"unclassified":sum(1 for row in output if row["구분"]=="미분류")}


def clean_trial_rows(rows):
    cleaned=[]
    for raw in rows or []:
        account_value=raw.get("계정과목","");account="" if account_value is None or str(account_value).strip().lower()=="nan" else str(account_value).strip()
        if not account:continue
        debit=max(0,number(raw.get("차변잔액")) or 0);credit=max(0,number(raw.get("대변잔액")) or 0)
        group=str(raw.get("구분","") or "미분류");group=group if group in TRIAL_GROUPS else "미분류"
        classification=str(raw.get("분류","") or "");classification=classification if classification in TRIAL_CLASSES else "검토 필요" if group=="자산" else ""
        special=str(raw.get("특수처리","") or "");special=special if special in SPECIAL_OPTIONS else ""
        net=debit-credit if group=="자산" else credit-debit if group=="부채" else 0
        cleaned.append({"계정과목":account,"차변잔액":debit,"대변잔액":credit,"구분":group,"분류":classification,"특수처리":special,"순금액":net,"근거·비고":str(raw.get("근거·비고","") or "").strip(),"출처":str(raw.get("출처","직접입력") or "직접입력").strip()})
    return cleaned


def calculate_trial_balance(trial_rows, adjustments, licenses, year=None):
    rows=clean_trial_rows(trial_rows);adjustments=dict(adjustments or {});license_rows=clean_licenses(licenses,year or 0)
    accounting_assets=sum(row["순금액"] for row in rows if row["구분"]=="자산")
    accounting_liabilities=sum(row["순금액"] for row in rows if row["구분"]=="부채")
    accounting_equity=accounting_assets-accounting_liabilities
    classified_bad=sum(row["순금액"] for row in rows if row["구분"]=="자산" and row["분류"]=="부실")
    cash=sum(row["순금액"] for row in rows if row["구분"]=="자산" and row["특수처리"]=="현금")
    cash_excess=max(0,cash-max(0,accounting_equity)*.01)
    deposits=sum(row["순금액"] for row in rows if row["구분"]=="자산" and row["특수처리"]=="예금")
    deposit_average=adjustments.get("deposit_average")
    deposit_average=None if deposit_average in (None,"") else number(deposit_average)
    deposit_adjustment=max(0,deposits-deposit_average) if deposit_average is not None else 0
    expired=max(0,number(adjustments.get("expired_receivables")) or 0);other_bad=max(0,number(adjustments.get("other_bad_assets")) or 0)
    bad_total=classified_bad+cash_excess+deposit_adjustment+expired+other_bad
    concurrent_assets=sum(row["순금액"] for row in rows if row["구분"]=="자산" and row["분류"]=="겸업")
    real_assets=accounting_assets-bad_total-concurrent_assets
    retirement_book=sum(row["순금액"] for row in rows if row["구분"]=="부채" and row["특수처리"]=="퇴직급여충당")
    retirement_estimate=adjustments.get("retirement_estimate");retirement_estimate=None if retirement_estimate in (None,"") else number(retirement_estimate)
    retirement_offbook=max(0,(retirement_estimate or 0)-retirement_book) if retirement_estimate is not None else 0
    other_offbook=max(0,number(adjustments.get("other_offbook_liabilities")) or 0)
    concurrent_liabilities=sum(row["순금액"] for row in rows if row["구분"]=="부채" and row["분류"]=="겸업")
    real_liabilities=accounting_liabilities+retirement_offbook+other_offbook-concurrent_liabilities
    real_capital=real_assets-real_liabilities
    detailed=[]
    for row in license_rows:
        applied=max(0,row["요구자본금"]+row["중복·겸업 조정액"]);detailed.append({**row,"최종 적용자본금":applied})
    required=sum(row["최종 적용자본금"] for row in detailed);surplus=real_capital-required
    unclassified=sum(1 for row in rows if row["구분"]=="미분류" and (row["차변잔액"] or row["대변잔액"]))
    review_count=sum(1 for row in rows if row["구분"]=="자산" and row["분류"]=="검토 필요" and row["순금액"]!=0)
    status="면허기준 미등록" if required<=0 else "검토 중" if unclassified else "충족" if surplus>=0 else "미달"
    return {"trial_rows":rows,"licenses":detailed,"accounting_assets":accounting_assets,"accounting_liabilities":accounting_liabilities,"accounting_equity":accounting_equity,"classified_bad":classified_bad,"cash":cash,"cash_excess":int(round(cash_excess)),"deposits":deposits,"deposit_average":deposit_average,"deposit_adjustment":deposit_adjustment,"expired_receivables":expired,"other_bad_assets":other_bad,"bad_total":bad_total,"concurrent_assets":concurrent_assets,"real_assets":real_assets,"retirement_book":retirement_book,"retirement_estimate":retirement_estimate,"retirement_offbook":retirement_offbook,"other_offbook_liabilities":other_offbook,"concurrent_liabilities":concurrent_liabilities,"real_liabilities":real_liabilities,"real_capital":real_capital,"required":required,"surplus":surplus,"status":status,"unclassified":unclassified,"review_count":review_count}


def clean_items(items):
    cleaned = []
    for raw in items or []:
        account_value = raw.get("계정과목", "")
        account = "" if account_value is None or str(account_value).strip().lower() == "nan" else str(account_value).strip()
        if not account:
            continue
        category = str(raw.get("구분", "차감검토") or "차감검토")
        if category not in CATEGORY_OPTIONS:
            category = "차감검토"
        decision = str(raw.get("판정", "검토 필요") or "검토 필요")
        if decision not in DECISION_OPTIONS:
            decision = "검토 필요"
        source_amount = number(raw.get("원천금액")) or 0
        deduction = max(0, number(raw.get("차감액")) or 0)
        adjustment = number(raw.get("인정조정액")) or 0
        if category == "차감검토" and decision == "전액 차감" and deduction == 0:
            deduction = max(0, source_amount)
        cleaned.append({
            "구분": category, "계정과목": account, "원천금액": source_amount,
            "차감액": deduction, "인정조정액": adjustment, "판정": decision,
            "근거·비고": str(raw.get("근거·비고", "") or "").strip(),
            "출처": str(raw.get("출처", "직접입력") or "직접입력").strip(),
        })
    return cleaned


def clean_licenses(licenses, year):
    cleaned = []
    for raw in licenses or []:
        name_value = raw.get("면허명·업종", "")
        name = "" if name_value is None or str(name_value).strip().lower() == "nan" else str(name_value).strip()
        if not name:
            continue
        required = max(0, number(raw.get("요구자본금")) or 0)
        adjustment = number(raw.get("중복·겸업 조정액")) or 0
        cleaned.append({
            "면허명·업종": name, "요구자본금": required,
            "중복·겸업 조정액": adjustment,
            "적용연도": int(number(raw.get("적용연도")) or year),
            "근거·비고": str(raw.get("근거·비고", "") or "").strip(),
        })
    return cleaned


def calculate(items, licenses, year=None):
    rows = clean_items(items)
    license_rows = clean_licenses(licenses, year or 0)
    capital_rows = [row for row in rows if row["구분"] == "자본"]
    reported_total = [row for row in capital_rows if norm(row["계정과목"]) in ["자본총계", "자기자본"]]
    capital = sum(row["원천금액"] for row in (reported_total or capital_rows))
    deduction = sum(row["차감액"] for row in rows if row["구분"] == "차감검토")
    adjustment = sum(row["인정조정액"] for row in rows)
    real_capital = capital - deduction + adjustment
    detailed = []
    for row in license_rows:
        applied = max(0, row["요구자본금"] + row["중복·겸업 조정액"])
        detailed.append({**row, "최종 적용자본금": applied})
    required = sum(row["최종 적용자본금"] for row in detailed)
    surplus = real_capital - required
    unresolved = sum(1 for row in rows if row["구분"] == "차감검토" and row["판정"] == "검토 필요")
    status = "면허기준 미입력" if required <= 0 else "검토 중" if unresolved else "충족" if surplus >= 0 else "미충족"
    return {
        "items": rows, "licenses": detailed, "capital": capital, "deduction": deduction,
        "adjustment": adjustment, "real_capital": real_capital, "required": required,
        "surplus": surplus, "status": status,
        "unresolved": unresolved,
    }


def _money(value):
    return f"{int(value or 0):,}"


def report_workbook(company, year, result):
    book = openpyxl.Workbook()
    sheet = book.active
    sheet.title = f"{year}.실질자본금"[:31]
    dark, green, pale, yellow, red = "173F59", "087A4F", "EAF3F7", "FFF2A8", "FCE8E6"
    thin = Side(style="thin", color="AAB8BF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    sheet.merge_cells("A1:H1");sheet["A1"] = f"{year}년 실질자본금 적격여부 검토표"
    sheet["A1"].font = Font(name="맑은 고딕", size=18, bold=True, color="FFFFFF")
    sheet["A1"].fill = PatternFill("solid", fgColor=dark);sheet["A1"].alignment = Alignment(horizontal="center")
    sheet.merge_cells("A2:D2");sheet["A2"] = f"결산법인  {company}"
    sheet.merge_cells("E2:H2");sheet["E2"] = f"결산연도  {year}년"
    for cell in sheet[2]:cell.fill = PatternFill("solid", fgColor=pale);cell.font = Font(name="맑은 고딕", bold=True, color=dark);cell.alignment = Alignment(horizontal="center")
    headers = ITEM_COLUMNS
    sheet.append(headers)
    for row in result["items"]:sheet.append([row.get(key, "") for key in headers])
    start = 3
    for cell in sheet[start]:cell.fill = PatternFill("solid", fgColor=green);cell.font = Font(name="맑은 고딕", bold=True, color="FFFFFF");cell.alignment = Alignment(horizontal="center")
    summary_row = sheet.max_row + 2
    summary = [("자본총계", result["capital"]), ("차감대상 자산", result["deduction"]), ("인정 조정액", result["adjustment"]), ("실질자본금", result["real_capital"]), ("최종 필요자본금", result["required"]), ("충족 여유액(부족액)", result["surplus"])]
    for offset, (label, value) in enumerate(summary):
        row = summary_row + offset;sheet.cell(row, 1, label);sheet.merge_cells(start_row=row, start_column=2, end_row=row, end_column=4);sheet.cell(row, 2, value)
        sheet.cell(row, 1).font = Font(name="맑은 고딕", bold=True);sheet.cell(row, 2).font = Font(name="맑은 고딕", bold=True, color="D92C25" if offset >= 3 else "126BB0")
        for col in range(1, 5):sheet.cell(row, col).fill = PatternFill("solid", fgColor=yellow if offset >= 3 else pale);sheet.cell(row, col).border = border
        sheet.cell(row, 2).number_format = "#,##0;[Red]-#,##0";sheet.cell(row, 2).alignment = Alignment(horizontal="right")
    license_start = summary_row
    sheet.merge_cells(start_row=license_start, start_column=5, end_row=license_start, end_column=8);sheet.cell(license_start, 5, "회사별 면허 기준자본금")
    sheet.cell(license_start, 5).fill = PatternFill("solid", fgColor=green);sheet.cell(license_start, 5).font = Font(name="맑은 고딕", bold=True, color="FFFFFF");sheet.cell(license_start, 5).alignment = Alignment(horizontal="center")
    license_headers = ["면허명·업종", "요구자본금", "조정액", "최종 적용자본금"]
    for col, label in enumerate(license_headers, 5):sheet.cell(license_start + 1, col, label)
    for i, row in enumerate(result["licenses"], license_start + 2):
        values = [row["면허명·업종"], row["요구자본금"], row["중복·겸업 조정액"], row["최종 적용자본금"]]
        for col, value in enumerate(values, 5):sheet.cell(i, col, value)
    max_row = max(sheet.max_row, license_start + len(result["licenses"]) + 1)
    for row in sheet.iter_rows(min_row=3, max_row=max_row, min_col=1, max_col=8):
        for cell in row:
            cell.border = border;cell.font = cell.font.copy(name="맑은 고딕");cell.alignment = Alignment(horizontal="right" if cell.column in [3,4,5,6,7,8] and isinstance(cell.value, (int, float)) else "center", vertical="center", wrap_text=True)
            if isinstance(cell.value, (int, float)):cell.number_format = "#,##0;[Red]-#,##0"
    for col, width in enumerate([13,22,16,16,16,18,28,18], 1):sheet.column_dimensions[get_column_letter(col)].width = width
    sheet.freeze_panes = "A4";sheet.sheet_view.showGridLines = False;sheet.print_area = f"A1:H{max_row}";sheet.page_setup.orientation = "landscape";sheet.page_setup.fitToWidth = 1;sheet.sheet_properties.pageSetUpPr.fitToPage = True
    output = BytesIO();book.save(output);return output.getvalue()


def report_html(company, year, result):
    item_rows = "".join("<tr>" + "".join(f"<td class='{('num' if key in ['원천금액','차감액','인정조정액'] else '')}'>{_money(row[key]) if key in ['원천금액','차감액','인정조정액'] else escape(str(row[key]))}</td>" for key in ITEM_COLUMNS) + "</tr>" for row in result["items"])
    license_rows = "".join(f"<tr><td>{escape(row['면허명·업종'])}</td><td class='num'>{_money(row['요구자본금'])}</td><td class='num'>{_money(row['중복·겸업 조정액'])}</td><td class='num'>{_money(row['최종 적용자본금'])}</td><td>{escape(row['근거·비고'])}</td></tr>" for row in result["licenses"])
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>실질자본금 검토표</title><style>
    @page{{size:A4 landscape;margin:9mm}}body{{font-family:"Malgun Gothic",sans-serif;color:#173f59;margin:0}}button{{padding:7px 14px;margin-bottom:8px}}h1{{background:#173f59;color:#fff;padding:12px;text-align:center;font-size:20px;margin:0}}.identity{{display:flex;justify-content:space-between;background:#eaf3f7;padding:9px 14px;font-weight:700}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin:10px 0}}.card{{border:1px solid #b9cbd4;border-radius:6px;padding:8px;text-align:center;background:#f7fafb}}.card strong{{display:block;color:#126bb0;font-size:16px;margin-top:4px}}.result{{background:#fff2a8}}.result strong{{color:#d92c25}}h2{{font-size:14px;background:#087a4f;color:white;padding:6px 8px;margin:12px 0 0}}table{{border-collapse:collapse;width:100%;font-size:9px}}th,td{{border:1px solid #aab8bf;padding:4px;text-align:center}}th{{background:#eaf3f7}}td.num{{text-align:right;color:#126bb0;font-variant-numeric:tabular-nums}}@media print{{button{{display:none}}}}</style></head><body>
    <button onclick="window.print()">인쇄 · PDF 저장</button><h1>{year}년 실질자본금 적격여부 검토표</h1><div class="identity"><span>결산법인　{escape(company)}</span><span>결산연도　{year}년</span><span>판정　{result['status']}</span></div>
    <div class="cards"><div class="card">자본총계<strong>{_money(result['capital'])}원</strong></div><div class="card">차감대상 자산<strong>{_money(result['deduction'])}원</strong></div><div class="card result">실질자본금<strong>{_money(result['real_capital'])}원</strong></div><div class="card result">여유액(부족액)<strong>{_money(result['surplus'])}원</strong></div></div>
    <h2>실질자본금 계산내역</h2><table><thead><tr>{''.join(f'<th>{escape(key)}</th>' for key in ITEM_COLUMNS)}</tr></thead><tbody>{item_rows}</tbody></table>
    <h2>회사별 면허 기준자본금</h2><table><thead><tr><th>면허명·업종</th><th>요구자본금</th><th>중복·겸업 조정액</th><th>최종 적용자본금</th><th>근거·비고</th></tr></thead><tbody>{license_rows}</tbody></table>
    <p style="font-size:9px;color:#667">면허별 법정 기준과 중복·겸업 조정은 적용연도 및 근거자료를 확인한 후 확정하십시오.</p></body></html>'''.encode("utf-8")


def _trial_summary_rows(result):
    return [
        ("회계상 금액","회계상 자산총계",result["accounting_assets"]),("회계상 금액","회계상 부채총계",result["accounting_liabilities"]),("회계상 금액","회계상 자본총계",result["accounting_equity"]),
        ("실질자산","(-) 계정분류상 부실자산",result["classified_bad"]),("실질자산","(-) 현금 한도초과분",result["cash_excess"]),("실질자산","(-) 예금 평균잔액 조정",result["deposit_adjustment"]),("실질자산","(-) 공사미수금 인정기간 초과분",result["expired_receivables"]),("실질자산","(-) 기타 부실자산 조정",result["other_bad_assets"]),("실질자산","부실자산 합계",result["bad_total"]),("실질자산","(-) 겸업자산",result["concurrent_assets"]),("실질자산","실질자산",result["real_assets"]),
        ("실질부채","회계상 부채총계",result["accounting_liabilities"]),("실질부채","(+) 퇴직급여 부외부채",result["retirement_offbook"]),("실질부채","(+) 기타 부외부채",result["other_offbook_liabilities"]),("실질부채","(-) 겸업부채",result["concurrent_liabilities"]),("실질부채","실질부채",result["real_liabilities"]),
        ("판정","실질자본금",result["real_capital"]),("판정","등록기준 자본금",result["required"]),("판정","여유(부족) 금액",result["surplus"]),
    ]


def trial_report_workbook(company,year,result):
    book=openpyxl.Workbook();sheet=book.active;sheet.title=f"{year}.실질자본금"[:31]
    dark,green,pale,yellow="173F59","087A4F","EAF3F7","FFF2A8";thin=Side(style="thin",color="AAB8BF");border=Border(left=thin,right=thin,top=thin,bottom=thin)
    sheet.merge_cells("A1:I1");sheet["A1"]=f"{year}년 실질자본금 적격여부 검토표";sheet["A1"].font=Font(name="맑은 고딕",size=18,bold=True,color="FFFFFF");sheet["A1"].fill=PatternFill("solid",fgColor=dark);sheet["A1"].alignment=Alignment(horizontal="center")
    sheet.merge_cells("A2:E2");sheet["A2"]=f"결산법인  {company}";sheet.merge_cells("F2:I2");sheet["F2"]=f"결산연도  {year}년　판정  {result['status']}"
    for cell in sheet[2]:cell.fill=PatternFill("solid",fgColor=pale);cell.font=Font(name="맑은 고딕",bold=True,color=dark);cell.alignment=Alignment(horizontal="center")
    summary_start=4
    for row_no,(section,label,value) in enumerate(_trial_summary_rows(result),summary_start):
        sheet.cell(row_no,1,section);sheet.merge_cells(start_row=row_no,start_column=2,end_row=row_no,end_column=4);sheet.cell(row_no,2,label);sheet.merge_cells(start_row=row_no,start_column=5,end_row=row_no,end_column=6);sheet.cell(row_no,5,value)
        for col in range(1,7):sheet.cell(row_no,col).border=border;sheet.cell(row_no,col).fill=PatternFill("solid",fgColor=yellow if section=="판정" else pale if label in ["회계상 자본총계","실질자산","실질부채"] else "FFFFFF")
        sheet.cell(row_no,5).number_format="#,##0;[Red]-#,##0";sheet.cell(row_no,5).alignment=Alignment(horizontal="right");sheet.cell(row_no,5).font=Font(name="맑은 고딕",bold=section=="판정",color="D92C25" if section=="판정" else "126BB0")
    license_row=summary_start
    sheet.merge_cells(start_row=license_row,start_column=7,end_row=license_row,end_column=9);sheet.cell(license_row,7,"회사별 면허 기준자본금");sheet.cell(license_row,7).fill=PatternFill("solid",fgColor=green);sheet.cell(license_row,7).font=Font(name="맑은 고딕",bold=True,color="FFFFFF");sheet.cell(license_row,7).alignment=Alignment(horizontal="center")
    for col,label in enumerate(["면허명·업종","요구자본금","최종 적용자본금"],7):sheet.cell(license_row+1,col,label)
    for i,row in enumerate(result["licenses"],license_row+2):
        for col,value in enumerate([row["면허명·업종"],row["요구자본금"],row["최종 적용자본금"]],7):sheet.cell(i,col,value)
    trial_start=max(summary_start+len(_trial_summary_rows(result))+2,license_row+len(result["licenses"])+3)
    sheet.merge_cells(start_row=trial_start,start_column=1,end_row=trial_start,end_column=9);sheet.cell(trial_start,1,"합계잔액시산표 계정분류");sheet.cell(trial_start,1).fill=PatternFill("solid",fgColor=green);sheet.cell(trial_start,1).font=Font(name="맑은 고딕",bold=True,color="FFFFFF");sheet.cell(trial_start,1).alignment=Alignment(horizontal="center")
    for col,label in enumerate(TRIAL_COLUMNS,1):sheet.cell(trial_start+1,col,label)
    for i,row in enumerate(result["trial_rows"],trial_start+2):
        for col,key in enumerate(TRIAL_COLUMNS,1):sheet.cell(i,col,row.get(key,""))
    max_row=sheet.max_row
    for row in sheet.iter_rows(min_row=3,max_row=max_row,min_col=1,max_col=9):
        for cell in row:
            cell.border=border;cell.alignment=Alignment(horizontal="right" if isinstance(cell.value,(int,float)) else "center",vertical="center",wrap_text=True)
            if isinstance(cell.value,(int,float)):cell.number_format="#,##0;[Red]-#,##0"
    for col,width in enumerate([13,22,16,16,16,16,16,25,18],1):sheet.column_dimensions[get_column_letter(col)].width=width
    sheet.freeze_panes=f"A{trial_start+2}";sheet.sheet_view.showGridLines=False;sheet.print_area=f"A1:I{max_row}";sheet.page_setup.orientation="landscape";sheet.page_setup.fitToWidth=1;sheet.sheet_properties.pageSetUpPr.fitToPage=True
    output=BytesIO();book.save(output);return output.getvalue()


def trial_report_html(company,year,result):
    summary="".join(f"<tr><td>{escape(section)}</td><td>{escape(label)}</td><td class='num'>{_money(value)}</td></tr>" for section,label,value in _trial_summary_rows(result))
    licenses="".join(f"<tr><td>{escape(row['면허명·업종'])}</td><td class='num'>{_money(row['요구자본금'])}</td><td class='num'>{_money(row['중복·겸업 조정액'])}</td><td class='num'>{_money(row['최종 적용자본금'])}</td><td>{row['적용연도']}</td><td>{escape(row['근거·비고'])}</td></tr>" for row in result["licenses"])
    trial="".join("<tr>"+"".join(f"<td class='{('num' if key in ['차변잔액','대변잔액','순금액'] else '')}'>{_money(row[key]) if key in ['차변잔액','대변잔액','순금액'] else escape(str(row.get(key,'')))}</td>" for key in TRIAL_COLUMNS)+"</tr>" for row in result["trial_rows"])
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>실질자본금 검토표</title><style>@page{{size:A4 landscape;margin:8mm}}body{{font-family:"Malgun Gothic",sans-serif;color:#173f59;margin:0}}button{{padding:7px 14px;margin-bottom:8px}}h1{{background:#173f59;color:#fff;padding:11px;text-align:center;font-size:19px;margin:0}}.identity{{display:flex;justify-content:space-between;background:#eaf3f7;padding:8px 13px;font-weight:700}}.cards{{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin:9px 0}}.card{{border:1px solid #b9cbd4;border-radius:6px;padding:7px;text-align:center}}.card strong{{display:block;color:#126bb0;margin-top:3px}}.result{{background:#fff2a8}}.result strong{{color:#d92c25}}h2{{font-size:13px;background:#087a4f;color:#fff;padding:5px 7px;margin:10px 0 0}}table{{border-collapse:collapse;width:100%;font-size:8px}}th,td{{border:1px solid #aab8bf;padding:3px;text-align:center}}th{{background:#eaf3f7}}td.num{{text-align:right;color:#126bb0}}@media print{{button{{display:none}}}}</style></head><body><button onclick="window.print()">인쇄 · PDF 저장</button><h1>{year}년 실질자본금 적격여부 검토표</h1><div class="identity"><span>{escape(company)}</span><span>{year}년</span><span>{result['status']}</span></div><div class="cards"><div class="card">회계상 자본<strong>{_money(result['accounting_equity'])}</strong></div><div class="card">부실자산<strong>{_money(result['bad_total'])}</strong></div><div class="card result">실질자본금<strong>{_money(result['real_capital'])}</strong></div><div class="card">기준자본금<strong>{_money(result['required'])}</strong></div><div class="card result">여유(부족)<strong>{_money(result['surplus'])}</strong></div></div><h2>실질자본금 계산근거</h2><table><tr><th>구분</th><th>항목</th><th>금액</th></tr>{summary}</table><h2>회사별 면허 기준자본금</h2><table><tr><th>면허명·업종</th><th>요구자본금</th><th>조정액</th><th>최종 적용액</th><th>적용연도</th><th>근거</th></tr>{licenses}</table><h2>합계잔액시산표 계정분류</h2><table><tr>{''.join(f'<th>{key}</th>' for key in TRIAL_COLUMNS)}</tr>{trial}</table></body></html>'''.encode("utf-8")

"""Editable monthly investment/performance/contract dashboard for nonlead projects."""
from datetime import date
from calendar import monthrange
from io import BytesIO
import json
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
import joint_store as db
import joint_workflow as flow
import joint_status as status
import joint_status_report as report
from joint_amounts import money_input,show as amount_table,total_input
from table_layout import aligned_config,format_excel

TITLE='당사투입비·기성·계약현황'
def done():
 from joint_app import saved
 saved()
def manual_form(c,p,m,month):
 rows=status.manual(c,p,m,month);lookup={r['id']:r for r in rows};base=f'js_manual_{p}_{m}_{month}_'
 if base+'pending' in st.session_state:st.session_state[base+'load']=st.session_state.pop(base+'pending')
 selected=st.selectbox('수동입력 내역 불러오기',[None]+list(lookup),format_func=lambda id:'새 수동입력' if id is None else lookup[id]['kind']+' / '+lookup[id]['category']+' / '+lookup[id]['note'],key=base+'load');v=lookup.get(selected,{});key=base+str(selected)+'_'+str(v.get('version',0))
 kind=st.radio('입력 구분',['영업비','안분제외'],index=0 if v.get('kind','안분제외')=='영업비' else 1,horizontal=True,key=key+'kind')
 category='영업비' if kind=='영업비' else st.selectbox('안분제외 비용구분',status.CATEGORIES,index=status.CATEGORIES.index(v.get('category','기타비용')),key=key+'category')
 amount=money_input('수동 입력 공급가액',v.get('amount','0'),key=key+'amount');note=st.text_input('사유·적요',v.get('note',''),key=key+'note')
 included=st.checkbox('금회 지급액에 이미 포함된 안분제외액',value=bool(v.get('included',False)),key=key+'included',disabled=kind=='영업비')
 if st.button('수동입력 수정 저장' if selected else '수동입력 등록',type='primary',key=key+'save'):
  id=status.save_manual(c,p,m,month,kind,category,amount,note,included,selected,v.get('version'));st.session_state[base+'pending']=id;done()
 if selected:
  check=st.checkbox('수동입력 삭제 확인',key=key+'check')
  if st.button('수동입력 삭제',disabled=not check,key=key+'delete'):status.set_manual_deleted(c,p,m,month,selected,v['version'],True);st.session_state[base+'pending']=None;done()
 with st.expander('월별 수동입력 목록·삭제 내역 복구'):
  amount_table([{'내역번호':r['id'],'구분':r['kind'],'비용구분':r['category'],'공급가액':r['amount'],'이미포함':'예' if r['included'] else '아니오','사유':r['note']} for r in rows],['공급가액'])
  removed=status.manual(c,p,m,month,True)
  if removed:
   lookup_removed={r['id']:r for r in removed};rid=st.selectbox('복구할 수동입력',list(lookup_removed),format_func=lambda id:lookup_removed[id]['note'],key=base+'restore')
   if st.button('수동입력 복구',key=base+'restore_btn'):status.set_manual_deleted(c,p,m,month,rid,lookup_removed[rid]['version'],False);st.session_state[base+'pending']=rid;done()

def view(c,p,m):
 st.subheader(TITLE);records=status.records(c,p,m['id']);lookup={r['id']:r for r in records};base=f'js_{p}_{m["id"]}_'
 if base+'pending' in st.session_state:st.session_state[base+'load']=st.session_state.pop(base+'pending')
 selected=st.selectbox('저장 현황 불러오기',[None]+list(lookup),format_func=lambda id:'새 현황 작성' if id is None else lookup[id]['month']+' / '+lookup[id]['data']['run_name']+' / '+lookup[id]['data']['as_of'],key=base+'load')
 record=lookup.get(selected,{});initial=record.get('data',{}).get('inputs',{});key=base+str(selected)+'_'+str(record.get('version',0))+'_'
 controls=st.columns(3);month=controls[0].text_input('기준월 (YYYY-MM)',record.get('month',date.today().strftime('%Y-%m')),key=key+'month',disabled=bool(selected));db.period(month);key=key+month+'_'
 end=date.fromisoformat(month+'-01').replace(day=monthrange(int(month[:4]),int(month[5:]))[1]);as_of=str(controls[1].date_input('기준일',date.fromisoformat(initial['as_of']) if initial.get('as_of') else end,key=key+'date'))
 runs=flow.runs(c,p,m['id']);run_map={r['id']:r for r in runs}
 if not runs:st.info('원가정산서에서 정산 건을 먼저 저장하세요. 영업비·안분제외는 아래에서 미리 등록할 수 있습니다.')
 run_id=controls[2].selectbox('연결 정산 건',list(run_map),index=list(run_map).index(record['run_id']) if record.get('run_id') in run_map else 0,format_func=lambda id:run_map[id]['name'],key=key+'run',disabled=bool(selected)) if runs else None
 docs=status.notices(c,p,month);doc_map={d['id']:d for d in docs};choices=[None]+list(doc_map)
 source_doc=st.selectbox('당사투입비 연동 원본',choices,index=choices.index(initial['source_doc']) if 'source_doc' in initial and initial['source_doc'] in choices else 1 if docs else 0,format_func=lambda id:'현재 당사투입비 (미발행 포함)' if id is None else '통보 발행본 '+doc_map[id]['number'],key=key+'source')
 st.caption('보증수수료·급여·기타비용은 관리법인 통보월 자료를 연동합니다. 영업비·안분제외는 별도 입력하며 금액은 공급가액입니다. 안분제외는 통보 대상액과 별도의 추가 금액이므로 같은 비용을 두 곳에 중복 입력하지 마세요.')
 left,right=st.columns([1.45,1])
 with left:
  st.markdown('### ① 당사투입비 내역');source=status.investment(c,p,m['id'],month,source_doc);manual=status.manual(c,p,m['id'],month);rows=[]
  for category in status.CATEGORIES:
   target=sum((db.num(r['amount']) for r in manual if r['kind']=='영업비'),db.num(0)) if category=='영업비' else db.num(source['totals'][category]);excluded=sum((db.num(r['amount']) for r in manual if r['kind']=='안분제외' and r['category']==category),db.num(0))
   rows.append({'구분':category,'안분대상액':str(target),'안분제외액':str(excluded),'계':str(target+excluded)})
  amount_table(rows,['안분대상액','안분제외액','계'])
  if source['unmapped']:
   with st.expander('자동 집계에서 제외된 다른 원장 구분 확인'):st.dataframe(pd.DataFrame(source['unmapped']).rename(columns={'id':'원장번호','account':'구분','amount':'공급가액'}),hide_index=True,use_container_width=True)
 with right:
  st.markdown('### 영업비·안분제외 수동입력');manual_form(c,p,m['id'],month)
 if run_id is None:return
 middle_left,middle_right=st.columns([1,1.6])
 with middle_left:
  st.markdown('### ② 수입·지출 현황');flow_preview=st.empty()
 with middle_right:
  st.markdown('### ③ 계약·실기성 현황');defaults=status.contract_defaults(c,p,m['id'],month);stored={int(r['company_id']):r for r in initial.get('contracts',[])}
  frame=pd.DataFrame([{'법인번호':r['company_id'],'법인':r['name'],'지분율(%)':float(db.num(r['share'])),'계약금액':float(db.num(stored.get(r['company_id'],r)['contract'])),'전회까지':float(db.num(stored.get(r['company_id'],r)['previous'])),'금회':float(db.num(stored.get(r['company_id'],r)['current']))} for r in defaults])
  frame=st.data_editor(frame,hide_index=True,use_container_width=True,disabled=['법인번호','법인','지분율(%)'],column_config=aligned_config(frame),key=key+'contracts')
  contract_rows=[dict(company_id=int(r['법인번호']),contract=r['계약금액'],previous=r['전회까지'],current=r['금회']) for r in frame.to_dict('records')]
  st.caption('등록 법인과 지분율은 자동 표시합니다. 계약금액은 지분율 배분값을 제안하며 직접 수정할 수 있습니다. 전회 기본값은 이전 월의 마지막 저장 누계입니다. 누계·기성률은 저장 미리보기에서 자동 계산합니다.')
 with st.expander('수입·지출 계산 및 지급 예정액 입력',expanded=True):
  cols=st.columns(2);income_scope=cols[0].selectbox('기성 수입 집계범위',['관리법인','전체법인'],index=0 if initial.get('income_scope','관리법인')=='관리법인' else 1,key=key+'scope');ratio=cols[1].selectbox('대비율 산식',status.RATIOS,index=status.RATIOS.index(initial.get('ratio','미설정')),key=key+'ratio')
  insurance_included=st.checkbox('선택 정산 보험료는 금회 지급대상액에 이미 포함',value=initial.get('insurance_in_payment',True),key=key+'insurance')
  st.caption('전회지출은 이전 월까지 실제 지급 공급가액입니다. 금회예정은 선택 정산 순공급가액(선택 건 기지급 포함)에 다른 당월 실지급을 더합니다. 보험료·안분제외는 미포함으로 확인한 금액만 추가합니다.')
  cols=st.columns(4);extra={}
  for column,(field,label) in zip(cols,[('prior_balance','전회 미지급·유보액 (부가세 포함)'),('investment_offset','추가 당사투입비 차감 (부가세 포함)'),('advance','추가 선금반제 (부가세 포함)')]):extra[field]=money_input(label,initial.get(field,'0'),key=key+field,where=column)
  approval=cols[3].checkbox('승인액 입력',value=initial.get('approved') not in [None,''],key=key+'approval_on');approved=money_input('승인액 (부가세 포함)',initial.get('approved') or '0',key=key+'approved',where=cols[3]) if approval else None
  st.caption('청구금액은 기존 원가정산서에서 이미 차감한 금액을 반영합니다. 여기에는 아직 반영되지 않은 추가 차감만 입력하세요. 지급 예정액 = 청구금액 − 선택 기지급액 + 전회미지급·유보액 − 추가 당사투입비 − 추가 선금반제.')
 values=dict(as_of=as_of,contracts=contract_rows,source_doc=source_doc,income_scope=income_scope,ratio=ratio,insurance_in_payment=insurance_included,approved=approved,**extra)
 data=None
 try:
  data=status.build(c,p,m['id'],run_id,month,values)
  cf=data['cash'];flow_rows=[{'구분':label,'입금 기준':int(db.num(cf[a])),'기성 기준':int(db.num(cf[b]))} for label,a,b in [('수입','income','earned'),('지출(전회까지)','previous','previous'),('지출(금회예정)','current','current'),('보험료·안분제외 추가','extra','extra'),('지출총계','spending','spending'),('수입−지출','cash_balance','earned_balance')]]
  flow_preview.dataframe(pd.DataFrame(flow_rows),hide_index=True,use_container_width=True,column_config=aligned_config(flow_rows))
  with middle_right:
   st.caption('누계·기성률 자동 계산')
   st.dataframe(pd.DataFrame([{'법인':r['name'],'누계':int(db.num(r['cumulative'])),'기성률':('—' if r['rate'] is None else f"{db.num(r['rate']):.2f}%")} for r in data['contracts']]),hide_index=True,use_container_width=True)
  st.markdown('### 원가정산서 하단 미리보기');components.html('<!doctype html><meta charset="utf-8">'+report.render(data),height=610,scrolling=True)
 except (ValueError,TypeError) as e:st.warning(str(e))
 cols=st.columns(3)
 if cols[0].button('현황 수정 저장' if selected else '현황 저장',type='primary',disabled=data is None,key=key+'save'):
  id=status.save(c,p,m['id'],run_id,month,values,selected,record.get('version'));st.session_state[base+'pending']=id;st.session_state['_jv_next_run']=[p,m['id'],run_id];done()
 if selected:
  check=cols[1].checkbox('현황 삭제 확인',key=key+'delete_confirm')
  if cols[2].button('현황 삭제',disabled=not check,key=key+'delete'):status.set_deleted(c,p,m['id'],selected,record['version'],True);st.session_state[base+'pending']=None;done()
 if data:
  st.download_button('현황 엑셀 다운로드',report.excel(data),file_name=f'당사투입비_기성_계약현황_{month}.xlsx',key=key+'xlsx')
 with st.expander('삭제 현황 복구'):
  removed=status.records(c,p,m['id'],deleted=True)
  if removed:
   lookup_removed={r['id']:r for r in removed};rid=st.selectbox('복구할 현황',list(lookup_removed),format_func=lambda id:lookup_removed[id]['month']+' / '+lookup_removed[id]['data']['run_name'],key=base+'restore')
   if st.button('현황 복구',key=base+'restore_btn'):status.set_deleted(c,p,m['id'],rid,lookup_removed[rid]['version'],False);st.session_state[base+'pending']=rid;done()

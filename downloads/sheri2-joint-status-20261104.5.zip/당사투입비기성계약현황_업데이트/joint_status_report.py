"""Compact three-panel nonlead overview followed by payment approval row."""
from html import escape
from joint_store import num

def esc(v):return escape(str(v if v is not None else ''))
def money(v):return '—' if v is None else f'{num(v):,.0f}'
def percent(v):return '—' if v is None else f'{num(v):,.2f}%'
def table(headers,rows,money_cols=()):
 return '<table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td'+(' class="number"' if i in money_cols else ' class="text"')+'>'+esc(money(x) if i in money_cols else x)+'</td>' for i,x in enumerate(row))+'</tr>' for row in rows)+'</tbody></table>'
CSS='''<style>.nonlead-status{margin-top:14px;border-top:2px solid #396653;padding-top:10px;break-inside:avoid}.nonlead-status h2{font-size:15px;margin:0 0 5px;color:#133e2b}.nonlead-status .status-panels{display:grid;grid-template-columns:1fr .95fr 1.55fr;gap:16px;align-items:start}.nonlead-status table{font-size:11px;table-layout:fixed}.nonlead-status td,.nonlead-status th{padding:4px 3px;white-space:normal;overflow-wrap:anywhere}.nonlead-status td.number{text-align:right;white-space:nowrap}.nonlead-status td.text{text-align:center}.nonlead-status th{background:#e8f4ed}.nonlead-status tr:last-child{font-weight:700;background:#f2f7f3}.nonlead-status .status-payment{margin-top:12px}.nonlead-status p{font-size:10px;margin:5px 0;color:#52675a}@media print{.nonlead-status table{font-size:7pt}.nonlead-status th,.nonlead-status td{padding:2px 1px}.nonlead-status h2{font-size:9pt}.nonlead-status p{font-size:6.5pt}.nonlead-status .status-panels{gap:8px}.nonlead-status{margin-top:7px;padding-top:6px}.nonlead-status .status-payment{margin-top:7px}}@media screen and (max-width:1000px){.nonlead-status .status-panels{grid-template-columns:1fr;gap:14px}}</style>'''
def render(s):
 costs=[[r['category'],r['target'],r['excluded'],r['total']] for r in s['investment_rows']]
 costs.append(['합계']+[sum((num(r[k]) for r in s['investment_rows']),num(0)) for k in ['target','excluded','total']])
 cash=s['cash'];flow=[['수입',cash['income'],cash['earned']],['지출(전회까지)',cash['previous'],cash['previous']],['지출(금회예정)',cash['current'],cash['current']],['보험료·안분제외 추가',cash['extra'],cash['extra']],['지출총계',cash['spending'],cash['spending']],['수입−지출',cash['cash_balance'],cash['earned_balance']]]
 contract=[[r['name'],str(r['share'])+'%',r['contract'],r['previous'],r['current'],r['cumulative'],percent(r['rate'])] for r in s['contracts']]
 totals={k:sum((num(r[k]) for r in s['contracts']),num(0)) for k in ['contract','previous','current','cumulative']}
 total_rate=str(totals['cumulative']/totals['contract']*100) if totals['contract'] else None
 contract.append(['전체분','100%',totals['contract'],totals['previous'],totals['current'],totals['cumulative'],percent(total_rate)])
 b=s['payment'];body=CSS+'<section class="nonlead-status"><div class="status-panels"><div><h2>■ 당사 투입비 내역</h2>'+table(['구분','안분대상액','안분제외액','계'],costs,[1,2,3])+'<p>기준월 '+esc(s['month'])+' · '+esc(s['source_label'])+'</p></div>'
 body+='<div><h2>■ 수입·지출 현황 (공급가액)</h2>'+table(['구분','입금 기준','기성 기준'],flow,[1,2])+table(['대비율',percent(cash['cash_ratio']),percent(cash['earned_ratio'])],[])+'<p>기성 집계: '+esc(s['income_scope'])+' / 대비율: '+esc(s['ratio'])+'</p></div>'
 body+='<div><h2>● 계약·실기성 현황</h2><p>기준일: '+esc(s['as_of'])+'</p>'+table(['법인','지분율','계약금액(공급가액)','전회까지','금회','누계','기성률'],contract,[2,3,4,5])+'</div></div>'
 payment=[[s['month']+' 원가배분',b['claim'],b['paid'],b['prior_balance'],num(b['investment_offset'])+num(b['advance']),b['planned'],b['approved']]]
 body+='<div class="status-payment">'+table(['구분','청구금액(부가세 포함)','기지급액','전회미지급·유보액','추가 당사투입비·선금반제','지급 예정액','승인액'],payment,[1,2,3,4,5,6])+'</div><p>금회예정은 선택 정산 순공급가액(선택 건 기지급 포함)과 다른 당월 실지급을 집계합니다. 보험료·안분제외는 이미 포함된 금액을 추가하지 않습니다. 추가 차감은 기존 청구금액에 반영되지 않은 금액만 입력합니다.</p></section>'
 return body

def excel(s):
 from io import BytesIO
 import pandas as pd
 from table_layout import format_excel
 def number(v):return None if v is None else int(num(v)) if num(v)==int(num(v)) else float(num(v))
 costs=[{'구분':r['category'],'안분대상액':number(r['target']),'안분제외액':number(r['excluded']),'계':number(r['total'])} for r in s['investment_rows']]
 contracts=[{'법인':r['name'],'지분율(%)':number(r['share']),'계약금액':number(r['contract']),'전회까지':number(r['previous']),'금회':number(r['current']),'누계':number(r['cumulative']),'기성률(%)':number(r['rate'])} for r in s['contracts']]
 cash=s['cash'];cash_rows=[{'구분':label,'입금 기준':number(cash[a]),'기성 기준':number(cash[b])} for label,a,b in [('수입','income','earned'),('지출(전회까지)','previous','previous'),('지출(금회예정)','current','current'),('보험료·안분제외 추가','extra','extra'),('지출총계','spending','spending'),('수입−지출','cash_balance','earned_balance')]]
 p=s['payment'];payment=[{'구분':s['month']+' 원가배분','청구금액':number(p['claim']),'기지급액':number(p['paid']),'전회미지급·유보액':number(p['prior_balance']),'추가 당사투입비':number(p['investment_offset']),'추가 선금반제':number(p['advance']),'지급예정액':number(p['planned']),'승인액':number(p['approved'])}]
 out=BytesIO()
 with pd.ExcelWriter(out,engine='openpyxl') as writer:
  for title,rows in [('당사투입비',costs),('계약실기성',contracts),('수입지출',cash_rows),('지급예정',payment)]:
   pd.DataFrame(rows).to_excel(writer,index=False,sheet_name=title);sheet=writer.sheets[title];format_excel(sheet);sheet.freeze_panes='B2'
   for col in sheet.columns:
    sheet.column_dimensions[col[0].column_letter].width=23
    for cell in col[1:]:
     if '(%)' in str(col[0].value):cell.number_format='0.00"%"'
     if cell.data_type=='f':cell.data_type='s'
 return out.getvalue()

@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
echo [Collect current Sheri2 program source]
echo Select start.bat from the program folder you currently use.
echo Databases, private data, uploads and passwords are NOT collected.
pause
call find_python.bat
if errorlevel 1 goto fail
%FINANCE_PYTHON% collect_current_source.py
if errorlevel 1 goto fail
echo Collection completed.
echo Upload sheri2-current-source-20261119.zip from the selected program folder.
pause
exit /b 0
:fail
echo Collection failed. Review the message above.
pause
exit /b 1

"""Collect program source without databases, credentials, uploads, or user data."""
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import sys

ROOT_NAMES={'README.md','requirements.txt','requirements.lock','app_upgrade.json'}
ROOT_SUFFIXES={'.py','.bat','.css','.html'}
SAFE_SUBDIRS={'assets','docs'}
SAFE_SUBDIR_SUFFIXES={'.md','.png','.jpg','.jpeg','.svg','.css','.html'}
MAX_FILE=8*1024*1024

def collect(target):
    target=Path(target).expanduser().resolve()
    if target.is_file():target=target.parent
    if not (target/'start.bat').is_file():raise ValueError('현재 사용 중인 프로그램 폴더의 start.bat을 선택하세요.')
    required=['multiuser_app.py','collaboration.py','app_navigation.py']
    missing=[name for name in required if not (target/name).is_file()]
    if missing:raise ValueError('필수 프로그램 파일이 없습니다: '+', '.join(missing))
    files=[]
    for path in target.iterdir():
        if path.is_file() and (path.name in ROOT_NAMES or path.suffix.lower() in ROOT_SUFFIXES):files.append(path)
    for dirname in SAFE_SUBDIRS:
        folder=target/dirname
        if folder.is_dir():
            files.extend(path for path in folder.rglob('*') if path.is_file() and path.suffix.lower() in SAFE_SUBDIR_SUFFIXES)
    files=sorted(set(files),key=lambda path:path.relative_to(target).as_posix())
    if not files:raise ValueError('수집할 프로그램 소스가 없습니다.')
    for path in files:
        if path.stat().st_size>MAX_FILE:raise ValueError('프로그램 파일 크기를 확인하세요: '+str(path.relative_to(target)))
    manifest={'collected_at':datetime.now().isoformat(timespec='seconds'),'source_version':'current-installed','files':{}}
    for path in files:
        relative=path.relative_to(target).as_posix();manifest['files'][relative]=hashlib.sha256(path.read_bytes()).hexdigest()
    output=target/'sheri2-current-source-20261119.zip'
    with ZipFile(output,'w',ZIP_DEFLATED) as archive:
        for path in files:archive.write(path,'sheri2_current_source/'+path.relative_to(target).as_posix())
        archive.writestr('sheri2_current_source/source_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
    print('현재 프로그램 전체 소스 수집 완료:',output)
    print('수집 파일 수:',len(files))
    print('DB, data, private, 업로드자료, 백업본, 비밀번호 및 사용자 입력자료는 포함하지 않았습니다.')
    print('생성된 sheri2-current-source-20261119.zip 파일을 대화창에 첨부해 주세요.')
    return output

def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
    finally:
        if window:window.destroy()

if __name__=='__main__':
    try:
        value=choose_target()
        if not value:raise ValueError('취소했습니다.')
        collect(value)
    except Exception as error:raise SystemExit('수집 실패: '+str(error))

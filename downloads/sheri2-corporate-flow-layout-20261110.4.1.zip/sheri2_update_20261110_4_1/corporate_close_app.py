"""Corporate close workspace centered on the approved Excel-shaped tax flow."""
from datetime import date
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
import corporate_close_store as db
import corporate_close_calc as calc
import corporate_close_import as ledger
import corporate_close_report as report
import corporate_progress as progress
import corporate_progress_report as progress_report

VERSION='2026.11.10.4'
PAGES=['법인세 계산 흐름표','원장 업로드·분류','공사수입·원가대비','세무조정 항목','소득구분계산서','세액 계산','유보잔액 관리','법인·업종 설정','결산 확정·출력']
VALUE_FIELDS=[('construction_revenue','공사수입'),('service_revenue','용역수입'),('progress_adjustment','진행률조정수입(예상)'),('cost','매출원가'),('sga','판매관리비'),('nonop_income','영업외수익'),('nonop_expense','영업외비용'),('prior_sales','전기매출'),('prior_progress','전기 진행률 수입조정'),('prior_unfinished','전기 미완성공사'),('current_unfinished','당기 미완성공사')]
REVIEW_FIELDS=[('entertainment_cost','접대비·경비'),('entertainment_sga','접대비·판관비'),('tax_cost','세금과공과·경비'),('tax_sga','세금과공과·판관비'),('interest','이자비용'),('donation','기부금'),('rnd','연구·인력개발비'),('tech_total','기술개발투자비')]
TAX_FIELDS=[('donation_excess','기부금한도초과'),('donation_carry_deduction','기부금이월손금'),('carry_loss','전기이월결손금'),('special_reduction','중소기업 특별세액감면'),('rd_prior','R&D 세액공제 전기이월'),('rd_current','R&D 세액공제 당기'),('undocumented_base','증빙미수취 대상금액'),('land_gain','토지 등 양도차익'),('prepaid_corp_interim','법인세 중간예납'),('prepaid_corp_withholding','법인세 원천납부'),('prepaid_local','지방소득세 기납부'),('accrued_tax','미지급법인세')]
NEXT_FIELDS=[('donation_carry_next','차기 기부금 이월잔액'),('carry_loss_next','차기 이월결손금'),('rd_carry_next','차기 R&D 세액공제 이월액')]
CSS='''<style>.cc-title{background:#087a4f;color:#fff;border-radius:7px;padding:8px 12px;font-weight:800;font-size:18px;margin:5px 0 8px}.cc-card{border:1px solid #b8d5c6;border-radius:8px;padding:10px;background:#fff;margin-bottom:8px}.cc-legend{font-size:12px;color:#60776c;text-align:right}.cc-blue{color:#2788e8;font-weight:700}.cc-red{color:#ef2424;font-weight:700}.cc-yellow{background:#fff600;padding:1px 5px;font-weight:700}</style>'''
def money(v):return 0 if v is None or v=='' or pd.isna(v) else int(v)
def tax_input_values(raw):
    tax=dict(raw or {});parts=calc.prepaid_tax(tax)
    tax.update(parts);return tax
def refresh():st.rerun()
def active_company(c,id):return next(x for x in db.companies(c) if x['id']==id)
def reserve_summary(c,x):
    out=[]
    for r in db.reserves(c,x['company_id']):
        y=next((z for z in db.reserve_years(c,r['id']) if z['year']==x['year']),None)
        if y:period={k:y[k] for k in ['beginning','increase','deduction','other','ending']}
        else:
            prior=[z for z in db.reserve_years(c,r['id']) if z['year']<x['year']]
            beginning=prior[-1]['ending'] if prior else r['initial_amount']
            period={'beginning':beginning,'increase':0,'deduction':0,'other':0,'ending':beginning}
        out.append({**r,**period})
    return out
def readiness(c,x,company,inc):
    missing=[]
    value_keys={k for k,_ in VALUE_FIELDS};tax_keys={k for k,_ in TAX_FIELDS}
    if not value_keys.issubset(x.get('values',{})):missing.append('손익계산서·예상금액 저장')
    if not tax_keys.issubset(x.get('tax',{})):missing.append('세액 계산 입력 저장')
    if inc['check']!=0:missing.append('업종별 매출액 합계 일치')
    blanks=[r for r in db.ledger_rows(c,x['id']) if r['kind'] in ['영업외수익','영업외비용'] and not r['classification']]
    if blanks:missing.append(f'영업외손익 적요 분류 {len(blanks)}건')
    projects=db.progress_projects(c,x['id'])
    if projects:
        ps=progress.summary(projects,x.get('progress',{}));values=x.get('values',{})
        if money(values.get('construction_revenue'))!=ps['table_revenue'] or money(values.get('progress_adjustment'))!=ps['expected_adjustment']:missing.append('공사수입·진행률조정 검산값 흐름표 반영')
    return missing
def computed(c,x,company):
    adjustments=db.adjustments(c,x['id']);lr=db.ledger_rows(c,x['id']);other_income=sum(r['amount'] for r in lr if r['kind']=='영업외수익' and r['classification']=='기타분');other_expense=sum(r['amount'] for r in lr if r['kind']=='영업외비용' and r['classification']=='기타분')
    values=x.get('values',{});f=calc.flow(values,adjustments);businesses=[{'name':name,'revenue':x.get('business_revenue',{}).get(name,0)} for name in company.get('businesses',['건설업'])]
    if len(businesses)==1 and not businesses[0]['revenue']:businesses[0]['revenue']=f['sales']
    inc=calc.income_division(values,adjustments,businesses,other_income,other_expense,x.get('losses',{}));tax=calc.tax_calculation(inc['current_income'],{**x.get('tax',{}),'pre_tax':f['pre_tax']});return adjustments,inc,tax,reserve_summary(c,x)
def save_payload(c,x,payload):db.save_case(c,x,payload,x['version']);refresh()

def entry_page(c,x,company):
    st.html('<div class="cc-title">법인세 계산 흐름표 입력</div>')
    st.caption('파란색 원장값과 빨간색 예상금액을 입력합니다. 합계·이익·법인세등은 자동계산합니다.')
    with st.form('cc_values'):
        values=dict(x.get('values',{}));review=dict(x.get('review',{}));tax=tax_input_values(x.get('tax',{}));business=dict(x.get('business_revenue',{}))
        st.markdown('**손익계산서·예상금액**');cols=st.columns(4)
        for i,(key,label) in enumerate(VALUE_FIELDS):values[key]=cols[i%4].number_input(label,value=money(values.get(key)),step=1000,format='%d',disabled=x['status']=='confirmed')
        st.markdown('**조정 전 검토사항**');cols=st.columns(4)
        for i,(key,label) in enumerate(REVIEW_FIELDS):review[key]=cols[i%4].number_input(label,value=money(review.get(key)),step=1000,format='%d',disabled=x['status']=='confirmed')
        st.markdown('**기납부세액**');cols=st.columns(4)
        tax['prepaid_corp_interim']=cols[0].number_input('법인세 중간예납',value=money(tax.get('prepaid_corp_interim')),step=1000,format='%d',disabled=x['status']=='confirmed')
        tax['prepaid_corp_withholding']=cols[1].number_input('법인세 원천납부',value=money(tax.get('prepaid_corp_withholding')),step=1000,format='%d',disabled=x['status']=='confirmed')
        tax['prepaid_local']=cols[2].number_input('지방소득세 기납부',value=money(tax.get('prepaid_local')),step=1000,format='%d',disabled=x['status']=='confirmed')
        tax['prepaid_corp']=tax['prepaid_corp_interim']+tax['prepaid_corp_withholding'];cols[3].metric('선납세금 합계',f'{tax["prepaid_corp"]+tax["prepaid_local"]:,}원')
        if len(company.get('businesses',[]))>1:
            st.markdown('**겸업 업종별 매출액**');cols=st.columns(min(4,len(company['businesses'])))
            for i,name in enumerate(company['businesses']):business[name]=cols[i%len(cols)].number_input(name+' 매출액',value=money(business.get(name)),step=1000,format='%d',disabled=x['status']=='confirmed')
            st.caption('합계가 매출계와 일치해야 소득구분계산을 확정할 수 있습니다.')
        disposal=st.date_input('처분확정일',value=date.fromisoformat(x.get('disposal_date',f'{x["year"]+1}-03-31')),disabled=x['status']=='confirmed')
        submit=st.form_submit_button('입력값 저장',type='primary',disabled=x['status']=='confirmed')
    if submit:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload.update(values=values,review=review,tax=tax,business_revenue=business,disposal_date=str(disposal));save_payload(c,x,payload)
    adjustments,inc,tax_result,reserves=computed(c,x,company);preview=report.html(company['name'],x['year'],x,adjustments,inc,tax_result,reserves)
    components.html(preview,height=1080,scrolling=True)

def adjustment_page(c,x):
    st.html('<div class="cc-title">과목별 세무조정 내역</div>')
    active=db.adjustments(c,x['id']);deleted=[r for r in db.adjustments(c,x['id'],True) if r['deleted']]
    frame=pd.DataFrame([{'ID':r['id'],'구분':'익금산입·손금불산입' if r['side']=='add' else '손금산입·익금불산입','과목':r['name'],'금액':r['amount'],'반영':r['target'],'원가금액':r['amount'] if r['target']=='원가' else r['cost_amount'] if r['target']=='공통' else 0,'판관비금액':r['amount']-(r['amount'] if r['target']=='원가' else r['cost_amount'] if r['target']=='공통' else 0)} for r in active])
    st.dataframe(frame,hide_index=True,use_container_width=True)
    ids=[None]+[r['id'] for r in active if not r['source_key'].startswith('reserve:')];selected=st.selectbox('등록·수정할 항목',['새 항목']+ids[1:],format_func=lambda z:'새 항목' if z=='새 항목' else next(r['name'] for r in active if r['id']==z));row=next((r for r in active if r['id']==selected),None)
    with st.form('cc_adjust'):
        side=st.selectbox('조정 구분',['add','deduct'],index=['add','deduct'].index(row['side']) if row else 0,format_func=lambda z:'익금산입 및 손금불산입' if z=='add' else '손금산입 및 익금불산입')
        a,b,c1=st.columns(3);name=a.text_input('조정 과목',value=row['name'] if row else '');amount=b.number_input('작업자 입력금액',value=money(row['amount'] if row else 0),step=1000,format='%d');target=c1.selectbox('반영 구분',['원가','판관비','공통'],index=['원가','판관비','공통'].index(row['target']) if row else 1)
        cost=st.number_input('공통인 경우 원가 배분액',value=money(row['cost_amount'] if row else 0),step=1000,format='%d',disabled=target!='공통');note=st.text_input('근거·메모',value=row['note'] if row else '')
        save=st.form_submit_button('조정항목 저장',type='primary',disabled=x['status']=='confirmed')
    if save:
        db.save_adjustment(c,x,side,name,amount,target,cost,note,row['id'] if row else None,row['version'] if row else None);refresh()
    if row:
        reason=st.text_input('삭제 사유',key='cc_adj_delete_reason');ack=st.checkbox('선택 조정항목 삭제 영향을 확인했습니다.',key='cc_adj_delete_ack')
        if st.button('선택항목 삭제',disabled=x['status']=='confirmed' or not ack):db.delete_adjustment(c,x,row['id'],row['version'],reason);refresh()
    if deleted:
        with st.expander('삭제자료 복구'):
            did=st.selectbox('삭제 조정항목',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z))
            if st.button('조정항목 복구'):r=next(r for r in deleted if r['id']==did);db.restore_adjustment(c,x,did,r['version']);refresh()

def import_page(c,x):
    st.html('<div class="cc-title">계정별 원장 업로드·소득구분</div>');kind=st.selectbox('원장 종류',['합계잔액·계정별원장','영업외수익','영업외비용']);up=st.file_uploader('XLSX 또는 CSV 원장',type=['xlsx','csv'])
    parsed=None
    if up:
        try:parsed=ledger.parse(up.name,up.getvalue());st.dataframe(pd.DataFrame(parsed[:200]),hide_index=True,use_container_width=True);st.caption(f'전체 {len(parsed):,}행 중 최대 200행 미리보기')
        except ValueError as e:st.error(str(e))
    if st.button('미리보기 자료 등록',disabled=not parsed or x['status']=='confirmed'):
        db.save_import(c,x,kind,up.name,up.getvalue(),parsed);refresh()
    imports=db.imports(c,x['id']);active=[r for r in imports if not r['deleted']]
    if active:
        st.subheader('등록 원장');st.dataframe(active,hide_index=True,use_container_width=True)
        iid=st.selectbox('관리할 원장',[r['id'] for r in active],format_func=lambda z:next(r['kind']+' · '+r['name'] for r in active if r['id']==z))
        if st.button('선택 원장 삭제',disabled=x['status']=='confirmed'):db.delete_import(c,x,iid);refresh()
    allrows=db.ledger_rows(c,x['id'])
    if allrows:
        summary=ledger.aggregate(allrows)
        if st.button('원장 집계금액을 파란색 항목에 적용',disabled=x['status']=='confirmed'):
            payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};values=dict(payload.get('values',{}));tax=dict(payload.get('tax',{}))
            for k in ['construction_revenue','service_revenue','cost','sga','nonop_income','nonop_expense']:
                if summary.get(k):values[k]=summary[k]
            for k in ['prepaid_corp_interim','prepaid_corp_withholding','prepaid_local']:
                if summary.get(k):tax[k]=summary[k]
            tax['prepaid_corp']=money(tax.get('prepaid_corp_interim'))+money(tax.get('prepaid_corp_withholding'))
            payload.update(values=values,tax=tax);save_payload(c,x,payload)
        subset=[r for r in allrows if r['kind'] in ['영업외수익','영업외비용']]
        if subset:
            st.subheader('영업외손익 적요 분류');frame=pd.DataFrame([{'ID':r['id'],'구분':r['kind'],'계정과목':r['account'],'적요':r['description'],'금액':r['amount'],'소득구분':r['classification']} for r in subset]);edited=st.data_editor(frame,hide_index=True,use_container_width=True,disabled=['ID','구분','계정과목','적요','금액'],column_config={'소득구분':st.column_config.SelectboxColumn(options=['','감면분','기타분'])})
            if st.button('소득구분 저장',disabled=x['status']=='confirmed'):db.classify_rows(c,x,[(int(r['ID']),r['소득구분'],'') for _,r in edited.iterrows()]);refresh()
    deleted=[r for r in imports if r['deleted']]
    if deleted:
        with st.expander('삭제 원장 복구'):
            iid=st.selectbox('삭제 원장',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z),key='cc_restore_import')
            if st.button('원장 복구'):db.restore_import(c,x,iid);refresh()

def progress_page(c,x,company):
    st.html('<div class="cc-title">공사수입·원가대비 및 진행률 조정 검산</div>')
    st.caption('현장별 공사수입·원가를 집계하고 예상원가율에 따른 진행률 조정액을 법인세 계산 흐름표와 검산합니다.')
    up=st.file_uploader('공사수입·원가대비표 Excel',type=['xlsx'],key='cc_progress_upload');parsed=None;sheet=''
    if up:
        try:
            choices=progress.sheet_candidates(up.getvalue(),x['year'],company['name'])
            sheet=st.selectbox('가져올 법인·연도 시트',choices) if choices else ''
            if sheet:sheet,parsed=progress.parse(up.getvalue(),x['year'],company['name'],sheet);st.success(f'{sheet} · 현장 {len(parsed):,}건을 확인했습니다.');st.dataframe(pd.DataFrame(parsed[:20]),hide_index=True,use_container_width=True)
        except ValueError as e:st.error(str(e))
    if st.button('미리보기 현장자료 등록·갱신',type='primary',disabled=not parsed or x['status']=='confirmed'):
        try:db.save_progress_import(c,x,up.name,sheet,up.getvalue(),parsed);refresh()
        except ValueError as e:st.error(str(e))
    rows=db.progress_projects(c,x['id']);extra=dict(x.get('progress',{}));s=progress.summary(rows,extra);flow_revenue=money(x.get('values',{}).get('construction_revenue'));ledger_revenue=money(extra.get('ledger_construction_revenue',flow_revenue));flow_adjustment=money(x.get('values',{}).get('progress_adjustment'))
    tabs=st.tabs(['현장별 진행률 검산','원가율·조정값 관리','업로드·변경 이력','A4 출력·Excel'])
    with tabs[0]:
        cards=st.columns(5)
        for col,label,value in zip(cards,['원장 공사수입','현장표 당기 공사수입','공사수입 검산차이','진행률조정 예상액','흐름표 반영 차이'],[ledger_revenue,s['table_revenue'],ledger_revenue-s['table_revenue'],s['expected_adjustment'],flow_adjustment-s['expected_adjustment']]):col.metric(label,f'{value:,}원')
        view=[]
        for r in rows:
            z=progress.recalculate(r);view.append({'ID':r['id'],'검산':'예상원가율 확인' if not z['expected_cost_rate'] and z['status'] not in ['준공','준 공','준        공'] else '정상','발주처':z['client'],'공사명':z['project'],'계약공급가액':z['contract'],'전기수입':z['prior_revenue'],'당기수입':z['current_revenue'],'누계수입':z['total_revenue'],'전기원가':z['prior_cost'],'당기원가':z['current_cost'],'누계원가':z['total_cost'],'예상원가율(%)':round(z['expected_cost_rate']*100,4),'예상누적수입':z['expected_revenue'],'진행률조정':z['calculated_adjustment'],'상태':z['status']})
        st.dataframe(pd.DataFrame(view),hide_index=True,use_container_width=True,column_config={k:st.column_config.NumberColumn(format='%,d') for k in ['계약공급가액','전기수입','당기수입','누계수입','전기원가','당기원가','누계원가','예상누적수입','진행률조정']})
        if not rows:st.info('공사수입·원가대비표 Excel을 업로드하세요.')
        elif s['missing_rates']:st.warning(f'이월공사 중 예상원가율이 없는 현장 {s["missing_rates"]:,}건을 확인하세요.')
        if rows and st.button('검산값을 흐름표 공사수입·진행률조정(예상)에 반영',type='primary',disabled=x['status']=='confirmed'):
            payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};values=dict(payload.get('values',{}));extra.setdefault('ledger_construction_revenue',flow_revenue);values['construction_revenue']=s['table_revenue'];values['progress_adjustment']=s['expected_adjustment'];payload.update(values=values,progress=extra);save_payload(c,x,payload)
    with tabs[1]:
        if rows:
            edit=pd.DataFrame([{'ID':r['id'],'버전':r['version'],'발주처':r['client'],'공사명':r['project'],'착공일':r['start'],'준공일':r['end'],'계약공급가액':r['contract'],'전기수입':r['prior_revenue'],'당기수입':r['current_revenue'],'전기원가':r['prior_cost'],'당기원가':r['current_cost'],'예상원가율(%)':round(float(r['expected_cost_rate'])*100,5),'공종':r['trade'],'상태':r['status'],'전기진행률조정':r['prior_adjustment'],'가져온당기조정':r['current_adjustment'],'전기미완성':r['prior_unfinished'],'당기미완성':r['current_unfinished'],'비고':r['note']} for r in rows])
            edited=st.data_editor(edit,hide_index=True,use_container_width=True,disabled=['ID','버전'],column_config={k:st.column_config.NumberColumn(format='%,d') for k in ['계약공급가액','전기수입','당기수입','전기원가','당기원가','전기진행률조정','가져온당기조정','전기미완성','당기미완성']})
            if st.button('현장별 수정값 저장',disabled=x['status']=='confirmed'):
                for _,r in edited.iterrows():
                    vals={'client':r['발주처'],'project':r['공사명'],'start':r['착공일'],'end':r['준공일'],'contract':money(r['계약공급가액']),'prior_revenue':money(r['전기수입']),'current_revenue':money(r['당기수입']),'prior_cost':money(r['전기원가']),'current_cost':money(r['당기원가']),'expected_cost_rate':float(r['예상원가율(%)'] or 0)/100,'trade':r['공종'],'status':r['상태'],'prior_adjustment':money(r['전기진행률조정']),'current_adjustment':money(r['가져온당기조정']),'prior_unfinished':money(r['전기미완성']),'current_unfinished':money(r['당기미완성']),'note':r['비고']}
                    db.save_progress_project(c,x,int(r['ID']),int(r['버전']),vals)
                refresh()
            st.markdown('**현장 삭제**');pid=st.selectbox('삭제할 현장',[r['id'] for r in rows],format_func=lambda z:next(r['project'] for r in rows if r['id']==z));reason=st.text_input('현장 삭제 사유');ack=st.checkbox('현장 삭제가 합계와 흐름표 검산에 미치는 영향을 확인했습니다.')
            if st.button('선택 현장 삭제',disabled=x['status']=='confirmed' or not ack):r=next(r for r in rows if r['id']==pid);db.delete_progress_project(c,x,pid,r['version'],reason);refresh()
        with st.form('cc_progress_extra'):
            a,b=st.columns(2);extra['vat_adjustment']=a.number_input('VAT 신고 진행률 조정',value=money(extra.get('vat_adjustment')),step=1000,format='%d',disabled=x['status']=='confirmed');extra['manual_adjustment']=b.number_input('기타 수동 조정',value=money(extra.get('manual_adjustment')),step=1000,format='%d',disabled=x['status']=='confirmed');extra['note']=st.text_input('조정 근거·메모',value=extra.get('note',''),disabled=x['status']=='confirmed');save_extra=st.form_submit_button('조정값 저장',disabled=x['status']=='confirmed')
        if save_extra:
            payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['progress']=extra;save_payload(c,x,payload)
        deleted=[r for r in db.progress_projects(c,x['id'],True) if r['deleted']]
        if deleted:
            with st.expander('삭제 현장 복구'):
                pid=st.selectbox('복구할 현장',[r['id'] for r in deleted],format_func=lambda z:next(r['project'] for r in deleted if r['id']==z),key='cc_progress_restore_project')
                if st.button('선택 현장 복구',disabled=x['status']=='confirmed'):r=next(r for r in deleted if r['id']==pid);db.restore_progress_project(c,x,pid,r['version']);refresh()
    with tabs[2]:
        imports=db.progress_imports(c,x['id'],True);st.dataframe(pd.DataFrame(imports),hide_index=True,use_container_width=True)
        active=[r for r in imports if not r['deleted']];deleted=[r for r in imports if r['deleted']]
        if active:
            iid=st.selectbox('삭제할 업로드',[r['id'] for r in active],format_func=lambda z:next(r['name']+' · '+r['sheet_name'] for r in active if r['id']==z))
            if st.button('업로드 자료 삭제',disabled=x['status']=='confirmed'):db.delete_progress_import(c,x,iid);refresh()
        if deleted:
            iid=st.selectbox('복구할 업로드',[r['id'] for r in deleted],format_func=lambda z:next(r['name']+' · '+r['sheet_name'] for r in deleted if r['id']==z),key='cc_progress_restore_import')
            if st.button('업로드 자료 복구',disabled=x['status']=='confirmed'):db.restore_progress_import(c,x,iid);refresh()
    with tabs[3]:
        html=progress_report.html(company['name'],x['year'],rows,flow_revenue,extra);xlsx=progress_report.workbook(company['name'],x['year'],rows,flow_revenue,extra)
        a,b=st.columns(2);a.download_button('A4 인쇄 HTML',html,file_name=f'{x["year"]}_{company["name"]}_공사수입원가대비.html',mime='text/html',use_container_width=True);b.download_button('검산 Excel',xlsx,file_name=f'{x["year"]}_{company["name"]}_공사수입원가대비.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)
        components.html(html,height=800,scrolling=True)

def income_page(c,x,company):
    adjustments,inc,tax,reserves=computed(c,x,company);st.html('<div class="cc-title">소득구분계산서</div>');st.caption('한 업종은 전액 귀속하며, 겸업은 업종별 매출비율로 공통금액을 자동 배분합니다. 영업외손익 기타분은 원장 적요 분류를 사용합니다.')
    metrics=[('매출액','revenue'),('매출원가','cost'),('판매관리비','sga'),('영업외수익','nonop_income'),('영업외비용','nonop_expense'),('각사업연도소득','current_income'),('이월결손금','loss'),('과세표준','taxable')]
    view=[]
    for label,key in metrics:
        row={'구분':label,'전체 합계':sum(money(r[key]) for r in inc['rows'])}
        row.update({r['name']:money(r[key]) for r in inc['rows']});view.append(row)
    frame=pd.DataFrame(view);money_cols=[c for c in frame.columns if c!='구분']
    styled=frame.style.format({c:'{:,.0f}' for c in money_cols}).set_properties(subset=money_cols,**{'text-align':'right'}).set_properties(subset=['구분'],**{'text-align':'center'}).apply(lambda r:['background-color:#fff600;font-weight:700' if r['구분'] in ['각사업연도소득','과세표준'] else 'background-color:#eef6ff' if r['구분']=='이월결손금' else '' for _ in r],axis=1)
    st.dataframe(styled,hide_index=True,use_container_width=True)
    if inc['check']:st.error(f'업종별 매출액 합계와 매출계가 {inc["check"]:,}원 차이납니다.')
    with st.form('cc_losses'):
        losses=dict(x.get('losses',{}));cols=st.columns(min(4,len(inc['rows'])))
        for i,r in enumerate(inc['rows']):losses[r['name']]=cols[i%len(cols)].number_input(r['name']+' 이월결손금',value=money(losses.get(r['name'])),step=1000,format='%d')
        save=st.form_submit_button('이월결손금 저장',disabled=x['status']=='confirmed')
    if save:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['losses']=losses;save_payload(c,x,payload)

def reserve_page(c,x):
    st.html('<div class="cc-title">유보잔액 관리대장</div>');rs=db.reserves(c,x['company_id']);deleted=[r for r in db.reserves(c,x['company_id'],True) if r['deleted']];summary=reserve_summary(c,x)
    st.dataframe(pd.DataFrame([{'ID':r['id'],'관리항목':r['name'],'발생연도':r['origin_year'],'최초유보액':r['initial_amount'],'기초유보액':r['beginning'],'당기증가액':r['increase'],'당기추인액':r['deduction'],'기말유보잔액':r['ending'],'반영':r['target']} for r in summary]),hide_index=True,use_container_width=True)
    selected=st.selectbox('등록·수정할 유보항목',['새 항목']+[r['id'] for r in rs],format_func=lambda z:'새 항목' if z=='새 항목' else next(r['name'] for r in rs if r['id']==z));r=next((r for r in rs if r['id']==selected),None)
    with st.form('cc_reserve'):
        a,b,c1=st.columns(3);name=a.text_input('관리항목',value=r['name'] if r else '');origin=b.number_input('발생연도',2000,2100,value=r['origin_year'] if r else x['year']);initial=c1.number_input('최초 유보액',value=money(r['initial_amount'] if r else 0),step=1000,format='%d');target=st.selectbox('원가·판관비 반영',['원가','판관비'],index=['원가','판관비'].index(r['target']) if r else 1);note=st.text_input('기간·추인계획·근거',value=r['note'] if r else '');save=st.form_submit_button('유보항목 저장',type='primary',disabled=x['status']=='confirmed')
    if save:db.save_reserve(c,x,name,origin,initial,target,note,r['id'] if r else None,r['version'] if r else None);refresh()
    if r:
        current=next((z for z in db.reserve_years(c,r['id']) if z['year']==x['year']),None)
        with st.form('cc_reserve_year'):
            cols=st.columns(3);increase=cols[0].number_input('당기 유보 증가액',value=money(current['increase'] if current else 0),step=1000,format='%d');deduction=cols[1].number_input('당기 손금추인액',value=money(current['deduction'] if current else 0),step=1000,format='%d');other=cols[2].number_input('기타 조정액',value=money(current['other'] if current else 0),step=1000,format='%d');saveyear=st.form_submit_button('당해연도 유보잔액 저장·세무조정 반영',disabled=x['status']=='confirmed')
        if saveyear:db.save_reserve_year(c,x,r['id'],x['year'],increase,deduction,other);refresh()
        st.dataframe(pd.DataFrame(db.reserve_years(c,r['id'])),hide_index=True,use_container_width=True)
        reason=st.text_input('유보항목 삭제 사유');ack=st.checkbox('이월·세무조정 영향을 확인했습니다.')
        if st.button('유보항목 삭제',disabled=x['status']=='confirmed' or not ack):db.delete_reserve(c,x,r['id'],r['version'],reason);refresh()
    if deleted:
        with st.expander('삭제자료 복구'):
            rid=st.selectbox('삭제 유보항목',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z));rr=next(r for r in deleted if r['id']==rid)
            if st.button('유보항목 복구'):db.restore_reserve(c,x,rid,rr['version']);refresh()

def tax_page(c,x,company):
    adjustments,inc,result,reserves=computed(c,x,company);st.html('<div class="cc-title">세액 계산 입력·결과</div>')
    prior=db.prior_case(c,x['company_id'],x['year'])
    if prior and st.button(f'{x["year"]-1}년 차기 이월자료 불러오기',disabled=x['status']=='confirmed'):
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};tax=dict(payload.get('tax',{}));pt=prior.get('tax',{})
        tax.update(donation_excess=pt.get('donation_carry_next',0),carry_loss=pt.get('carry_loss_next',0),rd_prior=pt.get('rd_carry_next',0));payload['tax']=tax;save_payload(c,x,payload)
    elif not prior:st.caption('전년도 결산자료가 없어 이월자료를 수동 입력합니다.')
    with st.form('cc_tax'):
        tax=tax_input_values(x.get('tax',{}));cols=st.columns(4)
        for i,(key,label) in enumerate(TAX_FIELDS):tax[key]=cols[i%4].number_input(label,value=money(tax.get(key)),step=1000,format='%d',disabled=x['status']=='confirmed')
        tax['prepaid_corp']=tax['prepaid_corp_interim']+tax['prepaid_corp_withholding']
        st.markdown('**차기연도 이월자료**');cols=st.columns(3)
        for i,(key,label) in enumerate(NEXT_FIELDS):tax[key]=cols[i].number_input(label,value=money(tax.get(key)),step=1000,format='%d',disabled=x['status']=='confirmed')
        tax['land_rate']=st.number_input('토지 등 양도소득 세율(%)',value=float(tax.get('land_rate',20)),step=.1,disabled=x['status']=='confirmed');save=st.form_submit_button('세액 계산 입력 저장',type='primary',disabled=x['status']=='confirmed')
    if save:
        payload={k:v for k,v in x.items() if k not in ['id','company_id','year','status','version']};payload['tax']=tax;save_payload(c,x,payload)
    st.dataframe(pd.DataFrame([{'항목':k,'금액':v} for k,v in [('각사업연도소득',result['current_income']),('과세표준',result['taxable']),('산출세액',result['output_tax']),('공제·감면',result['credits']),('가산세',result['penalty']),('법인세 총부담',result['corp_total']),('법인세 납부·환급',result['corp_payable']),('지방소득세 총부담',result['local_total']),('지방소득세 납부·환급',result['local_payable']),('법인세등',result['tax_expense'])]]),hide_index=True,use_container_width=True)

def company_page(c):
    st.html('<div class="cc-title">법인·겸업 업종 설정</div>');allc=db.companies(c);selected=st.selectbox('등록·수정할 법인',['새 법인']+[r['id'] for r in allc],format_func=lambda z:'새 법인' if z=='새 법인' else next(r['name'] for r in allc if r['id']==z));r=next((r for r in allc if r['id']==selected),None)
    with st.form('cc_company'):
        name=st.text_input('법인명',value=r['name'] if r else '');business=st.text_input('업종명(쉼표로 구분)',value=', '.join(r.get('businesses',[])) if r else '건설업');save=st.form_submit_button('법인·업종 저장',type='primary')
    if save:db.save_company(c,name,business.split(','),r['id'] if r else None,r['version'] if r else None);refresh()
    if r:
        reason=st.text_input('법인 삭제 사유');ack=st.checkbox('법인 삭제 영향을 확인했습니다.')
        if st.button('법인 삭제',disabled=not ack):db.delete_company(c,r['id'],r['version'],reason);refresh()
    deleted=[r for r in db.companies(c,True) if r['deleted']]
    if deleted:
        rid=st.selectbox('삭제 법인',[r['id'] for r in deleted],format_func=lambda z:next(r['name'] for r in deleted if r['id']==z))
        if st.button('법인 복구'):r=next(r for r in deleted if r['id']==rid);db.restore_company(c,rid,r['version']);refresh()

def output_page(c,x,company):
    adjustments,inc,tax,reserves=computed(c,x,company);html=report.html(company['name'],x['year'],x,adjustments,inc,tax,reserves);xlsx=report.workbook(company['name'],x['year'],x,adjustments,inc,tax,reserves)
    st.html('<div class="cc-title">결산 확정·출력</div>');st.download_button('법인결산 전체 인쇄 HTML',html,file_name=f'{x["year"]}_{company["name"]}_법인결산.html',mime='text/html');st.download_button('법인결산 전체 Excel',xlsx,file_name=f'{x["year"]}_{company["name"]}_법인결산.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    if x['status']=='confirmed':
        reason=st.text_input('확정 해제 사유');ack=st.checkbox('확정 해제 후 자료가 다시 수정 가능해짐을 확인했습니다.')
        if st.button('결산 확정 해제',disabled=not ack):db.reopen(c,x,reason);refresh()
    else:
        missing=readiness(c,x,company,inc);ready=not missing;ack=st.checkbox('소득구분 검산과 세액 계산 결과를 확인했습니다.')
        if st.button('법인결산 확정',type='primary',disabled=not ready or not ack):db.confirm(c,x);refresh()
        if not ready:st.error('확정 전 완료할 사항: '+', '.join(missing))

def render(user):
    st.html(CSS);c=db.connect();companies=db.companies(c)
    if not companies:st.warning('법인·업종 설정에서 법인을 먼저 등록하세요.');company_page(c);return
    top=st.columns([1.4,.7,.7]);cid=top[0].selectbox('결산법인',[r['id'] for r in companies],format_func=lambda z:next(r['name'] for r in companies if r['id']==z),key='cc_company');year=top[1].number_input('결산연도',2015,2100,value=date.today().year-1,key='cc_year');company=active_company(c,cid);x=db.case(c,cid,year)
    top[2].metric('상태','확정' if x['status']=='confirmed' else '작성 중');st.caption(f'법인결산 · 버전 {VERSION} · 파란색은 원장·작업자 입력, 빨간색은 자동계산, 노란색은 주요 자동결과입니다.')
    with st.sidebar:page=st.radio('법인결산 메뉴',PAGES,key='cc_page')
    if page=='법인세 계산 흐름표':entry_page(c,x,company)
    elif page=='원장 업로드·분류':import_page(c,x)
    elif page=='공사수입·원가대비':progress_page(c,x,company)
    elif page=='세무조정 항목':adjustment_page(c,x)
    elif page=='소득구분계산서':income_page(c,x,company)
    elif page=='세액 계산':tax_page(c,x,company)
    elif page=='유보잔액 관리':reserve_page(c,x)
    elif page=='법인·업종 설정':company_page(c)
    elif page=='결산 확정·출력':output_page(c,x,company)

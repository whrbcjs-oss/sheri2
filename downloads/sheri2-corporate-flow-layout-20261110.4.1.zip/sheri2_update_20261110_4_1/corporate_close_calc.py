"""Deterministic corporate-close calculations; no persistence or UI state."""
from decimal import Decimal, ROUND_HALF_UP

ZERO=Decimal('0')
def dec(v):
    if v in (None,''):return ZERO
    return Decimal(str(v).replace(',',''))
def won(v):return int(dec(v).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def nonnegative(v,label='금액'):
    x=dec(v)
    if x<0:raise ValueError(label+'은 0 이상이어야 합니다.')
    return x

def adjustment_totals(rows):
    out={'add_amount':ZERO,'add_cost':ZERO,'add_sga':ZERO,'deduct_amount':ZERO,'deduct_cost':ZERO,'deduct_sga':ZERO}
    for r in rows:
        if r.get('deleted'):continue
        side=r['side'];amount=dec(r.get('amount'));target=r.get('target','판관비')
        out[side+'_amount']+=amount
        if target=='원가':out[side+'_cost']+=amount
        elif target=='판관비':out[side+'_sga']+=amount
        else:
            cost=dec(r.get('cost_amount'))
            if cost<0 or cost>amount:raise ValueError(r['name']+' 원가 배분액을 확인하세요.')
            out[side+'_cost']+=cost;out[side+'_sga']+=amount-cost
    return {k:won(v) for k,v in out.items()}

def flow(values,adjustments=()):
    v={k:won(values.get(k,0)) for k in ['construction_revenue','service_revenue','progress_adjustment','cost','sga','nonop_income','nonop_expense','prior_sales','prior_progress','prior_unfinished','current_unfinished']}
    a=adjustment_totals(adjustments)
    v['sales']=v['construction_revenue']+v['service_revenue']+v['progress_adjustment']
    v['gross_profit']=v['sales']-v['cost']
    v['operating_profit']=v['gross_profit']-v['sga']
    v['pre_tax']=v['operating_profit']+v['nonop_income']-v['nonop_expense']
    v['sales_growth']=float(dec(v['sales']-v['prior_sales'])/dec(v['prior_sales'])*100) if v['prior_sales'] else 0
    v['pre_tax_rate']=float(dec(v['pre_tax'])/dec(v['sales'])*100) if v['sales'] else 0
    v['cost_rate']=float(dec(v['cost'])/dec(v['construction_revenue'])*100) if v['construction_revenue'] else 0
    v.update(a);return v

def income_division(values,adjustments,businesses,other_income=0,other_expense=0,losses=None):
    f=flow(values,adjustments);bs=[]
    supplied=sum((dec(b.get('revenue')) for b in businesses),ZERO)
    if not businesses:businesses=[{'name':'건설업','revenue':f['sales']}];supplied=dec(f['sales'])
    if supplied==0 and f['sales']:businesses=[dict(businesses[0],revenue=f['sales'])]+[dict(b,revenue=0) for b in businesses[1:]];supplied=dec(f['sales'])
    oi=min(nonnegative(other_income,'영업외수익 기타분'),nonnegative(f['nonop_income'],'영업외수익'))
    oe=min(nonnegative(other_expense,'영업외비용 기타분'),nonnegative(f['nonop_expense'],'영업외비용'))
    alloc_income=dec(f['nonop_income'])-oi;alloc_expense=dec(f['nonop_expense'])-oe
    for b in businesses:
        revenue=dec(b.get('revenue'));ratio=revenue/supplied if supplied else ZERO
        cost=dec(f['cost'])*ratio;sga=dec(f['sga'])*ratio;income=alloc_income*ratio;expense=alloc_expense*ratio
        current=revenue-cost-sga+income-expense;loss=dec((losses or {}).get(b['name'],0));taxable=max(ZERO,current-loss)
        bs.append({'name':b['name'],'revenue':won(revenue),'ratio':float(ratio*100),'cost':won(cost),'sga':won(sga),'nonop_income':won(income),'nonop_expense':won(expense),'current_income':won(current),'loss':won(loss),'taxable':won(taxable)})
    other_current=oi-oe;other_loss=dec((losses or {}).get('기타분',0))
    bs.append({'name':'기타분','revenue':0,'ratio':0,'cost':0,'sga':0,'nonop_income':won(oi),'nonop_expense':won(oe),'current_income':won(other_current),'loss':won(other_loss),'taxable':won(max(ZERO,other_current-other_loss))})
    return {'rows':bs,'current_income':sum(r['current_income'] for r in bs),'taxable':sum(r['taxable'] for r in bs),'check':sum(r['revenue'] for r in bs)-f['sales']}

def corporate_tax(base):
    x=max(ZERO,dec(base));bands=[(Decimal('200000000'),Decimal('.09')),(Decimal('20000000000'),Decimal('.19')),(Decimal('300000000000'),Decimal('.21'))]
    tax=ZERO;lower=ZERO
    for upper,rate in bands:
        part=min(x,upper)-lower
        if part>0:tax+=part*rate
        if x<=upper:return won(tax)
        lower=upper
    return won(tax+(x-lower)*Decimal('.24'))
def local_tax(base):return won(dec(corporate_tax(base))*Decimal('.10'))

def prepaid_tax(inputs):
    """Return split prepaid taxes while preserving legacy combined values."""
    has_split='prepaid_corp_interim' in inputs or 'prepaid_corp_withholding' in inputs
    legacy=won(inputs.get('prepaid_corp',0))
    interim=won(inputs.get('prepaid_corp_interim',legacy if not has_split else 0))
    withholding=won(inputs.get('prepaid_corp_withholding',0))
    local=won(inputs.get('prepaid_local',0))
    return {'prepaid_corp_interim':interim,'prepaid_corp_withholding':withholding,
            'prepaid_corp':interim+withholding,'prepaid_local':local,
            'prepaid_total':interim+withholding+local}

def tax_calculation(current_income,inputs):
    i={k:won(inputs.get(k,0)) for k in ['donation_excess','donation_carry_deduction','carry_loss','special_reduction','rd_prior','rd_current','undocumented_base','land_gain','accrued_tax']}
    i.update(prepaid_tax(inputs))
    income=won(dec(current_income)+dec(i['donation_excess'])-dec(i['donation_carry_deduction']))
    taxable=max(0,income-i['carry_loss']);output=corporate_tax(taxable);penalty=won(dec(i['undocumented_base'])*Decimal('.02'));land_rate=dec(inputs.get('land_rate',20))/100;land_tax=won(dec(i['land_gain'])*land_rate)
    credits=min(output,max(0,i['special_reduction'])+max(0,i['rd_prior'])+max(0,i['rd_current']))
    corp_total=max(0,output-credits+penalty+land_tax);corp_payable=corp_total-i['prepaid_corp'];local_total=local_tax(taxable)+won(dec(penalty)*Decimal('.10'));local_payable=local_total-i['prepaid_local']
    return {**i,'current_income':won(current_income),'income':income,'taxable':taxable,'output_tax':output,'credits':credits,'penalty':penalty,'land_tax':land_tax,'corp_total':corp_total,'corp_payable':corp_payable,'local_total':local_total,'local_payable':local_payable,'tax_expense':corp_total+local_total,'net_income':won(dec(inputs.get('pre_tax',0))-(corp_total+local_total))}

def reserve_rollforward(beginning,increase,deduction,other=0):
    ending=dec(beginning)+dec(increase)-dec(deduction)+dec(other)
    if ending<0:raise ValueError('당기 손금추인액은 사용 가능한 유보잔액을 초과할 수 없습니다.')
    return won(ending)

Sheri2 corporate tax flow update 2026.11.10.4.1

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

The English launcher and folder name prevent Windows CMD encoding errors.
The application screen and reports remain in Korean.

"""Install the external subcontract settlement module without replacing existing business modules."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import secrets
import shutil
import sys

ROOT=Path(__file__).resolve().parent
VERSION='2026.11.23.58'
PAYLOAD=['outsource_settlement_app.py','outsource_settlement_store.py','outsource_settlement_report.py','templates/외주정산_출력양식.xlsx']
PATCHED=['app_navigation.py','multiuser_app.py']

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def patch_navigation(text):
    if 'REPORTS' not in text or '채권채무확인서' not in text or 'app_secondary_navigation' not in text:
        raise ValueError('2026.11.23.57 이후 메뉴 구조를 확인할 수 없습니다: app_navigation.py')
    text,count=re.subn(r'^REPORTS\s*=.*$',"REPORTS = ['엘비데크 월별보고', '자체결산 보고', '법인결산', '채권채무확인서', '외주정산']",text,count=1,flags=re.M)
    if count!=1:raise ValueError('결산보고서 하위 메뉴를 찾지 못했습니다.')
    text,count=re.subn(r"\['monthly'\s*,\s*'self'\s*,\s*'corporate'\s*,\s*'balance_confirmation'\s*(?:,\s*'outsource_settlement')?\]","['monthly','self','corporate','balance_confirmation','outsource_settlement']",text,count=1)
    if count!=1:raise ValueError('결산보고서 하위 메뉴 키를 찾지 못했습니다.')
    text=re.sub(r"st\.columns\(\[1\.4,1\.15,1\.05,1\.35,2\.2\]", "st.columns([1.3,1.1,1,1.3,1,1.8]", text, count=1)
    text,count=re.subn(r"(VERSION\s*=\s*)(['\"])([^'\"]+)\2",lambda m:m.group(1)+m.group(2)+VERSION+m.group(2),text,count=1)
    if count!=1:raise ValueError('메뉴 버전 항목을 찾지 못했습니다.')
    text=re.sub(r'버전\s+\d{4}\.\d{2}\.\d{2}\.\d+','버전 '+VERSION,text)
    compile(text,'app_navigation.py','exec');return text

def patch_router(text):
    if "program=='외주정산'" in text:compile(text,'multiuser_app.py','exec');return text
    needle="""                elif program=='채권채무확인서':
                    from balance_confirmation_app import render as render_balance_confirmation
                    render_balance_confirmation(user)
"""
    addition=needle+"""                elif program=='외주정산':
                    from outsource_settlement_app import render as render_outsource_settlement
                    render_outsource_settlement(user)
"""
    if text.count(needle)!=1:raise ValueError('채권채무확인서 화면 연결 위치를 찾지 못했습니다: multiuser_app.py')
    text=text.replace(needle,addition,1);compile(text,'multiuser_app.py','exec');return text

def verify_package():
    for name in PAYLOAD:
        path=ROOT/name
        if not path.is_file():raise ValueError('업데이트 파일이 없습니다: '+name)
        if path.suffix=='.py':compile(path.read_text(encoding='utf-8'),name,'exec')

def update(target):
    target=Path(target).expanduser().resolve()
    if target.is_file():target=target.parent
    if target==ROOT:raise ValueError('현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.')
    if not (target/'start.bat').is_file():raise ValueError('현재 사용하는 Sheri2 프로그램 폴더가 아닙니다.')
    verify_package()
    for name in PATCHED:
        if not (target/name).is_file():raise ValueError('필수 프로그램 파일이 없습니다: '+name)
    navigation=patch_navigation((target/'app_navigation.py').read_text(encoding='utf-8'))
    router=patch_router((target/'multiuser_app.py').read_text(encoding='utf-8'))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)
    backup=target/'private'/'code-updates'/stamp;backup.mkdir(parents=True)
    existing=[]
    for name in PATCHED+PAYLOAD:
        path=target/name
        if path.is_file():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved);existing.append(name)
    (backup/'manifest.json').write_text(json.dumps({'version':VERSION,'files':{name:digest(target/name) for name in existing}},ensure_ascii=False,indent=2),encoding='utf-8')
    installed=[]
    try:
        for name in PAYLOAD:
            destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True)
            temporary=destination.with_name(destination.name+'.update-'+secrets.token_hex(4))
            try:shutil.copy2(ROOT/name,temporary);temporary.replace(destination);installed.append(name)
            finally:temporary.unlink(missing_ok=True)
        for name,content in [('app_navigation.py',navigation),('multiuser_app.py',router)]:
            destination=target/name;temporary=destination.with_name(destination.name+'.update-'+secrets.token_hex(4))
            try:temporary.write_text(content,encoding='utf-8');compile(content,name,'exec');temporary.replace(destination);installed.append(name)
            finally:temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed):
            saved=backup/name;destination=target/name
            if saved.is_file():destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(saved,destination)
            else:destination.unlink(missing_ok=True)
        raise
    print('External subcontract settlement update completed:',target)
    print('Existing databases and business modules were preserved.')
    print('Code backup:',backup)

def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
    finally:
        if window:window.destroy()

if __name__=='__main__':
    try:
        selected=choose_target()
        if not selected:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
        update(selected)
    except Exception as error:raise SystemExit('업데이트 실패: '+str(error))

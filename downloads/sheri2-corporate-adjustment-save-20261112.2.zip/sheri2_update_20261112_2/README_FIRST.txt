Sheri2 corporate direct-flow update 2026.11.12.2

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

This update preserves company databases, accounts, ledgers, attachments and closing data.
The application screen and reports remain in Korean.

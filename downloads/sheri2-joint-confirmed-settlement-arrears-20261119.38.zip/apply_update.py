"""Install update 38 only on the verified user-supplied v35 joint source."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import sys

ROOT = Path(__file__).resolve().parent
FILES = ["joint_app.py", "joint_store.py", "joint_workflow.py", "app_navigation.py"]
BASE_HASHES = {
    "joint_app.py": "eb847d16da1b2f96e182bb72c3ef87bd28b44b17d7108f9d52720bf398af2f9b",
    "joint_store.py": "a5ee881f649d64f377aed49d9e6e3dc644d3629b07fc7439b81e9194a305d622",
    "joint_workflow.py": "096c57d46adc850ae30eb577f0858ca66650d2f15be3c0bebe0ed59f411b0b37",
    "app_navigation.py": "7c9b797ec16d4b3535210a1691b60a78f250f83b877d93bdf33d7972beab85cf",
}
NEW_HASHES = {
    "joint_app.py": "a29ac529569310900cd0db1e218451b306e7c7e10bf08299bd4605acf8e0d177",
    "joint_store.py": "372acbc3c66a588587f2088392f660b3f27575f52fd3474590b612f81b6783f8",
    "joint_workflow.py": "28b31b989c670bd87778508f329af2bfc73c30334db45ff20cbbf8c24391b051",
    "app_navigation.py": "b06b142440743d5231b32b9ecc9f7e7d19c65c90f415e6337e5837f9f375776f",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def update(target):
    target = Path(target).expanduser().resolve()
    if target.is_file():
        target = target.parent
    if target == ROOT:
        raise ValueError("복구된 v35 프로그램 폴더의 start.bat을 선택하세요.")
    if not (target / "start.bat").is_file():
        raise ValueError("현재 사용하는 프로그램 폴더가 아닙니다.")
    for name in FILES:
        source = ROOT / name
        installed = target / name
        if not source.is_file() or not installed.is_file():
            raise ValueError("필수 프로그램 파일이 없습니다: " + name)
        if digest(source) != NEW_HASHES[name]:
            raise ValueError("업데이트 패키지 파일 검증에 실패했습니다: " + name)
        current = digest(installed)
        if current not in [BASE_HASHES[name], NEW_HASHES[name]]:
            raise ValueError("업로드해 주신 v35 운영본과 다른 파일입니다: " + name + ". 아무 파일도 변경하지 않았습니다.")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    backup = target / "private" / "code-updates" / stamp
    backup.mkdir(parents=True)
    manifest = {}
    for name in FILES:
        path = target / name
        manifest[name] = digest(path)
        shutil.copy2(path, backup / name)
    (backup / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    installed_names = []
    try:
        for name in FILES:
            destination = target / name
            temporary = target / (name + ".update-" + secrets.token_hex(4))
            try:
                shutil.copy2(ROOT / name, temporary)
                if digest(temporary) != NEW_HASHES[name]:
                    raise ValueError("복사 파일 검증에 실패했습니다: " + name)
                temporary.replace(destination)
                installed_names.append(name)
            finally:
                temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed_names):
            shutil.copy2(backup / name, target / name)
        raise
    for name in FILES:
        if digest(target / name) != NEW_HASHES[name]:
            raise ValueError("설치 후 검증에 실패했습니다: " + name)
    print("공동도급 확정 정산서·전월 미수액 합계 업데이트 완료:", target)
    print("기존 코드 백업:", backup)
    print("DB, 원장, 정산, 마감 및 발행자료는 변경하지 않았습니다.")


def choose_target():
    if len(sys.argv) > 1:
        return sys.argv[1].strip().strip('"')
    window = None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window = tk.Tk()
        window.withdraw()
        window.attributes("-topmost", True)
        return filedialog.askopenfilename(parent=window, title="복구된 v35 프로그램의 start.bat을 선택하세요", filetypes=[("start.bat", "start.bat")])
    finally:
        if window:
            window.destroy()


if __name__ == "__main__":
    try:
        value = choose_target()
        if not value:
            raise ValueError("취소했습니다. 아무 파일도 변경하지 않았습니다.")
        update(value)
    except Exception as error:
        raise SystemExit("업데이트 실패: " + str(error))

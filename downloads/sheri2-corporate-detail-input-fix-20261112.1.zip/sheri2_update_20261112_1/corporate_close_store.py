"""Versioned corporate-close workbooks, adjustments, ledgers and reserve rollforwards."""
import base64,hashlib,json,uuid
from datetime import date
import collaboration as shared
import corporate_close_calc as calc

DEFAULT_COMPANIES=['㈜효성','다혜건설㈜','㈜효성전문','㈜한길','㈜효성엘비데크']
DEFAULT_EXEMPT_KEYWORDS=['환입','기부금시인액','보상비','고재매각','환수']
RECOMMENDED_EXEMPT_KEYWORDS=['공사원가환입','고용보험료환급','산재보험료환급','4대보험료환급','과오납환급','정산금환급','하자보수비환수','공사비환수','폐자재매각','고철매각','부산물매각','공사관련보상금','손해배상금','기부금시인','충당금환입','대손충당금환입','퇴직급여충당금환입']
def dump(v):return json.dumps(v,ensure_ascii=False,allow_nan=False)
def rows(c,sql,args=()):
    cur=c.execute(sql,args);names=[d[0] for d in cur.description];return [dict(zip(names,r)) for r in cur]
def normalized(v):return ''.join(ch for ch in str(v or '').lower() if ch.isalnum())
def _seed_rules(c,company_id):
    for keyword in DEFAULT_EXEMPT_KEYWORDS:c.execute("INSERT OR IGNORE INTO cc_rules(company_id,kind,keyword,classification) VALUES(?, 'description', ?, '감면분')",(company_id,keyword))
    c.execute("INSERT OR IGNORE INTO cc_rules(company_id,kind,keyword,classification) VALUES(?, 'account', '잡손실', '감면분')",(company_id,))
def connect():
    shared.DATA.mkdir(parents=True,exist_ok=True);c=shared.connect(shared.DATA/'corporate_close.db');c.create_function('current_actor',0,lambda:'system')
    c.executescript('''
    CREATE TABLE IF NOT EXISTS cc_companies(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,payload TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS cc_cases(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES cc_companies(id),year INTEGER NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',version INTEGER NOT NULL DEFAULT 1,UNIQUE(company_id,year));
    CREATE TABLE IF NOT EXISTS cc_adjustments(id INTEGER PRIMARY KEY,case_id INTEGER NOT NULL REFERENCES cc_cases(id),side TEXT NOT NULL,name TEXT NOT NULL,amount INTEGER NOT NULL,target TEXT NOT NULL,cost_amount INTEGER NOT NULL DEFAULT 0,account_group TEXT NOT NULL DEFAULT '원가',note TEXT NOT NULL DEFAULT '',source_key TEXT NOT NULL DEFAULT '',version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,UNIQUE(case_id,source_key));
    CREATE TABLE IF NOT EXISTS cc_reserves(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES cc_companies(id),name TEXT NOT NULL,origin_year INTEGER NOT NULL,initial_amount INTEGER NOT NULL,target TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,UNIQUE(company_id,name,origin_year));
    CREATE TABLE IF NOT EXISTS cc_reserve_years(id INTEGER PRIMARY KEY,reserve_id INTEGER NOT NULL REFERENCES cc_reserves(id),year INTEGER NOT NULL,beginning INTEGER NOT NULL,increase INTEGER NOT NULL,deduction INTEGER NOT NULL,other INTEGER NOT NULL DEFAULT 0,ending INTEGER NOT NULL,confirmed INTEGER NOT NULL DEFAULT 0,version INTEGER NOT NULL DEFAULT 1,UNIQUE(reserve_id,year));
    CREATE TABLE IF NOT EXISTS cc_imports(id INTEGER PRIMARY KEY,case_id INTEGER NOT NULL REFERENCES cc_cases(id),kind TEXT NOT NULL,name TEXT NOT NULL,digest TEXT NOT NULL,content TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,deleted INTEGER NOT NULL DEFAULT 0,UNIQUE(case_id,kind,digest));
    CREATE TABLE IF NOT EXISTS cc_ledger_rows(id INTEGER PRIMARY KEY,import_id INTEGER NOT NULL REFERENCES cc_imports(id),posting_date TEXT NOT NULL DEFAULT '',account TEXT NOT NULL,description TEXT NOT NULL,amount INTEGER NOT NULL,business TEXT NOT NULL DEFAULT '',classification TEXT NOT NULL DEFAULT '',deleted INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS cc_rules(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES cc_companies(id),kind TEXT NOT NULL,keyword TEXT NOT NULL,classification TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,UNIQUE(company_id,kind,keyword));
    CREATE TABLE IF NOT EXISTS cc_progress_imports(id INTEGER PRIMARY KEY,case_id INTEGER NOT NULL REFERENCES cc_cases(id),name TEXT NOT NULL,sheet_name TEXT NOT NULL,digest TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,deleted INTEGER NOT NULL DEFAULT 0,UNIQUE(case_id,digest));
    CREATE TABLE IF NOT EXISTS cc_progress_projects(id INTEGER PRIMARY KEY,case_id INTEGER NOT NULL REFERENCES cc_cases(id),import_id INTEGER REFERENCES cc_progress_imports(id),source_row INTEGER NOT NULL DEFAULT 0,client TEXT NOT NULL DEFAULT '',project TEXT NOT NULL,start TEXT NOT NULL DEFAULT '',end TEXT NOT NULL DEFAULT '',contract INTEGER NOT NULL DEFAULT 0,prior_revenue INTEGER NOT NULL DEFAULT 0,current_revenue INTEGER NOT NULL DEFAULT 0,prior_cost INTEGER NOT NULL DEFAULT 0,current_cost INTEGER NOT NULL DEFAULT 0,expected_cost_rate REAL NOT NULL DEFAULT 0,trade TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT '',prior_adjustment INTEGER NOT NULL DEFAULT 0,current_adjustment INTEGER NOT NULL DEFAULT 0,prior_unfinished INTEGER NOT NULL DEFAULT 0,current_unfinished INTEGER NOT NULL DEFAULT 0,note TEXT NOT NULL DEFAULT '',version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0);
    ''')
    columns={r[1] for r in c.execute('PRAGMA table_info(cc_adjustments)')}
    if 'account_group' not in columns:c.execute("ALTER TABLE cc_adjustments ADD COLUMN account_group TEXT NOT NULL DEFAULT '원가'")
    c.execute("UPDATE cc_adjustments SET account_group='자산' WHERE account_group='원가' AND (name LIKE '%선급%' OR name LIKE '%퇴직급여충당%' OR name LIKE '%감가상각%' OR name LIKE '%유형자산%' OR name LIKE '%대손충당%')")
    c.execute("UPDATE cc_adjustments SET account_group='영업외비용' WHERE account_group='원가' AND (name LIKE '%이자비용%' OR name LIKE '%기부금%' OR name LIKE '%잡손실%' OR name LIKE '%처분손실%')")
    c.execute("UPDATE cc_adjustments SET account_group='영업외수익' WHERE account_group='원가' AND (name LIKE '%환입%' OR name LIKE '%잡이익%' OR name LIKE '%처분이익%' OR name LIKE '%보상%' OR name LIKE '%매각%' OR name LIKE '%환수%')")
    c.execute("UPDATE cc_adjustments SET account_group='법인세' WHERE account_group='원가' AND name LIKE '%법인세%'")
    for name in DEFAULT_COMPANIES:c.execute('INSERT OR IGNORE INTO cc_companies(name,payload) VALUES(?,?)',(name,dump({'businesses':['건설업']})))
    for company_id, in c.execute('SELECT id FROM cc_companies'):_seed_rules(c,company_id)
    c.commit();return shared.protect(c)

def companies(c,include_deleted=False):
    out=[]
    for r in rows(c,'SELECT * FROM cc_companies ORDER BY id'):
        if r['deleted'] and not include_deleted:continue
        out.append({**json.loads(r['payload']),'id':r['id'],'name':r['name'],'version':r['version'],'deleted':bool(r['deleted'])})
    return out
def save_company(c,name,businesses,id=None,expected=None):
    name=str(name).strip();bs=list(dict.fromkeys(str(x).strip() for x in businesses if str(x).strip()))
    if not name or not bs:raise ValueError('법인명과 한 개 이상의 업종을 입력하세요.')
    with c:
        if id:
            old=next((x for x in companies(c,True) if x['id']==id),None)
            if not old or old['version']!=expected:raise ValueError('법인 정보가 변경되었습니다. 다시 불러오세요.')
            c.execute('UPDATE cc_companies SET name=?,payload=?,version=version+1,deleted=0 WHERE id=?',(name,dump({'businesses':bs}),id));return id
        id=c.execute('INSERT INTO cc_companies(name,payload) VALUES(?,?)',(name,dump({'businesses':bs}))).lastrowid;_seed_rules(c,id);return id
def delete_company(c,id,expected,reason):
    if c.execute('SELECT 1 FROM cc_cases WHERE company_id=?',(id,)).fetchone():raise ValueError('결산 자료가 있는 법인은 삭제할 수 없습니다.')
    if not str(reason).strip():raise ValueError('삭제 사유를 입력하세요.')
    with c:c.execute('UPDATE cc_companies SET deleted=1,version=version+1 WHERE id=? AND version=?',(id,expected))
def restore_company(c,id,expected):
    with c:c.execute('UPDATE cc_companies SET deleted=0,version=version+1 WHERE id=? AND version=?',(id,expected))

def case(c,company_id,year,create=True):
    r=c.execute('SELECT * FROM cc_cases WHERE company_id=? AND year=?',(company_id,int(year))).fetchone()
    if not r and create:
        with c:c.execute('INSERT INTO cc_cases(company_id,year,payload) VALUES(?,?,?)',(company_id,int(year),dump({'values':{},'review':{},'business_revenue':{},'tax':{},'losses':{},'disposal_date':f'{int(year)+1}-03-31'})))
        r=c.execute('SELECT * FROM cc_cases WHERE company_id=? AND year=?',(company_id,int(year))).fetchone()
    if not r:return None
    names=[d[0] for d in c.execute('SELECT * FROM cc_cases LIMIT 0').description]
    d=dict(zip(names,r));return {**json.loads(d['payload']),'id':d['id'],'company_id':d['company_id'],'year':d['year'],'status':d['status'],'version':d['version']}
def ensure_open(x):
    if x['status']=='confirmed':raise ValueError('확정된 법인결산입니다. 확정을 해제한 뒤 수정하세요.')
def save_case(c,x,payload,expected):
    ensure_open(x)
    if expected!=x['version']:raise ValueError('결산 자료가 변경되었습니다. 다시 불러오세요.')
    with c:c.execute('UPDATE cc_cases SET payload=?,version=version+1 WHERE id=?',(dump(payload),x['id']))
def confirm(c,x):
    ensure_open(x)
    with c:
        c.execute("UPDATE cc_cases SET status='confirmed',version=version+1 WHERE id=?",(x['id'],))
        c.execute('''UPDATE cc_reserve_years SET confirmed=1,version=version+1
                     WHERE year=? AND reserve_id IN
                     (SELECT id FROM cc_reserves WHERE company_id=?)''',(x['year'],x['company_id']))
def reopen(c,x,reason):
    if x['status']!='confirmed':raise ValueError('확정된 결산이 아닙니다.')
    if not str(reason).strip():raise ValueError('확정 해제 사유를 입력하세요.')
    with c:
        c.execute("UPDATE cc_cases SET status='draft',version=version+1 WHERE id=?",(x['id'],))
        c.execute('''UPDATE cc_reserve_years SET confirmed=0,version=version+1
                     WHERE year=? AND reserve_id IN
                     (SELECT id FROM cc_reserves WHERE company_id=?)''',(x['year'],x['company_id']))

def prior_case(c,company_id,year):
    return case(c,company_id,int(year)-1,create=False)

def adjustments(c,case_id,include_deleted=False):
    order="CASE account_group WHEN '원가' THEN 1 WHEN '자산' THEN 2 WHEN '영업외비용' THEN 3 WHEN '영업외수익' THEN 4 WHEN '법인세' THEN 5 ELSE 9 END";out=rows(c,f'SELECT * FROM cc_adjustments WHERE case_id=? ORDER BY side,{order},id',(case_id,));return [r for r in out if include_deleted or not r['deleted']]
def save_adjustment(c,x,side,name,amount,target,cost_amount=0,note='',id=None,expected=None,source_key='',account_group='원가'):
    ensure_open(x);name=str(name).strip();amount=calc.won(calc.nonnegative(amount));cost=calc.won(calc.nonnegative(cost_amount))
    if side not in ['add','deduct'] or target not in ['원가','판관비','공통'] or account_group not in calc.ACCOUNT_GROUPS or not name:raise ValueError('세무조정 구분과 과목을 확인하세요.')
    if target=='공통' and cost>amount:raise ValueError('원가 배분액은 입력금액 이하여야 합니다.')
    with c:
        if id:
            old=c.execute('SELECT version,source_key FROM cc_adjustments WHERE id=? AND case_id=?',(id,x['id'])).fetchone()
            if not old or old[0]!=expected:raise ValueError('조정항목이 변경되었습니다. 다시 불러오세요.')
            if old[1] and old[1].startswith('reserve:'):raise ValueError('유보 연계 항목은 유보잔액 관리에서 수정하세요.')
            c.execute('UPDATE cc_adjustments SET side=?,name=?,amount=?,target=?,cost_amount=?,account_group=?,note=?,version=version+1,deleted=0 WHERE id=?',(side,name,amount,target,cost,account_group,note,id));return id
        # source_key is unique within a closing case so automatic reserve links can
        # be upserted safely.  A blank key made every manual row after the first
        # collide with that unique constraint.  Give each manual row its own key;
        # supplied keys remain reserved for automatic links.
        key=source_key or f'manual:{uuid.uuid4().hex}'
        return c.execute('INSERT INTO cc_adjustments(case_id,side,name,amount,target,cost_amount,account_group,note,source_key) VALUES(?,?,?,?,?,?,?,?,?)',(x['id'],side,name,amount,target,cost,account_group,note,key)).lastrowid
def delete_adjustment(c,x,id,expected,reason):
    ensure_open(x)
    row=c.execute('SELECT version,source_key FROM cc_adjustments WHERE id=? AND case_id=?',(id,x['id'])).fetchone()
    if not row or row[0]!=expected:raise ValueError('조정항목을 다시 불러오세요.')
    if row[1] and row[1].startswith('reserve:'):raise ValueError('유보 연계 항목은 유보잔액 관리에서 수정하세요.')
    if not str(reason).strip():raise ValueError('삭제 사유를 입력하세요.')
    with c:c.execute('UPDATE cc_adjustments SET deleted=1,note=note||?,version=version+1 WHERE id=?',('\n삭제: '+reason,id))
def restore_adjustment(c,x,id,expected):
    ensure_open(x)
    with c:c.execute('UPDATE cc_adjustments SET deleted=0,version=version+1 WHERE id=? AND version=?',(id,expected))

def reserves(c,company_id,include_deleted=False):
    out=rows(c,'SELECT * FROM cc_reserves WHERE company_id=? ORDER BY origin_year,id',(company_id,));return [r for r in out if include_deleted or not r['deleted']]
def reserve_years(c,reserve_id):return rows(c,'SELECT * FROM cc_reserve_years WHERE reserve_id=? ORDER BY year',(reserve_id,))
def save_reserve(c,x,name,origin_year,initial,target,note='',id=None,expected=None):
    ensure_open(x);name=str(name).strip();initial=calc.won(calc.nonnegative(initial))
    if not name or target not in ['원가','판관비']:raise ValueError('유보항목과 반영 구분을 확인하세요.')
    with c:
        if id:
            row=c.execute('SELECT version FROM cc_reserves WHERE id=? AND company_id=?',(id,x['company_id'])).fetchone()
            if not row or row[0]!=expected:raise ValueError('유보항목을 다시 불러오세요.')
            c.execute('UPDATE cc_reserves SET name=?,origin_year=?,initial_amount=?,target=?,note=?,version=version+1,deleted=0 WHERE id=?',(name,int(origin_year),initial,target,note,id));return id
        return c.execute('INSERT INTO cc_reserves(company_id,name,origin_year,initial_amount,target,note) VALUES(?,?,?,?,?,?)',(x['company_id'],name,int(origin_year),initial,target,note)).lastrowid
def save_reserve_year(c,x,reserve_id,year,increase,deduction,other=0):
    ensure_open(x);r=next((r for r in reserves(c,x['company_id']) if r['id']==reserve_id),None)
    if not r:raise ValueError('유보항목을 확인하세요.')
    prior=c.execute('SELECT ending FROM cc_reserve_years WHERE reserve_id=? AND year<? ORDER BY year DESC LIMIT 1',(reserve_id,int(year))).fetchone();beginning=prior[0] if prior else r['initial_amount']
    ending=calc.reserve_rollforward(beginning,increase,deduction,other)
    with c:
        c.execute('INSERT INTO cc_reserve_years(reserve_id,year,beginning,increase,deduction,other,ending) VALUES(?,?,?,?,?,?,?) ON CONFLICT(reserve_id,year) DO UPDATE SET beginning=excluded.beginning,increase=excluded.increase,deduction=excluded.deduction,other=excluded.other,ending=excluded.ending,version=cc_reserve_years.version+1',(reserve_id,int(year),beginning,calc.won(increase),calc.won(deduction),calc.won(other),ending))
        for side,amount,label in [('add',increase,r['name']),('deduct',deduction,r['name'])]:
            key=f'reserve:{reserve_id}:{year}:{side}'
            c.execute('INSERT INTO cc_adjustments(case_id,side,name,amount,target,cost_amount,note,source_key) VALUES(?,?,?,?,?,0,?,?) ON CONFLICT(case_id,source_key) DO UPDATE SET amount=excluded.amount,name=excluded.name,target=excluded.target,deleted=0,version=cc_adjustments.version+1',(x['id'],side,label,calc.won(amount),r['target'],'유보잔액 자동 연계',key))
    return ending
def delete_reserve(c,x,id,expected,reason):
    ensure_open(x)
    if c.execute('SELECT 1 FROM cc_reserve_years WHERE reserve_id=? AND confirmed=1',(id,)).fetchone():raise ValueError('확정 이력이 있는 유보항목은 삭제할 수 없습니다.')
    if not str(reason).strip():raise ValueError('삭제 사유를 입력하세요.')
    with c:c.execute('UPDATE cc_reserves SET deleted=1,note=note||?,version=version+1 WHERE id=? AND version=?',('\n삭제: '+reason,id,expected))
def restore_reserve(c,x,id,expected):
    ensure_open(x)
    with c:c.execute('UPDATE cc_reserves SET deleted=0,version=version+1 WHERE id=? AND version=?',(id,expected))

def save_import(c,x,kind,name,content,parsed):
    ensure_open(x);digest=hashlib.sha256(content).hexdigest()
    if len(content)>20*1024*1024:raise ValueError('원장 파일은 20MB 이하만 등록할 수 있습니다.')
    with c:
        old=c.execute('SELECT id FROM cc_imports WHERE case_id=? AND kind=? AND digest=?',(x['id'],kind,digest)).fetchone()
        if old:raise ValueError('같은 원장 파일이 이미 등록되어 있습니다.')
        iid=c.execute('INSERT INTO cc_imports(case_id,kind,name,digest,content,payload) VALUES(?,?,?,?,?,?)',(x['id'],kind,name,digest,base64.b64encode(content).decode(),dump({'count':len(parsed)}))).lastrowid
        c.executemany('INSERT INTO cc_ledger_rows(import_id,posting_date,account,description,amount,business,classification) VALUES(?,?,?,?,?,?,?)',[(iid,r.get('date',''),r.get('account',''),r.get('description',''),calc.won(r.get('amount',0)),r.get('business',''),r.get('classification','')) for r in parsed])
    apply_income_rules(c,x)
    return iid
def imports(c,case_id):return rows(c,'SELECT id,kind,name,digest,payload,created_at,deleted FROM cc_imports WHERE case_id=? ORDER BY id DESC',(case_id,))
def ledger_rows(c,case_id,kind=None):
    sql="""SELECT r.*,CASE
      WHEN r.account LIKE '%영업외수익%' OR r.account LIKE '%잡이익%' OR r.account LIKE '%처분이익%' THEN '영업외수익'
      WHEN r.account LIKE '%영업외비용%' OR r.account LIKE '%잡손실%' OR r.account LIKE '%처분손실%' OR r.account LIKE '%이자비용%' OR r.account LIKE '%기부금%' THEN '영업외비용'
      ELSE i.kind END kind,i.name source_name
      FROM cc_ledger_rows r JOIN cc_imports i ON i.id=r.import_id
      WHERE i.case_id=? AND i.deleted=0 AND r.deleted=0""";args=[case_id]
    if kind:sql+=' AND i.kind=?';args.append(kind)
    return rows(c,sql+' ORDER BY r.id',args)
def classify_rows(c,x,changes):
    ensure_open(x)
    with c:
        for id,classification,business in changes:
            if classification not in ['','감면분','기타분']:raise ValueError('소득구분을 확인하세요.')
            c.execute('UPDATE cc_ledger_rows SET classification=?,business=? WHERE id=?',(classification,business or '수동',id))
def income_rules(c,company_id,include_deleted=False):
    out=rows(c,"SELECT * FROM cc_rules WHERE company_id=? ORDER BY CASE kind WHEN 'account' THEN 1 ELSE 2 END,id",(company_id,));return [r for r in out if include_deleted or not r['deleted']]
def save_income_rule(c,x,kind,keyword,id=None,expected=None):
    ensure_open(x);keyword=str(keyword).strip()
    if kind not in ['description','account'] or not keyword:raise ValueError('적요 문구와 적용 대상을 확인하세요.')
    with c:
        if id:
            old=c.execute('SELECT version FROM cc_rules WHERE id=? AND company_id=?',(id,x['company_id'])).fetchone()
            if not old or old[0]!=expected:raise ValueError('감면분 문구가 변경되었습니다. 다시 불러오세요.')
            c.execute("UPDATE cc_rules SET kind=?,keyword=?,classification='감면분',version=version+1,deleted=0 WHERE id=?",(kind,keyword,id))
        else:c.execute("INSERT INTO cc_rules(company_id,kind,keyword,classification) VALUES(?,?,?,'감면분')",(x['company_id'],kind,keyword))
    apply_income_rules(c,x)
def delete_income_rule(c,x,id,expected):
    ensure_open(x)
    with c:c.execute('UPDATE cc_rules SET deleted=1,version=version+1 WHERE id=? AND company_id=? AND version=?',(id,x['company_id'],expected))
    apply_income_rules(c,x)
def restore_income_rule(c,x,id,expected):
    ensure_open(x)
    with c:c.execute('UPDATE cc_rules SET deleted=0,version=version+1 WHERE id=? AND company_id=? AND version=?',(id,x['company_id'],expected))
    apply_income_rules(c,x)
def apply_income_rules(c,x):
    ensure_open(x);rules=income_rules(c,x['company_id']);rs=ledger_rows(c,x['id'])
    with c:
        for r in rs:
            if r['kind'] not in ['영업외수익','영업외비용'] or r.get('business')=='수동':continue
            account=normalized(r['account']);description=normalized(r['description']);matched=''
            for rule in rules:
                needle=normalized(rule['keyword']);hay=account if rule['kind']=='account' else description
                if needle and needle in hay:matched=rule['keyword'];break
            c.execute('UPDATE cc_ledger_rows SET classification=?,business=? WHERE id=?',('감면분' if matched else '기타분',('자동:'+matched) if matched else '자동:기타분',r['id']))
def rule_recommendations(c,x):
    existing={normalized(r['keyword']) for r in income_rules(c,x['company_id'])};out=[]
    for keyword in RECOMMENDED_EXEMPT_KEYWORDS:
        if normalized(keyword) in existing:continue
        matches=[r for r in ledger_rows(c,x['id']) if r['kind'] in ['영업외수익','영업외비용'] and normalized(keyword) in normalized(r['description'])]
        if matches:out.append({'추천 문구':keyword,'발견 건수':len(matches),'합계금액':sum(r['amount'] for r in matches),'대표 적요':matches[0]['description']})
    return out
def delete_import(c,x,id):
    ensure_open(x)
    with c:c.execute('UPDATE cc_imports SET deleted=1 WHERE id=? AND case_id=?',(id,x['id']))
def restore_import(c,x,id):
    ensure_open(x)
    with c:c.execute('UPDATE cc_imports SET deleted=0 WHERE id=? AND case_id=?',(id,x['id']))

def progress_imports(c,case_id,include_deleted=False):
    out=rows(c,'SELECT id,name,sheet_name,digest,created_at,deleted FROM cc_progress_imports WHERE case_id=? ORDER BY id DESC',(case_id,));return [r for r in out if include_deleted or not r['deleted']]
def progress_projects(c,case_id,include_deleted=False):
    out=rows(c,'SELECT * FROM cc_progress_projects WHERE case_id=? ORDER BY deleted,source_row,id',(case_id,));return [r for r in out if include_deleted or not r['deleted']]
def save_progress_import(c,x,name,sheet_name,content,projects):
    ensure_open(x);digest=hashlib.sha256(content).hexdigest()
    if len(content)>20*1024*1024:raise ValueError('공사수입·원가대비 파일은 20MB 이하만 등록할 수 있습니다.')
    if c.execute('SELECT 1 FROM cc_progress_imports WHERE case_id=? AND digest=?',(x['id'],digest)).fetchone():raise ValueError('같은 공사수입·원가대비 파일이 이미 등록되어 있습니다.')
    with c:
        c.execute('UPDATE cc_progress_imports SET deleted=1 WHERE case_id=? AND deleted=0',(x['id'],));c.execute('UPDATE cc_progress_projects SET deleted=1,version=version+1 WHERE case_id=? AND deleted=0',(x['id'],))
        iid=c.execute('INSERT INTO cc_progress_imports(case_id,name,sheet_name,digest,content) VALUES(?,?,?,?,?)',(x['id'],name,sheet_name,digest,base64.b64encode(content).decode())).lastrowid
        fields=['source_row','client','project','start','end','contract','prior_revenue','current_revenue','prior_cost','current_cost','expected_cost_rate','trade','status','prior_adjustment','current_adjustment','prior_unfinished','current_unfinished','note']
        c.executemany('INSERT INTO cc_progress_projects(case_id,import_id,'+','.join(fields)+') VALUES(?,?,'+','.join('?' for _ in fields)+')',[(x['id'],iid,*[p.get(k,0 if k not in ['client','project','start','end','trade','status','note'] else '') for k in fields]) for p in projects])
    return iid
def save_progress_project(c,x,id,expected,values):
    ensure_open(x);row=c.execute('SELECT version FROM cc_progress_projects WHERE id=? AND case_id=?',(id,x['id'])).fetchone()
    if not row or row[0]!=expected:raise ValueError('현장 자료가 변경되었습니다. 다시 불러오세요.')
    fields=['client','project','start','end','contract','prior_revenue','current_revenue','prior_cost','current_cost','expected_cost_rate','trade','status','prior_adjustment','current_adjustment','prior_unfinished','current_unfinished','note']
    with c:c.execute('UPDATE cc_progress_projects SET '+','.join(k+'=?' for k in fields)+',version=version+1,deleted=0 WHERE id=?',(*[values.get(k,0 if k not in ['client','project','start','end','trade','status','note'] else '') for k in fields],id))
def delete_progress_project(c,x,id,expected,reason):
    ensure_open(x)
    if not str(reason).strip():raise ValueError('삭제 사유를 입력하세요.')
    with c:c.execute('UPDATE cc_progress_projects SET deleted=1,note=note||?,version=version+1 WHERE id=? AND case_id=? AND version=?',('\n삭제: '+reason,id,x['id'],expected))
def restore_progress_project(c,x,id,expected):
    ensure_open(x)
    with c:c.execute('UPDATE cc_progress_projects SET deleted=0,version=version+1 WHERE id=? AND case_id=? AND version=?',(id,x['id'],expected))
def delete_progress_import(c,x,id):
    ensure_open(x)
    with c:c.execute('UPDATE cc_progress_imports SET deleted=1 WHERE id=? AND case_id=?',(id,x['id']));c.execute('UPDATE cc_progress_projects SET deleted=1,version=version+1 WHERE import_id=? AND case_id=?',(id,x['id']))
def restore_progress_import(c,x,id):
    ensure_open(x)
    with c:
        c.execute('UPDATE cc_progress_imports SET deleted=1 WHERE case_id=? AND deleted=0',(x['id'],));c.execute('UPDATE cc_progress_projects SET deleted=1,version=version+1 WHERE case_id=? AND deleted=0',(x['id'],));c.execute('UPDATE cc_progress_imports SET deleted=0 WHERE id=? AND case_id=?',(id,x['id']));c.execute('UPDATE cc_progress_projects SET deleted=0,version=version+1 WHERE import_id=? AND case_id=?',(id,x['id']))

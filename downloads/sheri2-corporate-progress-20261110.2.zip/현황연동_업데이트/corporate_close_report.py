"""Excel-shaped corporate-close preview and numeric workbook export."""
from html import escape
from io import BytesIO
import openpyxl
from openpyxl.styles import Font,PatternFill,Border,Side,Alignment
from openpyxl.utils import get_column_letter
import corporate_close_calc as calc
from table_layout import format_excel

def n(v):return f'{int(v):,}'
def td(label,value=None,kind='',span=1):
    cls=(' '+kind) if kind else ''
    if value is None:return f'<td colspan="{span}" class="text{cls}">{escape(str(label))}</td>'
    return f'<td class="text{cls}">{escape(str(label))}</td><td class="money{cls}">{n(value)}</td>'
def html(company,year,payload,adjustments,income,tax,reserves=()):
    f=calc.flow(payload.get('values',{}),adjustments);a=calc.adjustment_totals(adjustments)
    review=payload.get('review',{});blue=lambda k:n(review.get(k,0));tax_ready=all(k in payload.get('tax',{}) for k in ['donation_excess','donation_carry_deduction','carry_loss','special_reduction','rd_prior','rd_current','undocumented_base','land_gain','prepaid_corp','prepaid_local','accrued_tax'])
    def adj(side):
        rs=[r for r in adjustments if r['side']==side and not r.get('deleted')];body=''
        for r in rs:
            cost=r['amount'] if r['target']=='원가' else r.get('cost_amount',0) if r['target']=='공통' else 0;sga=r['amount']-cost
            body+=f'<tr><td>{escape(r["name"])}</td><td class="money input">{n(r["amount"])}</td><td class="money calc">{n(cost)}</td><td class="money calc">{n(sga)}</td></tr>'
        amount=sum(r['amount'] for r in rs);cost=a[side+'_cost'];sga=a[side+'_sga']
        return body+f'<tr class="auto"><th>계</th><th class="money calc">{n(amount)}</th><th class="money calc">{n(cost)}</th><th class="money calc">{n(sga)}</th></tr>'
    division=''.join(f'<tr><td>{escape(r["name"])}</td><td class="money">{n(r["revenue"])}</td><td class="money">{n(r["cost"])}</td><td class="money">{n(r["sga"])}</td><td class="money">{n(r["nonop_income"])}</td><td class="money">{n(r["nonop_expense"])}</td><td class="money calc">{n(r["current_income"])}</td><td class="money input">{n(r["loss"])}</td><td class="money calc">{n(r["taxable"])}</td></tr>' for r in income['rows'])
    reserve_rows=''.join(f'<tr><td>{escape(r["name"])}</td><td>{r["origin_year"]}</td><td class="money">{n(r.get("beginning",0))}</td><td class="money input">{n(r.get("increase",0))}</td><td class="money input">{n(r.get("deduction",0))}</td><td class="money calc">{n(r.get("ending",0))}</td></tr>' for r in reserves)
    css='''*{box-sizing:border-box}body{font:12px "Malgun Gothic",sans-serif;color:#111;margin:10px;background:white}.title{text-align:center;color:#00a6df;text-decoration:underline;font-size:25px}.meta{display:flex;justify-content:space-between;font-weight:bold;font-size:15px;margin:8px 0}table{border-collapse:collapse;width:100%;margin-bottom:13px}th,td{border:1px dotted #777;padding:5px;text-align:center}th{font-weight:700}.money{text-align:right;font-variant-numeric:tabular-nums}.input{color:#2788e8}.calc{color:#f22}.auto{background:#fff600;font-weight:bold}.section{background:#bbb;font-size:14px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:0}.pair table:first-child{border-right:2px solid #222}.green{background:#eaf4ed;font-weight:bold}.note{font-size:10px}.break{break-before:page}@page{size:A4 landscape;margin:8mm}@media print{body{margin:0;font-size:6.7pt}.title{font-size:18pt;margin:0 0 3mm}.meta{font-size:9pt;margin:2mm 0}table{margin-bottom:2.5mm}th,td{padding:1.2mm}.section{font-size:8pt}.no-print{display:none}.break{page-break-before:always}}'''
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><style>{css}</style></head><body><button class="no-print" onclick="print()">인쇄 / PDF 저장</button><h1 class="title">{year}년도 법인세 계산 흐름표</h1><div class="meta"><span>{escape(company)}</span><span>처분확정일 {escape(payload.get('disposal_date',''))}</span></div>
    <table><tr><th class="section" colspan="2">손익계산서 점검</th><th class="section" colspan="2">전기·예상 지표</th><th class="section" colspan="3">조정 전 검토사항</th><th class="section" colspan="2">기납부세액</th></tr>
    <tr>{td('공사수입',f['construction_revenue'],'input')}{td('전기매출',f['prior_sales'],'input')}<td>접대비·경비</td><td class="money input">{blue('entertainment_cost')}</td><td></td>{td('법인중간·원천납부',tax['prepaid_corp'],'input')}</tr>
    <tr>{td('용역수입',f['service_revenue'],'input')}{td('당기매출',f['sales'],'auto')}<td>접대비·판관비</td><td class="money input">{blue('entertainment_sga')}</td><td></td>{td('지방세 기납부',tax['prepaid_local'],'input')}</tr>
    <tr>{td('진행률조정수입',f['progress_adjustment'],'calc')}{td('증감률',round(f['sales_growth']))}<td>세금과공과·경비</td><td class="money input">{blue('tax_cost')}</td><td></td>{td('선납세금 계',tax['prepaid_corp']+tax['prepaid_local'],'auto')}</tr>
    <tr>{td('매출계',f['sales'],'auto')}{td('매출원가',f['cost'],'input')}<td>세금과공과·판관비</td><td class="money input">{blue('tax_sga')}</td><td></td><td colspan="2"></td></tr>
    <tr>{td('매출총이익',f['gross_profit'],'auto')}{td('판매관리비',f['sga'],'input')}<td>이자비용</td><td class="money input">{blue('interest')}</td><td></td><td colspan="2"></td></tr>
    <tr>{td('영업이익',f['operating_profit'],'auto')}{td('영업외수익',f['nonop_income'],'input')}<td>기부금</td><td class="money input">{blue('donation')}</td><td></td><td colspan="2"></td></tr>
    <tr>{td('영업외비용',f['nonop_expense'],'input')}{td('법인세차감전순이익',f['pre_tax'],'auto')}<td>연구·인력개발비</td><td class="money input">{blue('rnd')}</td><td></td><td colspan="2"></td></tr>
    <tr><td class="text calc">법인세등</td><td class="money calc">{n(tax['tax_expense']) if tax_ready else '계산 대기'}</td>{td('당기순이익',tax['net_income'],'auto')}<td>기술개발투자비</td><td class="money auto">{n(review.get('tech_total',0))}</td><td></td><td colspan="2"></td></tr></table>
    <div class="pair"><table><tr><th class="section" colspan="4">익금산입 및 손금불산입</th></tr><tr><th>과목</th><th>금액</th><th>원가부인</th><th>판관비부인</th></tr>{adj('add')}</table><table><tr><th class="section" colspan="4">손금산입 및 익금불산입</th></tr><tr><th>과목</th><th>금액</th><th>원가추인</th><th>판관비추인</th></tr>{adj('deduct')}</table></div>
    <table><tr><th class="section" colspan="9">소득구분계산서</th></tr><tr><th>구분</th><th>매출액</th><th>매출원가</th><th>판매관리비</th><th>영업외수익</th><th>영업외비용</th><th>각사업연도소득</th><th>이월결손금</th><th>과세표준</th></tr>{division}</table>
    <table><tr><th class="section" colspan="6">세액 계산</th></tr><tr><td>차가감소득금액</td><td class="money calc">{n(tax['current_income'])}</td><td class="auto">산출세액</td><td class="money auto calc">{n(tax['output_tax'])}</td><td>공제·감면</td><td class="money calc">{n(tax['credits'])}</td></tr><tr><td>기부금한도초과</td><td class="money input">{n(tax['donation_excess'])}</td><td>가산세</td><td class="money calc">{n(tax['penalty'])}</td><td>법인세 총부담세액</td><td class="money calc">{n(tax['corp_total'])}</td></tr><tr><td>기부금이월손금</td><td class="money input">{n(tax['donation_carry_deduction'])}</td><td>법인세 기납부세액</td><td class="money input">{n(tax['prepaid_corp'])}</td><td class="auto">법인세 납부·환급</td><td class="money auto calc">{n(tax['corp_payable'])}</td></tr><tr><td>전기이월결손금</td><td class="money input">{n(tax['carry_loss'])}</td><td>지방소득세 총부담</td><td class="money calc">{n(tax['local_total'])}</td><td class="auto">지방소득세 납부·환급</td><td class="money auto calc">{n(tax['local_payable'])}</td></tr><tr><td class="auto">과세표준</td><td class="money auto calc">{n(tax['taxable'])}</td><td colspan="3" class="green">법인세·지방소득세 총부담</td><td class="money green calc">{n(tax['corp_total']+tax['local_total'])}</td></tr></table>
    <table class="break"><tr><th class="section" colspan="6">유보잔액 관리대장</th></tr><tr><th>관리항목</th><th>발생연도</th><th>기초 유보액</th><th>당기 증가액</th><th>당기 추인액</th><th>기말 유보잔액</th></tr>{reserve_rows or '<tr><td colspan="6">등록된 유보항목이 없습니다.</td></tr>'}</table><p class="note">파란색은 원장·전기이월·작업자 입력, 빨간색은 자동계산, 노란색은 주요 자동계산 결과입니다.</p></body></html>'''

def workbook(company,year,payload,adjustments,income,tax,reserves=()):
    w=openpyxl.Workbook();s=w.active;s.title='법인세 계산'
    rows=[['법인세 계산 흐름표',company,year],['항목','금액'],['차가감소득금액',tax['current_income']],['기부금한도초과',tax['donation_excess']],['기부금이월손금',tax['donation_carry_deduction']],['전기이월결손금',tax['carry_loss']],['과세표준',tax['taxable']],['산출세액',tax['output_tax']],['공제·감면',tax['credits']],['가산세',tax['penalty']],['법인세 총부담',tax['corp_total']],['법인세 납부·환급',tax['corp_payable']],['지방소득세 총부담',tax['local_total']],['지방소득세 납부·환급',tax['local_payable']]]
    for r in rows:s.append(r)
    for name,data,headers in [('세무조정',adjustments,['구분','과목','금액','반영구분','원가배분액','비고']),('소득구분',income['rows'],['구분','매출액','매출원가','판매관리비','영업외수익','영업외비용','각사업연도소득','이월결손금','과세표준']),('유보잔액',reserves,['관리항목','발생연도','기초유보액','당기증가액','당기추인액','기말유보잔액'])]:
        sh=w.create_sheet(name);sh.append(headers)
        for r in data:
            if name=='세무조정':sh.append([r['side'],r['name'],r['amount'],r['target'],r.get('cost_amount',0),r.get('note','')])
            elif name=='소득구분':sh.append([r['name'],r['revenue'],r['cost'],r['sga'],r['nonop_income'],r['nonop_expense'],r['current_income'],r['loss'],r['taxable']])
            else:sh.append([r['name'],r['origin_year'],r.get('beginning',0),r.get('increase',0),r.get('deduction',0),r.get('ending',0)])
        format_excel(sh);sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
        for cell in sh[1]:cell.fill=PatternFill('solid',fgColor='DCECE2');cell.font=Font(bold=True)
    format_excel(s);s.column_dimensions['A'].width=28;s.column_dimensions['B'].width=22
    out=BytesIO();w.save(out);return out.getvalue()

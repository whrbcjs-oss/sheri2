"""Loan overview, certificates, actual collections and contract renewal."""
from datetime import date
from io import BytesIO
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
import loan_calc as calc
import loan_store as db
import loan_report as report

PAGES=['대여금 총현황','차용증 작성','인별 차용현황']

def go(page,id=None):
    st.session_state['loan_page']=page
    if id is not None:st.session_state['loan_selected']=id

def uploads(files):return [dict(name=f.name,mime=f.type,content=f.getvalue()) for f in files or []]
def act(fn):
    try:fn();st.success('저장했습니다.');st.rerun()
    except ValueError as e:st.error(str(e))

def render_alerts(c=None,home=False):
    items=db.alerts(c)
    if not items:return
    st.subheader('대여금 상환 알림현황판')
    for a in items:
        text=f"{a['status']} · {a['name']} / {a['company']} · 상환기일 {a['due']} · 잔여원금 {calc.money(a['balance'])}원"
        if a['status']=='기일 경과':st.error(text)
        else:st.warning(text)
    if home and st.button('대여금 현황 확인',key='loan_home_open'):
        st.session_state['main_system']='대여금관리';go(PAGES[0]);st.rerun()
    st.caption('상환기일 한 달 전부터 안내합니다. 원금·이자 회수 완료 계약은 제외합니다.')

def fields(prefix,initial=None,renew=False,c=None):
    today=db.today();v=initial or {};key=lambda n:prefix+n
    with st.container(border=True):
        st.markdown('**작성 정보**')
        cols=st.columns(2)
        issued=cols[0].date_input('작성일자',calc.day(v.get('issued_date',today)),key=key('issued'))
        number=cols[1].text_input('갱신 관리번호' if renew else '관리번호',db.next_number(c,issued),key=key('number_')+db.next_number(c,issued)) if c is not None else ''
    with st.container(border=True):
        st.markdown('**차용기간**')
        cols=st.columns(2)
        start=cols[0].date_input('갱신 적용일' if renew else '대여일 / 차용 시작일',today if renew else calc.day(v.get('start_date',today)),key=key('start'))
        end=cols[1].date_input('상환기일 / 차용 종료일',calc.add_months(calc.day(v.get('end_date',today)),12) if renew else calc.day(v.get('end_date',calc.add_months(today,12))),min_value=start,key=key('end'))
    with st.container(border=True):
        st.markdown('**차용금액 · 이자**')
        cols=st.columns(2)
        principal=cols[0].number_input('차용금액 (원)',min_value=0,value=int(v.get('principal',0)),step=100000,key=key('principal'),disabled=renew)
        kind=cols[1].selectbox('차용이자 구분',calc.KINDS,index=calc.KINDS.index(v.get('interest_kind',calc.KINDS[0])),key=key('kind'))
        cols=st.columns(2)
        rate=cols[0].number_input('연이율 (%)',min_value=0.,max_value=100.,value=float(v.get('rate',5)),step=.1,key=key('rate'),disabled=kind!=calc.KINDS[0])
        fixed=cols[1].number_input('매월 약정 이자 (원)',min_value=0,value=int(v.get('fixed_interest',0)),key=key('fixed'),disabled=kind!=calc.KINDS[1])
    with st.container(border=True):
        st.markdown('**상환 조건 · 일정**')
        mode=st.radio('상환조건',calc.MODES,index=calc.MODES.index(v.get('mode',calc.MODES[2])),key=key('mode'))
        cols=st.columns(2)
        first_default=min(calc.add_months(start,1),end)
        first=cols[0].date_input('첫 상환일',end if mode==calc.MODES[1] else (calc.day(v.get('first_due',first_default)) if not renew else first_default),key=key('first'),disabled=mode==calc.MODES[1])
        pay_day=cols[1].number_input('매월 상환일 (일)',1,31,int(v.get('pay_day',first.day)),key=key('payday'))
        cols=st.columns(2)
        method=cols[0].selectbox('매월 원리금 계산',calc.METHODS,index=calc.METHODS.index(v.get('method',calc.METHODS[0])),key=key('method'),disabled=mode!=calc.MODES[0])
        manual=cols[1].checkbox('매월 원리금 상환액 직접 지정',value=bool(v.get('installment',0)),key=key('manual'),disabled=mode!=calc.MODES[0])
        installment=st.number_input('매월 원리금 합계 (원)',min_value=0,value=int(v.get('installment',0)),key=key('installment'),disabled=not manual)
        with st.expander('이자 계산 기준'):
            basis=st.selectbox('계산 기준',calc.BASES,index=calc.BASES.index(v.get('basis',calc.BASES[0])),key=key('basis'))
            early=st.selectbox('중도 원금상환 후 이자',['잔여원금 기준','약정 유지'],index=0 if v.get('early_interest','잔여원금 기준')=='잔여원금 기준' else 1,key=key('early'))
            st.caption('월 단위는 연이율 ÷ 12를 적용하며, 일부 월은 해당 계약 월의 경과 비율로 계산합니다. 마지막 회차에 원 단위 차액과 남은 원금을 정산합니다.')
    with st.container(border=True):
        st.markdown('**담보 · 기타 약정**')
        cols=st.columns(2)
        collateral=cols[0].text_area('기타 조건 / 담보 (아파트·퇴직연금 등)',v.get('collateral',''),key=key('collateral'))
        note=cols[1].text_area('비고 / 추가 약정',v.get('note',''),key=key('note'))
    return dict(issued_date=str(issued),start_date=str(start),end_date=str(end),principal=principal,interest_kind=kind,rate=rate,fixed_interest=fixed,mode=mode,method=method,first_due=str(end if mode==calc.MODES[1] else first),pay_day=pay_day,installment=installment if manual and mode==calc.MODES[0] else 0,basis=basis,early_interest=early,collateral=collateral,note=note,number=number)

def downloads(c,item,prefix):
    show=st.checkbox('출력물에 주민등록번호 전체 표시',key=prefix+'showid')
    snapshots=db.issued(c,item['id'])
    if st.button('현재 차용증 발행 기록 저장',key=prefix+'issue'):act(lambda:db.issue(c,item['id']))
    versions=[dict(data=dict(v['data'],attachments=[f['name'] for f in db.attachments(c,item['id'],v['id']) if not f['receipt_id']]),label=f"{v['version']}차 계약 · {v['number']}") for v in reversed(item['versions'])]
    docs=[dict(data=x['data'],label=f"발행본 #{x['id']} · {x['created_at']}") for x in snapshots]+versions
    doc=st.selectbox('계약·발행 이력',docs,format_func=lambda x:x['label'],key=prefix+'doc')['data']
    components.html(report.certificate_html(doc,show),height=740,scrolling=True)
    st.download_button('차용증 인쇄 HTML',report.certificate_html(doc,show),file_name=doc['number']+'.html',mime='text/html',key=prefix+'html')
    if st.button('PDF 만들기',key=prefix+'pdfmake'):
        st.download_button('차용증 PDF 다운로드',report.certificate_pdf(doc,show),file_name=doc['number']+'.pdf',mime='application/pdf',key=prefix+'pdf')
    with st.expander('첨부서류 / 회수 증빙'):
        for f in db.attachments(c,item['id']):
            r,data=db.attachment_bytes(c,item['id'],f['id'])
            st.download_button(f['name'],data,file_name=f['name'],mime=f['mime'],key=prefix+'file'+str(f['id']))

def overview(c):
    st.header('대여금 총현황')
    render_alerts(c)
    cols=st.columns(3);asof=cols[0].date_input('기준일',db.today(),key='loan_asof')
    items=db.loans(c,asof)
    company=cols[1].selectbox('지급회사',['전체']+sorted({v['company'] for v in items}))
    person=cols[2].selectbox('차용인',['전체']+sorted({v['borrower']['name'] for v in items}))
    items=[v for v in items if (company=='전체' or v['company']==company) and (person=='전체' or v['borrower']['name']==person)]
    summaries=[db.summary(c,v,asof) for v in items]
    cols=st.columns(4)
    for col,key,label in zip(cols,['principal','paid_principal','balance','unpaid_interest'],['총 대여원금','회수 원금','미회수 원금','발생 미회수 이자']):col.metric(label,calc.money(sum(s[key] for s in summaries))+'원')
    html=report.register_html(summaries,asof)
    components.html(html,height=430,scrolling=True)
    st.download_button('총현황표 인쇄',html,file_name='대여금총현황.html',mime='text/html')
    records=[dict(관리번호=v['number'],구분=v['borrower']['kind'],차용인=v['borrower']['name'],지급회사=v['company'],대여일=v['start_date'],적요='일시 대여금',채권금액=s['principal'],상환원금=s['paid_principal'],잔액=s['balance'],상환일=v['terms']['end_date'],이자=report.interest_label(v['terms']),증빙='차용증',비고=v['terms'].get('note','')) for s in summaries for v in [s['loan']]]
    out=BytesIO()
    with pd.ExcelWriter(out,engine='openpyxl') as writer:
        pd.DataFrame(records,columns=['관리번호','구분','차용인','지급회사','대여일','적요','채권금액','상환원금','잔액','상환일','이자','증빙','비고']).to_excel(writer,index=False,sheet_name='대여금총현황',startrow=4)
        from openpyxl.styles import Font,PatternFill,Alignment
        from openpyxl.utils import get_column_letter
        sheet=writer.sheets['대여금총현황'];sheet.merge_cells('A1:I2');sheet['A1']='임직원 차용현황표';sheet['A1'].font=Font(size=20,bold=True);sheet['A1'].alignment=Alignment(horizontal='center',vertical='center')
        for col,label in zip(range(10,14),['담당','부장','상무','사장']):sheet.cell(1,col,label)
        sheet['A4']='기준일: '+str(asof);sheet.freeze_panes='A6';sheet.auto_filter.ref=sheet.dimensions
        for col in range(1,14):sheet.column_dimensions[get_column_letter(col)].width=20 if col in [1,4,13] else 16
        for cell in sheet[5]:cell.fill=PatternFill('solid',fgColor='DFF3E7');cell.font=Font(bold=True)
        for row in sheet.iter_rows(min_row=6,min_col=7,max_col=9):
            for cell in row:cell.number_format='#,##0'
        sheet.append(['전체 합계','','','','','']+[sum(s[k] for s in summaries) for k in ['principal','paid_principal','balance']])
        from table_layout import format_excel
        format_excel(sheet,min_row=5)
        sheet.sheet_properties.pageSetUpPr.fitToPage=True;sheet.page_setup.orientation='landscape';sheet.page_setup.paperSize=sheet.PAPERSIZE_A3;sheet.page_setup.fitToWidth=1;sheet.page_setup.fitToHeight=0
    st.download_button('엑셀 다운로드',out.getvalue(),file_name='대여금총현황.xlsx')
    if st.button('새 차용증 작성',type='primary'):go(PAGES[1]);st.rerun()

def compose(c):
    st.header('차용증 작성')
    people=db.borrowers(c);options=[None]+people
    person=st.selectbox('차용인 선택',options,format_func=lambda p:'신규 차용인' if p is None else p['name']+' · '+p['phone'],key='loan_person') or {}
    left,right=st.columns([1.15,1])
    with left:
        with st.container(border=True):
            st.markdown('**차용인 정보**')
            cols=st.columns(2)
            name=cols[0].text_input('차용인',person.get('name',''),key='loan_name'+str(person.get('id',0)))
            kind=cols[1].selectbox('차용인 구분',['직원','개인','법인'],index=['직원','개인','법인'].index(person.get('kind','직원')))
            cols=st.columns(2)
            nid=cols[0].text_input('주민등록번호 / 생년월일',person.get('national_id',''),type='password',key='loan_nid'+str(person.get('id',0)),help='주민등록번호 13자리 또는 생년월일 6·8자리를 입력하세요. 생년월일은 차용증에 그대로 표시됩니다.')
            phone=cols[1].text_input('전화번호',person.get('phone',''),key='loan_phone'+str(person.get('id',0)))
            address=st.text_input('주소',person.get('address',''),key='loan_address'+str(person.get('id',0)))
        with st.container(border=True):
            st.markdown('**지급회사**')
            company=st.text_input('차용금 지급회사명')
        v=fields('new_',c=c)
        number=v.pop('number')
        with st.container(border=True):
            st.markdown('**첨부서류**')
            files=st.file_uploader('첨부서류 · 파일당 10MB / 합계 30MB',accept_multiple_files=True,key='loan_upload')
        p=dict(name=name,national_id=nid,phone=phone,address=address,kind=kind)
        if st.button('차용증 저장',type='primary'):
            def save():
                id=db.save_loan(c,v,p,company,number,borrower_id=person.get('id'),files=uploads(files));go(PAGES[2],id)
            act(save)
    with right:
        st.subheader('차용증 미리보기')
        try:
            draft=calc.validate(v);calc.schedule(draft)
            draft.update(borrower=p,company=company,number=number,attachments=[f.name for f in files or []])
            components.html(report.certificate_html(draft),height=830,scrolling=True)
        except ValueError as e:st.info(str(e))

def detail(c):
    st.header('인별 차용현황')
    items=db.loans(c)
    if not items:st.info('차용증을 먼저 작성하세요.');return
    cols=st.columns(2)
    names=sorted({v['borrower']['name'] for v in items})
    person=cols[0].selectbox('차용인 조회',['전체']+names)
    company=cols[1].selectbox('지급회사 조회',['전체']+sorted({v['company'] for v in items}))
    filtered=[v for v in items if (person=='전체' or v['borrower']['name']==person) and (company=='전체' or v['company']==company)]
    if not filtered:st.info('해당 내역이 없습니다.');return
    selected=st.session_state.get('loan_selected');index=next((i for i,v in enumerate(filtered) if v['id']==selected),0)
    item=st.selectbox('차용 계약',filtered,index=index,format_func=lambda v:f"{v['number']} · {v['borrower']['name']} · {v['company']}")
    s=db.summary(c,item,db.today());cols=st.columns(4)
    for col,label,value in zip(cols,['대여 원금','회수 원금','남은 원금','기일 도래 미회수액'],[s['principal'],s['paid_principal'],s['balance'],s['unpaid']]):col.metric(label,calc.money(value)+'원')
    month=db.today().strftime('%Y-%m');planned=[r for r in s['plan'] if r['due_date'].startswith(month)];actual=[r for r in item['receipts'] if r['receipt_date'].startswith(month) and r['receipt_date']<=str(db.today())]
    st.info(f"이번 달 예정 원금 {calc.money(sum(r['principal'] for r in planned))}원 + 이자 {calc.money(sum(r['interest'] for r in planned))}원 · 실제 회수 {calc.money(sum(r['principal']+r['interest'] for r in actual))}원 · 다음 상환일 {s['next_due'] or '없음'}")
    tabs=st.tabs(['월별 상환·회수','차용증·첨부서류','예상 시나리오','계약 연장·갱신 이력'])
    with tabs[0]:
        frame=pd.DataFrame(s['plan']).rename(columns={'index':'회차','due_date':'상환일','principal':'예정 원금','interest':'예정 이자','total':'예정 합계','balance':'예정 잔액','paid_principal':'배분 회수원금','paid_interest':'배분 회수이자','paid':'배분 회수합계','unpaid':'기일 미회수','status':'상태'})
        st.dataframe(frame[[x for x in ['회차','상환일','예정 원금','예정 이자','예정 합계','예정 잔액','배분 회수원금','배분 회수이자','기일 미회수','상태'] if x in frame]],hide_index=True,use_container_width=True)
        st.caption('회수액은 원금·이자를 구분하여 오래된 회차부터 배분합니다. 예정 잔액은 약정 기준이며, 실제 남은 원금은 상단에 표시합니다.')
        st.subheader('실제 회수내역')
        st.dataframe(pd.DataFrame([{'회수일':r['receipt_date'],'회수원금':r['principal'],'회수이자':r['interest'],'입금방법':r['method'],'메모':r['note']} for r in item['receipts']]),hide_index=True,use_container_width=True)
        current=[r for r in item['receipts'] if r['contract_id']==item['contract_id']]
        edit=st.selectbox('회수 등록 / 수정',[None]+current,format_func=lambda r:'신규 등록' if r is None else f"{r['receipt_date']} · 원금 {calc.money(r['principal'])} / 이자 {calc.money(r['interest'])}") or {}
        with st.form('loan_receipt_'+str(item['id'])+'_'+str(edit.get('id',0))):
            st.markdown('**회수 정보**')
            cols=st.columns(2)
            rd=cols[0].date_input('회수일',calc.day(edit.get('receipt_date',db.today())))
            method=cols[1].text_input('입금방법',edit.get('method',''))
            st.markdown('**회수 금액**')
            cols=st.columns(2)
            rp=cols[0].number_input('실제 회수원금 (원)',min_value=0,value=int(edit.get('principal',0)))
            ri=cols[1].number_input('실제 회수이자 (원)',min_value=0,value=int(edit.get('interest',0)))
            st.markdown('**메모 · 증빙**')
            note=st.text_input('회수 메모',edit.get('note',''))
            evidence=st.file_uploader('입금 증빙',accept_multiple_files=True)
            if st.form_submit_button('회수내역 저장'):act(lambda:db.save_receipt(c,item['id'],rd,rp,ri,method,note,id=edit.get('id'),files=uploads(evidence)))
        if edit and st.checkbox('선택한 회수내역 삭제 확인') and st.button('회수내역 삭제'):act(lambda:db.delete_receipt(c,item['id'],edit['id']))
    with tabs[1]:downloads(c,item,'detail_'+str(item['id']))
    with tabs[2]:
        st.caption('가정만 비교하며 계약과 실제 회수내역은 변경하지 않습니다.')
        cols=st.columns(3);pre=cols[0].number_input('추가 원금상환 가정 (원)',0,s['balance'],0);rate=cols[1].number_input('변경 연이율 (%)',0.,100.,float(item['terms']['rate']));end=cols[2].date_input('예상 만기일',max(db.today(),calc.day(item['terms']['end_date'])))
        if st.button('시나리오 계산'):
            try:
                now=db.today();v=dict(item['terms'],principal=s['balance']-pre,start_date=str(now),end_date=str(end),first_due=str(min(calc.add_months(now,1),end)),rate=rate,carry_interest=s['unpaid_interest'],interest_credit=s['interest_credit'])
                plan=calc.schedule(v);st.metric('가정 후 총 상환액',calc.money(sum(r['total'] for r in plan))+'원');st.dataframe(pd.DataFrame([{'회차':r['index'],'상환일':r['due_date'],'예정 원금':r['principal'],'예정 이자':r['interest'],'상환액':r['total'],'예정 잔액':r['balance']} for r in plan]),hide_index=True,use_container_width=True)
            except ValueError as e:st.info(str(e))
    with tabs[3]:
        st.subheader('계약 연장 / 차용증 갱신')
        st.caption('기존 차용증·첨부·회수 이력을 보존하고 새 관리번호로 갱신합니다. 잔여원금은 한 번만 집계하며, 발생 미회수 이자는 별도로 이월합니다.')
        v=fields('renew_'+str(item['id'])+'_',dict(item['terms'],principal=s['balance']),True,c=c)
        number=v.pop('number')
        reason=st.text_input('계약 연장·갱신 사유')
        if st.checkbox('잔여원금·미회수 이자 승계 및 기존 계약 보존 확인') and st.button('계약 갱신 저장',type='primary'):act(lambda:db.renew(c,item['id'],v,number,v['start_date'],reason))
        st.dataframe(pd.DataFrame([dict(차수=x['version'],관리번호=x['number'],적용일=x['effective_date'],만기일=x['data']['end_date'],사유=x['reason']) for x in item['versions']]),hide_index=True,use_container_width=True)
        st.caption('갱신 차용증은 차용증·첨부서류 탭에서 확인·발행·출력하세요.')

def render(user):
    c=db.connect()
    with st.sidebar:
        page=st.session_state.get('loan_page',PAGES[0])
        for name in PAGES:
            if st.button(name,key='loan_nav_'+name,use_container_width=True,type='primary' if page==name else 'secondary'):go(name);st.rerun()
    {PAGES[0]:overview,PAGES[1]:compose,PAGES[2]:detail}.get(page,overview)(c)

"""Construction-company management-ratio checks and association PDF imports."""
from __future__ import annotations

from datetime import date, datetime
from io import BytesIO, StringIO
from pathlib import Path
import csv
import math
import re
import statistics
import sys

import openpyxl


RATIOS = {
    "debt_ratio": {
        "label": "부채비율", "unit": "%", "direction": "lower", "formula": "부채총계 ÷ 자기자본",
        "aliases": ["부채비율"], "points": [8.0, 7.2, 6.4, 5.6, 4.8], "thresholds": [50, 75, 100, 125],
    },
    "current_ratio": {
        "label": "유동비율", "unit": "%", "direction": "higher", "formula": "유동자산 ÷ 유동부채",
        "aliases": ["유동비율"], "points": [8.0, 7.2, 6.4, 5.6, 4.8], "thresholds": [150, 120, 100, 70],
    },
    "borrowing_ratio": {
        "label": "차입금의존도", "unit": "%", "direction": "lower", "formula": "차입금 ÷ 총자산",
        "aliases": ["차입금의존도", "차입금 의존도"], "points": [4.0, 3.6, 3.2, 2.8, 2.4], "thresholds": [50, 75, 100, 125],
    },
    "interest_coverage": {
        "label": "이자보상배율", "unit": "배", "direction": "higher", "formula": "영업이익 ÷ 이자비용",
        "aliases": ["이자보상배율", "이자 보상배율"], "points": [4.0, 3.6, 3.2, 2.8, 2.4], "thresholds": [150, 100, 50, 10],
    },
    "sales_profit_ratio": {
        "label": "매출액순이익률", "unit": "%", "direction": "higher", "formula": "세전이익 ÷ 매출액",
        "aliases": ["매출액순이익률", "매출액 순이익율", "매출순이익율"], "points": [3.0, 2.7, 2.4, 2.1, 1.8],
        "thresholds": [100, 75, 50, 10],
    },
    "asset_profit_ratio": {
        "label": "총자산순이익률", "unit": "%", "direction": "higher", "formula": "세전이익 ÷ 총자산",
        "aliases": ["총자산순이익률", "총자산 순이익율"], "points": [1.0, .9, .8, .7, .6], "thresholds": [150, 100, 50, 10],
    },
    "asset_turnover": {
        "label": "자산회전율", "unit": "회", "direction": "higher", "formula": "매출액 ÷ 평균총자산",
        "aliases": ["자산회전율", "자산 회전율"], "points": [3.0, 2.7, 2.4, 2.1, 1.8], "thresholds": [150, 100, 50, 10],
    },
    "tech_investment_ratio": {
        "label": "기술개발투자율", "unit": "%", "direction": "higher", "formula": "기술개발비 ÷ 건설매출액",
        "aliases": ["기술개발투자율", "기술개발 투자율"], "points": [4.0, 3.6, 3.2, 2.8, 2.4], "thresholds": [150, 100, 50, 10],
    },
    "business_years": {
        "label": "영업기간", "unit": "년", "direction": "direct", "formula": "설립일 ～ 결산일",
        "aliases": ["영업기간", "영업 기간"], "points": [2.0, 1.8, 1.6, 1.4], "thresholds": [10, 5, 3],
    },
}

FINANCIAL_FIELDS = {
    "debt_total": ("부채총계", ["부채총계", "부채 총계"]),
    "equity_total": ("자기자본", ["자본총계", "자기자본"]),
    "current_assets": ("유동자산", ["유동자산"]),
    "current_liabilities": ("유동부채", ["유동부채"]),
    "borrowings": ("차입금", ["차입금", "단기차입금", "장기차입금"]),
    "total_assets": ("기말총자산", ["자산총계", "부채및자본총계", "부채 및 자본 총계"]),
    "beginning_assets": ("기초총자산", ["전기자산총계", "자산총계(전기)", "부채및자본총계(전기)"]),
    "operating_profit": ("영업이익", ["영업이익"]),
    "interest_expense": ("이자비용", ["이자비용"]),
    "pre_tax_income": ("세전이익", ["법인세비용차감전순이익", "세전이익"]),
    "sales": ("매출액", ["매출액", "매출총액"]),
    "construction_sales": ("건설매출액", ["공사수입", "건설매출액", "공사매출액"]),
    "tech_development": ("기술개발비", ["기술개발비", "기술개발투자비"]),
}


def norm(value):
    return re.sub(r"[\s\n\r()·._\-ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]", "", str(value or "")).lower()


def number(value):
    if value in (None, "", "-"):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(float(value)) else None
    text = str(value).strip().replace(",", "").replace("%", "").replace("배", "").replace("회", "")
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    try:
        result = float(text)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def _pdf_text(content):
    try:
        from pypdf import PdfReader
    except ImportError:
        bundled = Path(__file__).resolve().parent / "vendor" / "pypdf-6.10.0.zip"
        if bundled.is_file() and str(bundled) not in sys.path:
            sys.path.insert(0, str(bundled))
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise ValueError("PDF 판독 모듈이 없습니다. 최신 업데이트를 다시 적용하세요.") from exc
    try:
        reader = PdfReader(BytesIO(content))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    except Exception as exc:
        raise ValueError("협회 PDF를 읽을 수 없습니다. 암호 또는 파일 손상 여부를 확인하세요.") from exc


def publication_year(text, filename=""):
    candidates = re.findall(r"(?:19|20)\d{2}", f"{filename}\n{text[:3000]}")
    years = [int(v) for v in candidates if 1990 <= int(v) <= date.today().year + 2]
    return max(years) if years else date.today().year - 1


def extract_pdf_ratios(content, filename=""):
    """Best-effort extraction; every result remains editable before saving."""
    text = _pdf_text(content)
    compact_lines = [re.sub(r"\s+", " ", line).strip() for line in text.splitlines() if line.strip()]
    values = {}
    pattern = re.compile(r"[-+]?\d[\d,]*(?:\.\d+)?\s*(?:%|배|회|년)?")
    for key, spec in RATIOS.items():
        found = None
        for i, line in enumerate(compact_lines):
            if not any(norm(alias) in norm(line) for alias in spec["aliases"]):
                continue
            aliases_at = [line]
            if i + 1 < len(compact_lines):
                aliases_at.append(compact_lines[i + 1])
            if i + 2 < len(compact_lines):
                aliases_at.append(compact_lines[i + 2])
            joined = " ".join(aliases_at)
            pos = min((joined.find(alias) for alias in spec["aliases"] if alias in joined), default=0)
            candidates = []
            for token in pattern.findall(joined[max(0, pos):]):
                value = number(token)
                if value is None or (1900 <= value <= 2100 and not any(u in token for u in "%배회년")):
                    continue
                unit_match = spec["unit"] in token
                candidates.append((unit_match, value))
            if candidates:
                unit_values = [v for matched, v in candidates if matched]
                found = unit_values[0] if unit_values else candidates[0][1]
                break
        values[key] = found
    return {"year": publication_year(text, filename), "ratios": values, "text": text,
            "warning": "" if text.strip() else "문자 추출이 되지 않는 스캔 PDF입니다. 공시값을 직접 입력해 주세요."}


def _matrixes(name, content):
    lower = name.lower()
    if lower.endswith(".csv"):
        text = content.decode("utf-8-sig", errors="replace")
        return [("CSV", list(csv.reader(StringIO(text))))]
    if lower.endswith(".xls"):
        try:
            import xlrd
        except ImportError:
            wheel = Path(__file__).resolve().parent / "vendor" / "xlrd-2.0.2-py2.py3-none-any.whl"
            if wheel.is_file() and str(wheel) not in sys.path:
                sys.path.insert(0, str(wheel))
            import xlrd
        book = xlrd.open_workbook(file_contents=content, on_demand=True)
        return [(book.sheet_by_index(i).name,
                 [[cell.value for cell in book.sheet_by_index(i).row(r)] for r in range(book.sheet_by_index(i).nrows)])
                for i in range(book.nsheets)]
    if not lower.endswith(".xlsx"):
        raise ValueError("XLS, XLSX 또는 CSV 재무자료만 업로드할 수 있습니다.")
    book = openpyxl.load_workbook(BytesIO(content), data_only=True, read_only=True)
    return [(ws.title, [list(row) for row in ws.iter_rows(values_only=True)]) for ws in book]


def extract_financial_statement(name, content):
    results = {key: None for key in FINANCIAL_FIELDS}
    evidence = {}
    for sheet_name, matrix in _matrixes(name, content):
        for row_index, row in enumerate(matrix, 1):
            for col_index, cell in enumerate(row):
                cell_norm = norm(cell)
                if not cell_norm:
                    continue
                for key, (_, aliases) in FINANCIAL_FIELDS.items():
                    # Exact normalized labels avoid mistaking ratio headings
                    # such as "차입금의존도" or "매출액순이익률" for source accounts.
                    if results[key] is not None or not any(norm(alias) == cell_norm for alias in aliases):
                        continue
                    right = [number(v) for v in row[col_index + 1:]]
                    right = [v for v in right if v is not None]
                    if right:
                        results[key] = right[0]
                        evidence[key] = f"{sheet_name} {row_index}행"
                        if key == "total_assets" and results["beginning_assets"] is None and len(right) > 1:
                            results["beginning_assets"] = right[1]
                            evidence["beginning_assets"] = f"{sheet_name} {row_index}행 전기금액"
    return {"values": results, "evidence": evidence,
            "missing": [key for key, value in results.items() if value is None]}


def financial_ratios(values, year):
    v = {key: float(values.get(key) or 0) for key in FINANCIAL_FIELDS}
    def pct(num, den):
        return num / den * 100 if den else None
    established = values.get("established_date")
    years = None
    if established:
        try:
            started = datetime.fromisoformat(str(established)[:10]).date()
            ended = date(int(year), 12, 31)
            years = max(0, ended.year - started.year - ((ended.month, ended.day) < (started.month, started.day)))
        except ValueError:
            pass
    average_assets = (v["beginning_assets"] + v["total_assets"]) / 2 if v["beginning_assets"] and v["total_assets"] else v["total_assets"]
    return {
        "debt_ratio": pct(v["debt_total"], v["equity_total"]),
        "current_ratio": pct(v["current_assets"], v["current_liabilities"]),
        "borrowing_ratio": pct(v["borrowings"], v["total_assets"]),
        "interest_coverage": v["operating_profit"] / v["interest_expense"] if v["interest_expense"] else None,
        "sales_profit_ratio": pct(v["pre_tax_income"], v["sales"]),
        "asset_profit_ratio": pct(v["pre_tax_income"], v["total_assets"]),
        "asset_turnover": v["sales"] / average_assets if average_assets else None,
        "tech_investment_ratio": pct(v["tech_development"], v["construction_sales"]),
        "business_years": years,
    }


def _remove_level_outliers(values):
    values = [float(v) for v in values]
    if len(values) < 4:
        return values, 0
    med = statistics.median(values)
    deviations = [abs(v - med) for v in values]
    mad = statistics.median(deviations)
    cleaned = list(values)
    removed = 0
    if mad == 0:
        limit = max(abs(med) * .5, .01)
        for i, value in enumerate(values):
            if abs(value - med) > limit:
                cleaned[i] = med
                removed += 1
    else:
        for i, value in enumerate(values):
            if .6745 * abs(value - med) / mad > 3.5:
                cleaned[i] = med
                removed += 1
    return cleaned, removed


def trend_forecast(points):
    """Recent-year weighted linear trend with robust level outlier handling."""
    pairs = sorted((int(year), float(value)) for year, value in points if value is not None)[-5:]
    if not pairs:
        return {"value": None, "lower": None, "upper": None, "confidence": "자료없음", "years": [], "outliers": 0, "r2": 0}
    years = [p[0] for p in pairs]
    raw = [p[1] for p in pairs]
    values, outliers = _remove_level_outliers(raw)
    if len(pairs) == 1:
        return {"value": values[0], "lower": values[0], "upper": values[0], "confidence": "낮음", "years": years, "outliers": outliers, "r2": 0}
    weights = list(range(1, len(pairs) + 1))
    sw = sum(weights)
    xbar = sum(w * x for w, x in zip(weights, years)) / sw
    ybar = sum(w * y for w, y in zip(weights, values)) / sw
    denominator = sum(w * (x - xbar) ** 2 for w, x in zip(weights, years))
    slope = sum(w * (x - xbar) * (y - ybar) for w, x, y in zip(weights, years, values)) / denominator if denominator else 0
    intercept = ybar - slope * xbar
    fitted = [intercept + slope * x for x in years]
    residuals = [y - fit for y, fit in zip(values, fitted)]
    sse = sum(w * r * r for w, r in zip(weights, residuals))
    sst = sum(w * (y - ybar) ** 2 for w, y in zip(weights, values))
    r2 = 1 - sse / sst if sst else 1.0
    forecast = max(0.0, intercept + slope * (years[-1] + 1))
    rmse = math.sqrt(sse / sw) if sw else 0
    spread = max(rmse * 1.64, abs(slope) * .35)
    confidence = "높음" if len(pairs) >= 5 and r2 >= .75 and not outliers else "보통" if len(pairs) >= 4 and r2 >= .4 else "낮음"
    if outliers and confidence == "높음":
        confidence = "보통"
    return {"value": forecast, "lower": max(0.0, forecast - spread), "upper": forecast + spread,
            "confidence": confidence, "years": years, "outliers": outliers, "r2": max(0.0, min(1.0, r2)), "slope": slope}


def grade_ratio(key, actual, official):
    spec = RATIOS[key]
    if actual is None:
        return {"relative": None, "grade": "-", "score": 0, "judgement": "자료확인"}
    if spec["direction"] == "direct":
        thresholds = spec["thresholds"]
        index = 0 if actual >= thresholds[0] else 1 if actual >= thresholds[1] else 2 if actual >= thresholds[2] else 3
        grade = "ABCD"[index]
        return {"relative": None, "grade": grade, "score": spec["points"][index], "judgement": "양호" if index <= 1 else "보완"}
    if official in (None, 0):
        return {"relative": None, "grade": "-", "score": 0, "judgement": "공시자료확인"}
    relative = actual / official * 100
    thresholds = spec["thresholds"]
    if spec["direction"] == "lower":
        index = 0 if relative < thresholds[0] else 1 if relative < thresholds[1] else 2 if relative < thresholds[2] else 3 if relative < thresholds[3] else 4
    else:
        index = 0 if relative >= thresholds[0] else 1 if relative >= thresholds[1] else 2 if relative >= thresholds[2] else 3 if relative >= thresholds[3] else 4
    grade = "ABCDE"[index]
    return {"relative": relative, "grade": grade, "score": spec["points"][index], "judgement": "양호" if index <= 1 else "보완"}


def evaluation_rows(actual, prior_official, forecasts):
    rows = []
    for key, spec in RATIOS.items():
        current = actual.get(key)
        official = prior_official.get(key) if prior_official else None
        forecast = forecasts.get(key, {})
        grade = grade_ratio(key, current, official)
        rows.append({"key": key, "점검 항목": spec["label"], "당사비율": current, "전년도 기준": official,
                     "예상 업종비율": forecast.get("value"), "예상 하한": forecast.get("lower"), "예상 상한": forecast.get("upper"),
                     "신뢰도": forecast.get("confidence", "자료없음"), "평균대비율": grade["relative"],
                     "등급": grade["grade"], "평점": grade["score"], "판정": grade["judgement"], "계산식": spec["formula"]})
    return rows


def format_ratio(key, value):
    if value is None:
        return "-"
    unit = RATIOS[key]["unit"]
    precision = 2 if unit in ("%", "배", "회") else 0
    return f"{value:,.{precision}f}{unit}"

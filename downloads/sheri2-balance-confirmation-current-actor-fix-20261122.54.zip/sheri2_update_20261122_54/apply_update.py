"""Install balance confirmations while preserving customized navigation files."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import secrets
import shutil
import sys

ROOT=Path(__file__).resolve().parent
VERSION='2026.11.22.54'
PAYLOAD=['mail_service.py','balance_confirmation_app.py','balance_confirmation_store.py','balance_confirmation_report.py']
PATCHED=['app_navigation.py','multiuser_app.py']
NEW={
 'mail_service.py':'67f588f6dbc8d493b019f0517f071f7c13e21c1bad2f6fe7bdf093888b2bdf50',
 'balance_confirmation_app.py':'920dcc45c417b8b7f43a0e442e84df496bde8a7d1c7b5392c932bc30ab7b12bc',
 'balance_confirmation_store.py':'fbbd1d647d240e54cfa70843d06a815971dab9fbe2aa16c06b6096b3f15f6199',
 'balance_confirmation_report.py':'bc7de2e1c8714fbd0de78f9ec398f89f761cb1360cb45251b06cdbe12ab9a1cf'}
MAIL_ACCEPTED={'5c7f95487a079a06b90dc21871c79a361103e2fc8223da8f5f184e4183a5f872',NEW['mail_service.py']}
MODULE_ACCEPTED={
 'balance_confirmation_app.py':{'e37cbbea156c0e63a7d1ce767125ca54d1c20d6151b3f9dd7142c37a9bcbece5','ee45070dcbe2b5b01d0be5a2335a6d3ac6f756fb89e3135783df7535dc828300',NEW['balance_confirmation_app.py']},
 'balance_confirmation_store.py':{'3ea686095e58b4a7de7cc350dd22913e725dac5c111eafa3e441d067f3113aa4','7a01b56246940e8dc1fd9511eee5cdb01e44b25b7b0536d99d2985d817dff817','dcbd742af46676fdf32706ff764c0d23796d2c3388556f0683894cc27996add7',NEW['balance_confirmation_store.py']},
 'balance_confirmation_report.py':{'927e563905ca444674edbabed49645366f86033c314a99b4c239c0eeece9c1fb',NEW['balance_confirmation_report.py']}}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def patch_navigation(text):
 if 'REPORTS' not in text or '법인결산' not in text or 'app_secondary_navigation' not in text:raise ValueError('현재 메뉴 구조를 확인할 수 없습니다: app_navigation.py')
 text,count=re.subn(r'^REPORTS\s*=.*$',"REPORTS = ['엘비데크 월별보고', '자체결산 보고', '법인결산', '채권채무확인서']",text,count=1,flags=re.M)
 if count!=1:raise ValueError('결산보고서 하위 메뉴 항목을 찾지 못했습니다.')
 text,count=re.subn(r"\['monthly'\s*,\s*'self'\s*,\s*'corporate'\s*(?:,\s*'balance_confirmation')?\]","['monthly','self','corporate','balance_confirmation']",text,count=1)
 if count!=1:raise ValueError('결산보고서 하위 메뉴 키를 찾지 못했습니다.')
 text,count=re.subn(r"(VERSION\s*=\s*)(['\"])([^'\"]+)\2",lambda m:m.group(1)+m.group(2)+VERSION+m.group(2),text,count=1)
 if count!=1:raise ValueError('메뉴 버전 항목을 찾지 못했습니다.')
 text=re.sub(r'버전\s+\d{4}\.\d{2}\.\d{2}\.\d+','버전 '+VERSION,text)
 compile(text,'app_navigation.py','exec');return text

def patch_router(text):
 if "program=='채권채무확인서'" in text:compile(text,'multiuser_app.py','exec');return text
 needle="""                elif program=='법인결산':
                    from corporate_close_app import render as render_corporate_close
                    render_corporate_close(user)
"""
 addition=needle+"""                elif program=='채권채무확인서':
                    from balance_confirmation_app import render as render_balance_confirmation
                    render_balance_confirmation(user)
"""
 if text.count(needle)!=1:raise ValueError('법인결산 화면 연결 위치를 찾지 못했습니다: multiuser_app.py')
 text=text.replace(needle,addition,1);compile(text,'multiuser_app.py','exec');return text

def verify_package():
 for name in PAYLOAD:
  source=ROOT/name
  if not source.is_file() or digest(source)!=NEW[name]:raise ValueError('업데이트 패키지 검증에 실패했습니다: '+name)
  compile(source.read_text(encoding='utf-8'),name,'exec')

def update(target):
 target=Path(target).expanduser().resolve()
 if target.is_file():target=target.parent
 if target==ROOT:raise ValueError('현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.')
 if not (target/'start.bat').is_file():raise ValueError('현재 사용하는 Sheri2 프로그램 폴더가 아닙니다.')
 verify_package()
 for name in PATCHED+['mail_service.py']:
  if not (target/name).is_file():raise ValueError('필수 프로그램 파일이 없습니다: '+name)
 if digest(target/'mail_service.py') not in MAIL_ACCEPTED:raise ValueError('현재 메일 기능 파일이 확인된 운영본과 다릅니다: mail_service.py. 아무 파일도 변경하지 않았습니다.')
 navigation=patch_navigation((target/'app_navigation.py').read_text(encoding='utf-8'))
 router=patch_router((target/'multiuser_app.py').read_text(encoding='utf-8'))
 for name in set(PAYLOAD)-{'mail_service.py'}:
  path=target/name
  if path.exists() and digest(path) not in MODULE_ACCEPTED[name]:raise ValueError('동일한 이름의 확인되지 않은 파일이 있습니다: '+name)
 stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3);backup=target/'private'/'code-updates'/stamp;backup.mkdir(parents=True)
 existing=[name for name in PATCHED+PAYLOAD if (target/name).is_file()]
 for name in existing:shutil.copy2(target/name,backup/name)
 (backup/'manifest.json').write_text(json.dumps({'version':VERSION,'files':{n:digest(target/n) for n in existing}},ensure_ascii=False,indent=2),encoding='utf-8')
 installed=[]
 try:
  for name in PAYLOAD:
   temporary=target/(name+'.update-'+secrets.token_hex(4))
   try:shutil.copy2(ROOT/name,temporary);temporary.replace(target/name);installed.append(name)
   finally:temporary.unlink(missing_ok=True)
  for name,content in [('app_navigation.py',navigation),('multiuser_app.py',router)]:
   temporary=target/(name+'.update-'+secrets.token_hex(4))
   try:temporary.write_text(content,encoding='utf-8');compile(content,name,'exec');temporary.replace(target/name);installed.append(name)
   finally:temporary.unlink(missing_ok=True)
 except BaseException:
  for name in reversed(installed):
   if name in existing:shutil.copy2(backup/name,target/name)
   else:(target/name).unlink(missing_ok=True)
  raise
 for name in PAYLOAD:
  if digest(target/name)!=NEW[name]:raise ValueError('설치 후 검증에 실패했습니다: '+name)
 if '채권채무확인서' not in (target/'app_navigation.py').read_text(encoding='utf-8'):raise ValueError('새 메뉴 설치 확인에 실패했습니다.')
 print('Balance confirmation and Nate IMAP update completed:',target)
 print('Customized navigation design was preserved. Only the new menu and route were added.')
 print('Existing databases and accounting records were not changed.')
 print('Code backup:',backup)

def choose_target():
 if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
 window=None
 try:
  import tkinter as tk
  from tkinter import filedialog
  window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
  return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
 finally:
  if window:window.destroy()

if __name__=='__main__':
 try:
  selected=choose_target()
  if not selected:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
  update(selected)
 except Exception as error:raise SystemExit('업데이트 실패: '+str(error))

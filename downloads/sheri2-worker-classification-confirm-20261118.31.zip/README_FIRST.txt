Sheri2 worker classification confirmation update 2026.11.18.31

Stops trial-balance import before the paid-in-capital account so equity and later income-statement rows are not searched, mapped or calculated.
Highlights the last saved account row in the review table and displays an explicit recalculation message and formula immediately after each row edit.
Applies the approved 자산 및 부채 평가 내역 output layout to Excel and print/PDF HTML, including the final real-capital versus legal-capital judgment.

Stores each worker-confirmed account decision independently. Editing another account or rerunning automatic mapping no longer changes a confirmed classification; use 자동판정으로 되돌리기 to unlock it.

Fixes guideline aliases failing to match Korean account names that contain distributed-alignment spaces, non-breaking spaces, zero-width characters or Hangul filler characters.
Normalizes full-width characters and compares letters and numbers only, then automatically refreshes the mapping workset after this update while preserving saved business data.
Replaces the spreadsheet-like editor with the approved right-hand review design: colored group/classification/special-handling cells, combined guideline rationale and review status. Accounts are edited or added through the visible selected-account editor below the review table.

Automatically maps uploaded trial-balance accounts to active diagnostic-guideline aliases and prepares editable drafts for account group, classification, special handling, net amount, rule reference, rationale and review status.
Combines guideline matching and account classification into the approved right-hand review grid, with clear automatic-draft, review-required, unclassified and excluded states.
Excludes statement heading and subtotal rows from calculation, preserves worker decisions during normal reruns, and only replaces draft classifications when the worker explicitly selects automatic remapping.

Locks company and license editing to the closing company selected at the top of the screen, eliminating cross-company editing confusion.
Removes the separate company selector and license effective-year input. License capital requirements are maintained as the company's current values and can be edited whenever the legal requirement changes.
Preserves previously saved closing-year license snapshots and safely converts legacy year-based license rows when the current settings are saved.

Registers the user-provided 건설업체 기업진단지침 source text with an explicit unverified effective-date status.
Adds a 기업진단지침 관리 menu with editable article rules, account aliases, recommendations, factual conditions and required evidence.
Matches uploaded trial-balance accounts to active rules and shows article-level bad/concurrent-asset candidates without inventing missing facts.
Calculates only deterministic cash and deposit adjustments automatically and stores the applied guideline version with each closing review.

Corrects real capital to use accounting assets minus liabilities, not paid-in capital.
Calculates asset net balances as debit minus credit and liability net balances as credit minus debit.
Separately calculates bad assets, concurrent-business assets/liabilities, cash excess, deposit-average adjustment and off-book liabilities.
Exactly reconciles the uploaded Da-hye Construction workbook: real capital KRW 1,776,075,215 and shortage KRW 148,924,785.
Moves company license capital requirements to 법인·업종 설정 and applies the company's current saved values.

Adds a polished 실질자본금 점검 menu below 경영상태비율 점검.
Imports XLS/XLSX/CSV trial balances or balance sheets, supports direct line editing, and preserves source, deduction and recognized-adjustment amounts separately.
Adds company-specific license capital requirements, overlap/concurrent-business adjustments, automatic sufficiency results, five-year history, Excel output and A4 print/PDF preview.
Saved values are isolated by company and closing year and remain locked until Edit is selected.

Adds the construction-company management-ratio review menu, annual association PDF registration, prior-year official grading, and a robust recent-year weighted trend forecast with outlier correction.
Adds company-sheet Excel and A4 print output with the forecast industry-average column, grades and scores.
Prevents all-zero association records, exposes year-by-year ratio editing, and ignores invalid zeros in official and trend calculations.
Shows company and forecast series with point markers and draws the fitted five-year forecast trend through the forecast year.
Adds operating cash-flow ratio to source entry, association data, grading, charts, Excel and print output.
Separates source-entry state by company and year, locks saved values until Edit is selected, and improves section color hierarchy.

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

This update preserves company databases, accounts, ledgers, attachments and closing data.
The application screen and reports remain in Korean.

After updating, open 법인결산 > 소득구분계산서 > 원장 업로드·적요 분류.
If the legacy-data warning appears, click 기존 원장 차변·대변 기준 재계산 once.

The closing-report submenu now opens 엘비데크 월별보고 first.
In the income-division statement, only 잡이익 is description-classified;
non-operating expense exempt/other amounts are entered directly and checked against the adjusted total.

Reserve items now support cost, SG&A, non-operating income and non-operating expense.
Matching tax adjustments automatically calculate current increases, deductions and ending reserves.
Tax-dues and prepaid-expense statements now support ledger upload, review and tax-adjustment linkage.
The first prepaid opening balance is entered manually; later years carry forward automatically.
Multiple policies for the same vehicle are calculated by contract period and then grouped by vehicle number.
The business-promotion statement imports six cost/SG&A ledgers and calculates the exact WEHAGO rows ⑤ through ⑱ by 판/도 division.
Workers can review and edit private-use, evidence, foreign-region, farmer/fisher, culture, traditional-market and local-gift amounts per transaction.
Revenue limits and limit excesses are intentionally excluded.
Tax-dues, prepaid-expense and business-promotion statement uploads now accept XLS, XLSX and CSV files. The offline XLS reader is included in this ZIP.
Rows labeled [월 계] or [누 계] are excluded from uploads and calculations in all three statements, including previously imported ledgers.
Prepaid opening balances are entered and edited by vehicle number or parcel, not as one total per ledger kind. Invalid identifier/period rows remain visible but are excluded from saving and calculations.
Tax-dues, prepaid-expense and business-promotion statements provide printable A4-landscape calculation HTML.
Prepaid opening balances are now edited directly in the current-contract calculation grid. Vehicle/parcel verification and printed output show opening balance, current expense and their combined amount on the same row.
The print workbook excludes the R&D detail, description-classification detail and reserve-ledger sections.

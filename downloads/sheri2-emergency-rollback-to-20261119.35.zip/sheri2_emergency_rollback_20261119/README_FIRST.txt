Emergency rollback from Sheri2 joint venture updates 36 and 37 to the verified v2026.11.19.35 operating state.

Run ROLLBACK_PROGRAM.bat and select start.bat from the program folder currently in use.
The tool restores only joint_app.py, joint_workflow.py, and app_navigation.py from the verified automatic backup created before update 36.
Database files and entered records are not modified.

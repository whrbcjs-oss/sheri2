@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
echo [Sheri2 joint venture emergency rollback]
echo Close the running Sheri2 server window first.
echo Select start.bat in the currently used Sheri2 program folder.
echo This restores code files only. Database and entered data are not changed.
pause
call find_python.bat
if errorlevel 1 goto fail
%FINANCE_PYTHON% rollback_update.py
if errorlevel 1 goto fail
echo Rollback completed. Run start.bat from the existing program folder.
pause
exit /b 0
:fail
echo Rollback stopped without selecting an unverified backup.
pause
exit /b 1

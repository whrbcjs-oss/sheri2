"""Restore the exact operating files saved immediately before updates 36/37."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import sys

FILES = ["joint_app.py", "joint_workflow.py", "app_navigation.py"]
BAD_VERSIONS = ["2026.11.19.36", "2026.11.19.37"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verified_candidate(folder):
    if not all((folder / name).is_file() for name in FILES):
        return False
    try:
        manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return False
    for name in FILES:
        expected = manifest.get(name)
        if not expected or digest(folder / name) != expected:
            return False
    combined = "\n".join((folder / name).read_text(encoding="utf-8", errors="replace") for name in FILES)
    return not any(version in combined for version in BAD_VERSIONS)


def restore(target):
    target = Path(target).expanduser().resolve()
    if target.is_file():
        target = target.parent
    if not (target / "start.bat").is_file() or not (target / "joint_app.py").is_file():
        raise ValueError("현재 사용 중인 프로그램 폴더의 start.bat을 선택하세요.")
    backup_root = target / "private" / "code-updates"
    if not backup_root.is_dir():
        raise ValueError("자동 코드 백업 폴더를 찾지 못했습니다. 아무 파일도 변경하지 않았습니다.")
    candidates = [folder for folder in backup_root.iterdir() if folder.is_dir() and verified_candidate(folder)]
    if not candidates:
        raise ValueError("36·37 설치 이전의 검증 가능한 공동도급 백업을 찾지 못했습니다. 아무 파일도 변경하지 않았습니다.")
    source = max(candidates, key=lambda folder: folder.name)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    safety = backup_root / ("rollback-current-" + stamp)
    safety.mkdir(parents=True)
    current_manifest = {}
    for name in FILES:
        current = target / name
        current_manifest[name] = digest(current) if current.exists() else None
        if current.exists():
            shutil.copy2(current, safety / name)
    (safety / "manifest.json").write_text(json.dumps(current_manifest, indent=2), encoding="utf-8")

    installed = []
    try:
        for name in FILES:
            destination = target / name
            temporary = target / (name + ".rollback-" + secrets.token_hex(4))
            try:
                shutil.copy2(source / name, temporary)
                if digest(temporary) != digest(source / name):
                    raise ValueError("복원 파일 검증에 실패했습니다: " + name)
                temporary.replace(destination)
                installed.append(name)
            finally:
                temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed):
            saved = safety / name
            if saved.exists():
                shutil.copy2(saved, target / name)
            else:
                (target / name).unlink(missing_ok=True)
        raise

    for name in FILES:
        if digest(target / name) != digest(source / name):
            raise ValueError("복원 후 검증에 실패했습니다: " + name)
    result = [
        "Sheri2 공동도급 긴급 복구 완료",
        "복원 원본 백업: " + str(source),
        "복구 직전 파일 보관: " + str(safety),
        "복원 파일: " + ", ".join(FILES),
        "DB, 원장, 마감자료, 발행본은 변경하지 않았습니다.",
    ]
    (target / "ROLLBACK_RESULT.txt").write_text("\n".join(result) + "\n", encoding="utf-8")
    print("\n".join(result))
    return source


def choose_target():
    if len(sys.argv) > 1:
        return sys.argv[1].strip().strip('"')
    window = None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window = tk.Tk()
        window.withdraw()
        window.attributes("-topmost", True)
        return filedialog.askopenfilename(parent=window, title="현재 사용 중인 프로그램의 start.bat을 선택하세요", filetypes=[("start.bat", "start.bat")])
    finally:
        if window:
            window.destroy()


if __name__ == "__main__":
    try:
        value = choose_target()
        if not value:
            raise ValueError("취소했습니다. 아무 파일도 변경하지 않았습니다.")
        restore(value)
    except Exception as error:
        raise SystemExit("복구 실패: " + str(error))

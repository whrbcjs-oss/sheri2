"""Escaped A4 loan certificates, PDF files and Excel-style loan-register printouts."""
from html import escape
from io import BytesIO
from PIL import Image,ImageDraw
import loan_calc as calc


def esc(value):return escape(str(value if value is not None else ''),quote=True)
def korean_amount(value):
    value=calc.won(value)
    if not value:return '영'
    digits='영일이삼사오육칠팔구';groups=[];units=['','만','억','조']
    for unit in units:
        group=value%10000;value//=10000
        if group:
            text=''
            for divisor,suffix in [(1000,'천'),(100,'백'),(10,'십'),(1,'')]:
                n,group=divmod(group,divisor)
                if n:text+=digits[n]+suffix
            groups.insert(0,text+unit)
    return ''.join(groups)


def interest_label(v):
    if v['interest_kind']==calc.KINDS[2]:return '무이자'
    if v['interest_kind']==calc.KINDS[1]:return '월정액 '+calc.money(v['fixed_interest'])+'원'
    return '연이율 '+str(v['rate'])+'%'


def certificate_lines(v,show_id=False):
    person=v.get('borrower',{});id_=person.get('national_id','')
    if not show_id:
        from loan_store import mask_id
        id_=mask_id(id_)
    dates=v['start_date'].replace('-','.')+' ~ '+v['end_date'].replace('-','.')
    if v['mode']==calc.MODES[2]:condition=f"이자는 매월 {v['pay_day']}일, 원금은 {v['end_date']}까지 상환할 것을 약속드립니다."
    elif v['mode']==calc.MODES[1]:condition=f"원리금은 {v['end_date']}까지 상환할 것을 약속드립니다."
    else:
        plan=calc.schedule(v);amount=calc.money(plan[0]['total'])
        condition=f"{v['method']} 방식으로 매월 {v['pay_day']}일 원리금을 상환하며, 최초 예정액은 {amount}원입니다. 최종 회차의 잔액은 만료일까지 정산할 것을 약속드립니다."
    result=[('title','차  용  증'),('small','관리번호: '+v.get('number','미저장')),('blank',''),('bold','■ 차용인'),('body','성명: '+person.get('name','')),('body','연락처: '+person.get('phone','')),('body','주민등록번호: '+id_),('body','주소: '+person.get('address','')),('blank',''),('bold','■ 차용금액: 일금 '+korean_amount(v['principal'])+'원정 (₩'+calc.money(v['principal'])+')'),('body','■ 차용기간: '+dates),('body','■ 차용이자: '+interest_label(v)),('blank',''),('body','상기 본인은 '+v.get('company','')+'로부터 위 금액을 차용하며, '+condition)]
    if v['interest_kind']==calc.KINDS[0]:result.append(('small','이자 계산 기준: '+v['basis']))
    if v['mode']!=calc.MODES[1]:result.append(('small','최초 상환일: '+v['first_due']))
    if v.get('carry_interest'):result.append(('body','이전 계약의 미회수 이자 '+calc.money(v['carry_interest'])+'원은 원금과 별도로 이월하여 첫 상환기일에 정산합니다.'))
    if v.get('interest_credit'):result.append(('body','이전 계약에서 선납한 이자 '+calc.money(v['interest_credit'])+'원은 이자 상환액에서 차감합니다.'))
    if v.get('previous_number'):result.append(('small','갱신 전 관리번호: '+v['previous_number']))
    result.extend([('blank',''),('body','# 담보물의 명칭 및 기타 조건: '+(v.get('collateral') or '별도 약정 없음'))])
    if v.get('note'):result.append(('body','# 추가 약정: '+v['note']))
    result.extend([('body','# 첨부서류: '+(', '.join(v.get('attachments',[])) or '별도 첨부 없음')+'. 끝.'),('blank',''),('center',v['issued_date'].replace('-','.')+' 작성'),('blank',''),('center','위 차용인: '+person.get('name','')+'                 (인)'),('center','(연락처: '+person.get('phone','')+')'),('blank',''),('company',v.get('company','')+' 귀중')])
    return result


DOC_CSS='''*{box-sizing:border-box}body{margin:0;background:#edf2ef;color:#111;font-family:"Malgun Gothic","Noto Serif CJK KR",serif}.tools{padding:10px;text-align:right}.tools button{border:0;border-radius:5px;padding:9px 18px;background:#087b52;color:#fff;cursor:pointer}.paper{background:#fff;max-width:210mm;min-height:270mm;margin:12px auto;padding:20mm 18mm;box-shadow:0 2px 8px #0001;font-size:14px;line-height:1.65;overflow-wrap:anywhere}.paper p{margin:3px 0;white-space:pre-wrap}.paper .title{text-align:center;font-size:27px;letter-spacing:9px;text-decoration:underline;text-underline-offset:8px;margin-bottom:24px}.paper .small{font-size:11px;color:#555}.paper .bold{font-weight:700}.paper .blank{height:17px}.paper .center{text-align:center;margin-top:8px}.paper .company{font-size:20px;margin-top:20px}.muted{color:#617569}@page{size:A4;margin:0}@media print{body{background:white}.tools{display:none}.paper{max-width:none;margin:0;box-shadow:none;min-height:0}p{break-inside:avoid}}'''


def certificate_html(v,show_id=False):
    body=''.join('<div class="blank"></div>' if k=='blank' else '<p class="'+k+'">'+esc(text)+'</p>' for k,text in certificate_lines(v,show_id))
    return '<!doctype html><html lang="ko"><meta charset="utf-8"><title>차용증 '+esc(v.get('number',''))+'</title><style>'+DOC_CSS+'</style><body><div class="tools"><button onclick="window.print()">인쇄 / PDF 저장</button></div><article class="paper">'+body+'</article></body></html>'


def certificate_pdf(v,show_id=False):
    from survey_report import font
    pages=[];page=Image.new('RGB',(2480,3508),'white');draw=ImageDraw.Draw(page);y=190;left=205;right=2275
    def next_page():
        nonlocal page,draw,y
        pages.append(page);page=Image.new('RGB',(2480,3508),'white');draw=ImageDraw.Draw(page);y=190
    for kind,text in certificate_lines(v,show_id):
        if kind=='blank':y+=65;continue
        size=23 if kind=='title' else 15 if kind=='company' else 9 if kind=='small' else 11.5
        f=font(size,kind in ['title','company','bold']);wrapped=[];line=''
        for char in text:
            if char=='\n' or draw.textlength(line+char,font=f)>right-left:
                wrapped.append(line);line='' if char=='\n' else char
            else:line+=char
        if line:wrapped.append(line)
        for line in wrapped:
            if y>3190:next_page()
            width=draw.textlength(line,font=f)
            x=(2480-width)/2 if kind in ['title','center'] else left
            draw.text((x,y),line,font=f,fill='black');y+=int(size*300/72*1.7)
        if kind=='title':y+=70
    pages.append(page);stream=BytesIO();pages[0].save(stream,format='PDF',save_all=True,append_images=pages[1:],resolution=300,quality=95)
    return stream.getvalue()


def register_html(summaries,as_of):
    headers=['관리번호','구분','차용인','지급회사','대여일','적요','채권금액','상환금액','잔액','상환일','이자','증빙','비고']
    groups={}
    for s in summaries:groups.setdefault(s['loan']['borrower_id'],[]).append(s)
    rows=[]
    for group in groups.values():
        for s in group:
            loan=s['loan'];v=loan['terms'];person=loan['borrower']
            data=[loan['number'],person['kind'],person['name'],loan['company'],loan['start_date'],'일시 대여금',calc.money(s['principal']),calc.money(s['paid_principal']),calc.money(s['balance']),v['end_date'],interest_label(v),'차용증',v.get('note','')]
            rows.append('<tr>'+''.join('<td class="'+('number' if i in [6,7,8] else '')+'">'+esc(t)+'</td>' for i,t in enumerate(data))+'</tr>')
        if len(group)>1:
            sums=[sum(s[k] for s in group) for k in ['principal','paid_principal','balance']]
            rows.append('<tr class="subtotal"><td colspan="6">'+esc(group[0]['loan']['borrower']['name'])+' 소계</td>'+''.join('<td class="number">'+calc.money(n)+'</td>' for n in sums)+'<td colspan="4"></td></tr>')
    sums=[sum(s[k] for s in summaries) for k in ['principal','paid_principal','balance']]
    rows.append('<tr class="total"><td colspan="6">전체 합계</td>'+''.join('<td class="number">'+calc.money(n)+'</td>' for n in sums)+'<td colspan="4"></td></tr>')
    approvals='<table class="approval"><tr>'+''.join('<th>'+name+'</th>' for name in ['담당','부장','상무','사장'])+'</tr><tr>'+'<td></td>'*4+'</tr></table>'
    css='''body{font:12px "Malgun Gothic",sans-serif;color:#162d29;margin:20px}h1{text-align:center;font-size:24px}.tools{text-align:right}button{padding:8px 18px;background:#087b52;color:white;border:0;border-radius:5px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #778d81;padding:7px 5px;text-align:center;overflow-wrap:anywhere}th{background:#e4f3e9}.number{text-align:right;white-space:nowrap}.subtotal{background:#fff7df;font-weight:bold}.total{background:#dff3e7;font-weight:bold}.register-head{display:flex;align-items:center;gap:20px}.register-head h1{flex:1}.approval{width:280px;margin-left:auto}.approval td{height:50px}.meta{text-align:right;margin:10px 0}.register{table-layout:fixed}.register th{font-size:11px}@page{size:A3 landscape;margin:10mm}@media print{.tools{display:none}body{margin:0}tr{break-inside:avoid}}'''
    return '<!doctype html><html lang="ko"><meta charset="utf-8"><title>임직원 차용현황표</title><style>'+css+'</style><div class="tools"><button onclick="window.print()">인쇄 / PDF 저장</button></div>'+'<div class="register-head"><h1>임직원 차용현황표</h1>'+approvals+'</div><div class="meta">기준일자: '+esc(as_of)+'</div><table class="register"><thead><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table><p>상환일은 현재 약정의 만료일입니다. 상환금액과 잔액은 기준일 실제 회수 원금을 반영합니다.</p></html>'

Sheri2 management-ratio chart visibility update 2026.11.16.21

Adds the construction-company management-ratio review menu, annual association PDF registration, prior-year official grading, and a robust recent-year weighted trend forecast with outlier correction.
Adds company-sheet Excel and A4 print output with the forecast industry-average column, grades and scores.
Prevents all-zero association records, exposes year-by-year ratio editing, and ignores invalid zeros in official and trend calculations.
Shows company and forecast series with point markers and draws the fitted five-year forecast trend through the forecast year.

1. Close the running Sheri2 server window.
2. Extract every file from this ZIP.
3. Double-click UPDATE_PROGRAM.bat.
4. Select start.bat in the existing Sheri2 installation folder.
5. Run the existing start.bat after completion.

This update preserves company databases, accounts, ledgers, attachments and closing data.
The application screen and reports remain in Korean.

After updating, open 법인결산 > 소득구분계산서 > 원장 업로드·적요 분류.
If the legacy-data warning appears, click 기존 원장 차변·대변 기준 재계산 once.

The closing-report submenu now opens 엘비데크 월별보고 first.
In the income-division statement, only 잡이익 is description-classified;
non-operating expense exempt/other amounts are entered directly and checked against the adjusted total.

Reserve items now support cost, SG&A, non-operating income and non-operating expense.
Matching tax adjustments automatically calculate current increases, deductions and ending reserves.
Tax-dues and prepaid-expense statements now support ledger upload, review and tax-adjustment linkage.
The first prepaid opening balance is entered manually; later years carry forward automatically.
Multiple policies for the same vehicle are calculated by contract period and then grouped by vehicle number.
The business-promotion statement imports six cost/SG&A ledgers and calculates the exact WEHAGO rows ⑤ through ⑱ by 판/도 division.
Workers can review and edit private-use, evidence, foreign-region, farmer/fisher, culture, traditional-market and local-gift amounts per transaction.
Revenue limits and limit excesses are intentionally excluded.
Tax-dues, prepaid-expense and business-promotion statement uploads now accept XLS, XLSX and CSV files. The offline XLS reader is included in this ZIP.
Rows labeled [월 계] or [누 계] are excluded from uploads and calculations in all three statements, including previously imported ledgers.
Prepaid opening balances are entered and edited by vehicle number or parcel, not as one total per ledger kind. Invalid identifier/period rows remain visible but are excluded from saving and calculations.
Tax-dues, prepaid-expense and business-promotion statements provide printable A4-landscape calculation HTML.
Prepaid opening balances are now edited directly in the current-contract calculation grid. Vehicle/parcel verification and printed output show opening balance, current expense and their combined amount on the same row.
The print workbook excludes the R&D detail, description-classification detail and reserve-ledger sections.

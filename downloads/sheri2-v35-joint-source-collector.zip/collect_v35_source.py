"""Collect only joint-venture program source files from a restored v35 install."""
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import sys


def collect(target):
    target = Path(target).expanduser().resolve()
    if target.is_file():
        target = target.parent
    if not (target / "start.bat").is_file():
        raise ValueError("현재 사용 중인 프로그램 폴더의 start.bat을 선택하세요.")
    navigation = target / "app_navigation.py"
    if not navigation.is_file():
        raise ValueError("app_navigation.py를 찾지 못했습니다.")
    text = navigation.read_text(encoding="utf-8", errors="replace")
    if "2026.11.19.35" not in text:
        raise ValueError("v2026.11.19.35 복구 상태가 아닙니다. 먼저 긴급 원상복구를 실행하세요.")

    names = sorted({path.name for path in target.glob("joint_*.py") if path.is_file()})
    names += [name for name in ["app_navigation.py", "multiuser_app.py"] if (target / name).is_file()]
    names = list(dict.fromkeys(names))
    required = {"joint_app.py", "joint_workflow.py", "joint_store.py", "joint_report.py"}
    missing = required - set(names)
    if missing:
        raise ValueError("필수 공동도급 파일이 없습니다: " + ", ".join(sorted(missing)))

    manifest = {"collected_at": datetime.now().isoformat(timespec="seconds"), "source_version": "2026.11.19.35", "files": {}}
    for name in names:
        path = target / name
        if path.stat().st_size > 5 * 1024 * 1024:
            raise ValueError("프로그램 파일 크기를 확인하세요: " + name)
        manifest["files"][name] = hashlib.sha256(path.read_bytes()).hexdigest()

    output = target / "sheri2-v35-joint-source.zip"
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        for name in names:
            archive.write(target / name, "v35_joint_source/" + name)
        archive.writestr("v35_joint_source/source_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    print("공동도급 프로그램 파일 수집 완료:", output)
    print("수집 파일:", ", ".join(names))
    print("DB, private 폴더, 원장과 입력자료는 포함하지 않았습니다.")
    print("생성된 sheri2-v35-joint-source.zip 파일을 대화창에 첨부해 주세요.")
    return output


def choose_target():
    if len(sys.argv) > 1:
        return sys.argv[1].strip().strip('"')
    window = None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window = tk.Tk()
        window.withdraw()
        window.attributes("-topmost", True)
        return filedialog.askopenfilename(parent=window, title="복구된 v35 프로그램의 start.bat을 선택하세요", filetypes=[("start.bat", "start.bat")])
    finally:
        if window:
            window.destroy()


if __name__ == "__main__":
    try:
        value = choose_target()
        if not value:
            raise ValueError("취소했습니다.")
        collect(value)
    except Exception as error:
        raise SystemExit("수집 실패: " + str(error))

@echo off
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
echo [Collect restored Sheri2 v2026.11.19.35 joint venture source]
echo Select start.bat from the restored program folder.
echo Database and entered data are not collected.
pause
call find_python.bat
if errorlevel 1 goto fail
%FINANCE_PYTHON% collect_v35_source.py
if errorlevel 1 goto fail
echo Collection completed. Upload sheri2-v35-joint-source.zip from the selected program folder.
pause
exit /b 0
:fail
echo Collection failed. Review the message above.
pause
exit /b 1

"""Install update 42 while preserving the installed navigation/theme source."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import secrets
import shutil
import sys

ROOT=Path(__file__).resolve().parent
CORE=['joint_app.py','joint_store.py','joint_workflow.py','joint_report.py','joint_status_report.py','joint_status.py','joint_status_app.py']
NAV='app_navigation.py'
ACCEPTED={
    'joint_app.py':{
        'eb847d16da1b2f96e182bb72c3ef87bd28b44b17d7108f9d52720bf398af2f9b',
        'a29ac529569310900cd0db1e218451b306e7c7e10bf08299bd4605acf8e0d177',
        '248862c7898be6c32e8fad3e8b19d03b8d5c19b3fd1e49ab1ccfd61649ac9ce4',
        'c2c6cd8f004c3b5e3670059ad6359e67f88681b37d901fe894add11522a2cb4f',
        'd9c85245f5006fdb89963d470853973b9212633574fb1ef7ed3f064579c8f644',
        '617526f70d7ea92b7d24864c14363247a363c5187e4d08fc88dd808bae20eedb',
        '39707a1cc34311c822a3a717dd7ee0be47e6cb65ef20075793fe4bd734d2a9ab',
        '5ad6455103c0bc837137fa3b249109bf107a7268debbc2e464c5f919172063dd',
    },
    'joint_store.py':{
        'a5ee881f649d64f377aed49d9e6e3dc644d3629b07fc7439b81e9194a305d622',
        '372acbc3c66a588587f2088392f660b3f27575f52fd3474590b612f81b6783f8',
        '6d0c6ef042bd78690cda48c9c2165edfb770a4b0627190e3e6ceea9bafe40c91',
        '6a92d80fffdbfe2f151979e7e3232f7c77d2018c5738b5194b7f3adf4674656f',
    },
    'joint_workflow.py':{
        '096c57d46adc850ae30eb577f0858ca66650d2f15be3c0bebe0ed59f411b0b37',
        '28b31b989c670bd87778508f329af2bfc73c30334db45ff20cbbf8c24391b051',
        '2b4982aece4d093188e83ef6add2dd83b6d638f915c8a1a45b971cb9acea6990',
    },
    'joint_report.py':{
        '69a03ee3574f5c5f8d65bba8ba7a6f965137c44cacfc92057e7053200c3036a2',
        '6623d3785547ec7a7eab6021016f41ef1abce9c43b06432a1a143fd9a765a22e',
    },
    'joint_status_report.py':{
        'e24e3b64f5b0b7578024e6b5b48f716d6e2de893c6e87f66d0c66820978d2f6d',
        '9c0d1b45a61dbe7fb8eb852b8c4f59952b78ea278ad335a8e57b949e2e8d172c',
    },
    'joint_status.py':{
        '4bdb55d5c40eec5be97f0f76e55e81b61cfccf95abbf533b46ad576101a84d38',
    },
    'joint_status_app.py':{
        '0cdefd1cdd6e4ed750110854b9f26634957b7d2f3d992a0c6e32cdbd3879bee7',
    },
}
NEW={
    'joint_app.py':'ce09a22bc5cd9f04510b6144c4d2581d02ef2cc00e3d9e83812e5454a4b10718',
    'joint_store.py':'6a92d80fffdbfe2f151979e7e3232f7c77d2018c5738b5194b7f3adf4674656f',
    'joint_workflow.py':'2b4982aece4d093188e83ef6add2dd83b6d638f915c8a1a45b971cb9acea6990',
    'joint_report.py':'c42744d4140add1165074a0855706e902dd1bb17cf3245baa2b39526dd3530c8',
    'joint_status_report.py':'a93a039f4d7d01c8a9cf585dbbbc7559ed10771bbf81544f2b985ac8a849d8a1',
    'joint_status.py':'0e86b10ec985230ef3e646e0039cfc13879dbffb3b6db60da0f51801488f722f',
    'joint_status_app.py':'a6726b666e67d43b0fdb8b5b3063cf2e167eb3d8d8ab6782028bbd874068da72',
}
VERSION='2026.11.26.72'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def patched_navigation(path):
    text=path.read_text(encoding='utf-8')
    if 'VERSION' not in text or 'st.' not in text:raise ValueError('현재 메뉴·테마 파일 형식을 확인할 수 없습니다. 아무 파일도 변경하지 않았습니다.')
    updated,count=re.subn(r"(VERSION\s*=\s*)(['\"])([^'\"]+)\2",lambda m:m.group(1)+m.group(2)+VERSION+m.group(2),text,count=1)
    if count!=1:raise ValueError('현재 메뉴·테마 파일의 버전 항목을 찾지 못했습니다. 아무 파일도 변경하지 않았습니다.')
    updated=re.sub(r'버전\s+\d{4}\.\d{2}\.\d{2}\.\d+', '버전 '+VERSION, updated)
    compile(updated,NAV,'exec')
    return updated

def update(target):
    target=Path(target).expanduser().resolve()
    if target.is_file():target=target.parent
    if target==ROOT:raise ValueError('현재 사용하는 프로그램 폴더의 start.bat을 선택하세요.')
    if not (target/'start.bat').is_file():raise ValueError('현재 사용하는 프로그램 폴더가 아닙니다.')
    for name in CORE:
        source=ROOT/name;installed=target/name
        if not source.is_file() or not installed.is_file():raise ValueError('필수 프로그램 파일이 없습니다: '+name)
        if digest(source)!=NEW[name]:raise ValueError('업데이트 패키지 파일 검증에 실패했습니다: '+name)
        current=digest(installed)
        if current not in ACCEPTED[name] and current!=NEW[name]:raise ValueError('확인된 최신 공동도급 운영본과 다른 파일입니다: '+name+'. 아무 파일도 변경하지 않았습니다.')
        compile(source.read_text(encoding='utf-8'),name,'exec')
    nav_path=target/NAV
    if not nav_path.is_file():raise ValueError('메뉴·테마 파일이 없습니다: '+NAV)
    nav_text=patched_navigation(nav_path)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)
    backup=target/'private'/'code-updates'/stamp;backup.mkdir(parents=True)
    manifest={}
    for name in CORE+[NAV]:
        path=target/name;manifest[name]=digest(path);shutil.copy2(path,backup/name)
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    installed_names=[]
    try:
        for name in CORE:
            destination=target/name;temporary=target/(name+'.update-'+secrets.token_hex(4))
            try:
                shutil.copy2(ROOT/name,temporary)
                if digest(temporary)!=NEW[name]:raise ValueError('복사 파일 검증에 실패했습니다: '+name)
                temporary.replace(destination);installed_names.append(name)
            finally:temporary.unlink(missing_ok=True)
        temporary=target/(NAV+'.update-'+secrets.token_hex(4))
        try:
            temporary.write_text(nav_text,encoding='utf-8')
            compile(temporary.read_text(encoding='utf-8'),NAV,'exec')
            temporary.replace(nav_path);installed_names.append(NAV)
        finally:temporary.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(installed_names):shutil.copy2(backup/name,target/name)
        raise
    for name in CORE:
        if digest(target/name)!=NEW[name]:raise ValueError('설치 후 검증에 실패했습니다: '+name)
    if VERSION not in (target/NAV).read_text(encoding='utf-8'):raise ValueError('메뉴 버전 표시 확인에 실패했습니다.')
    print('공동도급 금회예정 VAT 중복차감 수정 업데이트 완료:',target)
    print('현재 메뉴·테마 구성은 그대로 유지했습니다.')
    print('기존 코드 백업:',backup)
    print('DB, 원장, 정산, 마감 및 발행자료는 삭제하거나 변경하지 않았습니다.')

def choose_target():
    if len(sys.argv)>1:return sys.argv[1].strip().strip('"')
    window=None
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        return filedialog.askopenfilename(parent=window,title='현재 사용하는 Sheri2 프로그램의 start.bat을 선택하세요',filetypes=[('start.bat','start.bat')])
    finally:
        if window:window.destroy()

if __name__=='__main__':
    try:
        value=choose_target()
        if not value:raise ValueError('취소했습니다. 아무 파일도 변경하지 않았습니다.')
        update(value)
    except Exception as error:raise SystemExit('업데이트 실패: '+str(error))
